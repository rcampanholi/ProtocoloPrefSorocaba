﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormCorrigirConDB
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormCorrigirConDB))
        Me.CmdSair = New System.Windows.Forms.Button
        Me.CmdEspecCaminDB = New System.Windows.Forms.Button
        Me.LblLocalAtualDB = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.LblLocalInstalacao = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.SuspendLayout()
        '
        'CmdSair
        '
        Me.CmdSair.Location = New System.Drawing.Point(622, 129)
        Me.CmdSair.Name = "CmdSair"
        Me.CmdSair.Size = New System.Drawing.Size(75, 23)
        Me.CmdSair.TabIndex = 15
        Me.CmdSair.Text = "Sair"
        Me.CmdSair.UseVisualStyleBackColor = True
        '
        'CmdEspecCaminDB
        '
        Me.CmdEspecCaminDB.Location = New System.Drawing.Point(381, 129)
        Me.CmdEspecCaminDB.Name = "CmdEspecCaminDB"
        Me.CmdEspecCaminDB.Size = New System.Drawing.Size(235, 23)
        Me.CmdEspecCaminDB.TabIndex = 14
        Me.CmdEspecCaminDB.Text = "Especificar Caminho para o Banco de Dados"
        Me.CmdEspecCaminDB.UseVisualStyleBackColor = True
        '
        'LblLocalAtualDB
        '
        Me.LblLocalAtualDB.AutoSize = True
        Me.LblLocalAtualDB.Location = New System.Drawing.Point(12, 92)
        Me.LblLocalAtualDB.Name = "LblLocalAtualDB"
        Me.LblLocalAtualDB.Size = New System.Drawing.Size(0, 13)
        Me.LblLocalAtualDB.TabIndex = 13
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(9, 79)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(292, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Local atual onde sistema está buscando o Banco de Dados:"
        '
        'LblLocalInstalacao
        '
        Me.LblLocalInstalacao.AutoSize = True
        Me.LblLocalInstalacao.Location = New System.Drawing.Point(12, 55)
        Me.LblLocalInstalacao.Name = "LblLocalInstalacao"
        Me.LblLocalInstalacao.Size = New System.Drawing.Size(0, 13)
        Me.LblLocalInstalacao.TabIndex = 11
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(9, 42)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(185, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Local onde o Software está instalado:"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(685, 33)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "O caminho para o Banco de Dados não foi encontrado. Especifique o caminho para o " & _
            "banco de dados clicando no botão abaixo, feche a aplicação e abra-a novamente."
        Me.Label2.UseCompatibleTextRendering = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'FormCorrigirConDB
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(708, 165)
        Me.Controls.Add(Me.CmdSair)
        Me.Controls.Add(Me.CmdEspecCaminDB)
        Me.Controls.Add(Me.LblLocalAtualDB)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.LblLocalInstalacao)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FormCorrigirConDB"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Conexão com Banco de Dados"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CmdSair As System.Windows.Forms.Button
    Friend WithEvents CmdEspecCaminDB As System.Windows.Forms.Button
    Friend WithEvents LblLocalAtualDB As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents LblLocalInstalacao As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
End Class
