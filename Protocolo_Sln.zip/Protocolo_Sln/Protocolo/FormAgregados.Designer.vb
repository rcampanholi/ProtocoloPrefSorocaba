﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormAgregados
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormAgregados))
        Me.GroupInteressados = New System.Windows.Forms.GroupBox()
        Me.LstInteressadosGeral = New System.Windows.Forms.ListView()
        Me.ChkSelecionarTodosInteressadosGeral = New System.Windows.Forms.CheckBox()
        Me.TxtEncontrarInteressado = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ChkSelecionarTodosAgregados = New System.Windows.Forms.CheckBox()
        Me.TxtEncontrarAgregado = New System.Windows.Forms.TextBox()
        Me.LstAgregados = New System.Windows.Forms.ListView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LblInteressadoPrincipal = New System.Windows.Forms.Label()
        Me.CmdIncluir = New System.Windows.Forms.Button()
        Me.CmdExcluir = New System.Windows.Forms.Button()
        Me.CmdSair = New System.Windows.Forms.Button()
        Me.CmdCarregarLisInteressadosGeral = New System.Windows.Forms.Button()
        Me.GroupInteressados.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupInteressados
        '
        Me.GroupInteressados.Controls.Add(Me.CmdCarregarLisInteressadosGeral)
        Me.GroupInteressados.Controls.Add(Me.LstInteressadosGeral)
        Me.GroupInteressados.Controls.Add(Me.ChkSelecionarTodosInteressadosGeral)
        Me.GroupInteressados.Controls.Add(Me.TxtEncontrarInteressado)
        Me.GroupInteressados.Location = New System.Drawing.Point(12, 43)
        Me.GroupInteressados.Name = "GroupInteressados"
        Me.GroupInteressados.Size = New System.Drawing.Size(405, 378)
        Me.GroupInteressados.TabIndex = 0
        Me.GroupInteressados.TabStop = False
        Me.GroupInteressados.Text = "Interessados Geral"
        '
        'LstInteressadosGeral
        '
        Me.LstInteressadosGeral.AllowColumnReorder = True
        Me.LstInteressadosGeral.BackColor = System.Drawing.SystemColors.HighlightText
        Me.LstInteressadosGeral.CheckBoxes = True
        Me.LstInteressadosGeral.FullRowSelect = True
        Me.LstInteressadosGeral.HideSelection = False
        Me.LstInteressadosGeral.Location = New System.Drawing.Point(6, 53)
        Me.LstInteressadosGeral.MultiSelect = False
        Me.LstInteressadosGeral.Name = "LstInteressadosGeral"
        Me.LstInteressadosGeral.Size = New System.Drawing.Size(393, 293)
        Me.LstInteressadosGeral.TabIndex = 4
        Me.LstInteressadosGeral.UseCompatibleStateImageBehavior = False
        Me.LstInteressadosGeral.View = System.Windows.Forms.View.Details
        '
        'ChkSelecionarTodosInteressadosGeral
        '
        Me.ChkSelecionarTodosInteressadosGeral.AutoSize = True
        Me.ChkSelecionarTodosInteressadosGeral.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ChkSelecionarTodosInteressadosGeral.Enabled = False
        Me.ChkSelecionarTodosInteressadosGeral.Location = New System.Drawing.Point(6, 30)
        Me.ChkSelecionarTodosInteressadosGeral.Name = "ChkSelecionarTodosInteressadosGeral"
        Me.ChkSelecionarTodosInteressadosGeral.Size = New System.Drawing.Size(109, 17)
        Me.ChkSelecionarTodosInteressadosGeral.TabIndex = 1
        Me.ChkSelecionarTodosInteressadosGeral.Text = "Selecionar Todos"
        Me.ChkSelecionarTodosInteressadosGeral.UseVisualStyleBackColor = True
        '
        'TxtEncontrarInteressado
        '
        Me.TxtEncontrarInteressado.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TxtEncontrarInteressado.Enabled = False
        Me.TxtEncontrarInteressado.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.TxtEncontrarInteressado.Location = New System.Drawing.Point(6, 352)
        Me.TxtEncontrarInteressado.MaxLength = 80
        Me.TxtEncontrarInteressado.Name = "TxtEncontrarInteressado"
        Me.TxtEncontrarInteressado.Size = New System.Drawing.Size(393, 20)
        Me.TxtEncontrarInteressado.TabIndex = 3
        Me.TxtEncontrarInteressado.Text = "Encontrar Interessado"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ChkSelecionarTodosAgregados)
        Me.GroupBox1.Controls.Add(Me.TxtEncontrarAgregado)
        Me.GroupBox1.Controls.Add(Me.LstAgregados)
        Me.GroupBox1.Location = New System.Drawing.Point(504, 43)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(405, 378)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Interessados Agregados a esse Registro"
        '
        'ChkSelecionarTodosAgregados
        '
        Me.ChkSelecionarTodosAgregados.AutoSize = True
        Me.ChkSelecionarTodosAgregados.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ChkSelecionarTodosAgregados.Enabled = False
        Me.ChkSelecionarTodosAgregados.Location = New System.Drawing.Point(6, 30)
        Me.ChkSelecionarTodosAgregados.Name = "ChkSelecionarTodosAgregados"
        Me.ChkSelecionarTodosAgregados.Size = New System.Drawing.Size(109, 17)
        Me.ChkSelecionarTodosAgregados.TabIndex = 7
        Me.ChkSelecionarTodosAgregados.Text = "Selecionar Todos"
        Me.ChkSelecionarTodosAgregados.UseVisualStyleBackColor = True
        '
        'TxtEncontrarAgregado
        '
        Me.TxtEncontrarAgregado.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TxtEncontrarAgregado.Enabled = False
        Me.TxtEncontrarAgregado.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.TxtEncontrarAgregado.Location = New System.Drawing.Point(6, 352)
        Me.TxtEncontrarAgregado.MaxLength = 80
        Me.TxtEncontrarAgregado.Name = "TxtEncontrarAgregado"
        Me.TxtEncontrarAgregado.Size = New System.Drawing.Size(393, 20)
        Me.TxtEncontrarAgregado.TabIndex = 9
        Me.TxtEncontrarAgregado.Text = "Encontrar Interessado"
        '
        'LstAgregados
        '
        Me.LstAgregados.AllowColumnReorder = True
        Me.LstAgregados.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LstAgregados.BackColor = System.Drawing.SystemColors.HighlightText
        Me.LstAgregados.CheckBoxes = True
        Me.LstAgregados.FullRowSelect = True
        Me.LstAgregados.HideSelection = False
        Me.LstAgregados.Location = New System.Drawing.Point(6, 53)
        Me.LstAgregados.MultiSelect = False
        Me.LstAgregados.Name = "LstAgregados"
        Me.LstAgregados.Size = New System.Drawing.Size(393, 293)
        Me.LstAgregados.TabIndex = 8
        Me.LstAgregados.UseCompatibleStateImageBehavior = False
        Me.LstAgregados.View = System.Windows.Forms.View.Details
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(108, 13)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Interessado Principal:"
        '
        'LblInteressadoPrincipal
        '
        Me.LblInteressadoPrincipal.AutoSize = True
        Me.LblInteressadoPrincipal.Location = New System.Drawing.Point(132, 13)
        Me.LblInteressadoPrincipal.Name = "LblInteressadoPrincipal"
        Me.LblInteressadoPrincipal.Size = New System.Drawing.Size(47, 13)
        Me.LblInteressadoPrincipal.TabIndex = 13
        Me.LblInteressadoPrincipal.Text = "<Nome>"
        '
        'CmdIncluir
        '
        Me.CmdIncluir.Enabled = False
        Me.CmdIncluir.Image = CType(resources.GetObject("CmdIncluir.Image"), System.Drawing.Image)
        Me.CmdIncluir.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.CmdIncluir.Location = New System.Drawing.Point(423, 179)
        Me.CmdIncluir.Name = "CmdIncluir"
        Me.CmdIncluir.Size = New System.Drawing.Size(75, 53)
        Me.CmdIncluir.TabIndex = 4
        Me.CmdIncluir.Text = "Incluir <F2>"
        Me.CmdIncluir.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.CmdIncluir.UseVisualStyleBackColor = True
        '
        'CmdExcluir
        '
        Me.CmdExcluir.Enabled = False
        Me.CmdExcluir.Image = CType(resources.GetObject("CmdExcluir.Image"), System.Drawing.Image)
        Me.CmdExcluir.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.CmdExcluir.Location = New System.Drawing.Point(423, 238)
        Me.CmdExcluir.Name = "CmdExcluir"
        Me.CmdExcluir.Size = New System.Drawing.Size(75, 53)
        Me.CmdExcluir.TabIndex = 5
        Me.CmdExcluir.Text = "Excluir <F3>"
        Me.CmdExcluir.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.CmdExcluir.UseVisualStyleBackColor = True
        '
        'CmdSair
        '
        Me.CmdSair.Location = New System.Drawing.Point(834, 445)
        Me.CmdSair.Name = "CmdSair"
        Me.CmdSair.Size = New System.Drawing.Size(75, 23)
        Me.CmdSair.TabIndex = 10
        Me.CmdSair.Text = "Sair"
        Me.CmdSair.UseVisualStyleBackColor = True
        '
        'CmdCarregarLisInteressadosGeral
        '
        Me.CmdCarregarLisInteressadosGeral.Location = New System.Drawing.Point(305, 24)
        Me.CmdCarregarLisInteressadosGeral.Name = "CmdCarregarLisInteressadosGeral"
        Me.CmdCarregarLisInteressadosGeral.Size = New System.Drawing.Size(94, 23)
        Me.CmdCarregarLisInteressadosGeral.TabIndex = 5
        Me.CmdCarregarLisInteressadosGeral.Text = "Carregar Dados"
        Me.CmdCarregarLisInteressadosGeral.UseVisualStyleBackColor = True
        '
        'FormAgregados
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(921, 480)
        Me.Controls.Add(Me.CmdSair)
        Me.Controls.Add(Me.CmdExcluir)
        Me.Controls.Add(Me.CmdIncluir)
        Me.Controls.Add(Me.LblInteressadoPrincipal)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupInteressados)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Name = "FormAgregados"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Agregados"
        Me.GroupInteressados.ResumeLayout(False)
        Me.GroupInteressados.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupInteressados As System.Windows.Forms.GroupBox
    Friend WithEvents ChkSelecionarTodosInteressadosGeral As System.Windows.Forms.CheckBox
    Friend WithEvents TxtEncontrarInteressado As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents ChkSelecionarTodosAgregados As System.Windows.Forms.CheckBox
    Friend WithEvents TxtEncontrarAgregado As System.Windows.Forms.TextBox
    Friend WithEvents LstAgregados As System.Windows.Forms.ListView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LblInteressadoPrincipal As System.Windows.Forms.Label
    Friend WithEvents CmdIncluir As System.Windows.Forms.Button
    Friend WithEvents CmdExcluir As System.Windows.Forms.Button
    Friend WithEvents CmdSair As System.Windows.Forms.Button
    Friend WithEvents LstInteressadosGeral As System.Windows.Forms.ListView
    Friend WithEvents CmdCarregarLisInteressadosGeral As System.Windows.Forms.Button
End Class
