﻿Public Class FormImportacoes


    Dim ObjImportacoes As New ClassImportacoes
    Dim ObjMetodosGlobais As New ClassMetodosGlobais
    Dim ObjTratamentoArqsDirs As New ClassTratamentoDeArqsDirs

    Private Sub FormImportar_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Me.TxtCaminhoArq.Focus()

    End Sub

    Private Sub FormImportacoes_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated

        Me.CmdImportar.Focus()

    End Sub

    Private Sub TxtCaminhoArq_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtCaminhoArq.TextChanged

        If Me.TxtCaminhoArq.Text = String.Empty Then
            Me.CmdImportar.Enabled = False
        Else
            Me.CmdImportar.Enabled = True
        End If

    End Sub

    Private Sub CmdIndicarCaminhoArq_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdIndicarCaminhoArq.Click

        OpenFileDialog1.FileName = String.Empty
        OpenFileDialog1.Title = "Importar Arquivo"
        If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.Cancel Then
            Exit Sub
        End If

        TxtCaminhoArq.Text = OpenFileDialog1.FileName

    End Sub

    Private Sub CmdImportar_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdImportar.Click

        Me.DesabilitaBotoes()

        'VERIFICA SE O ARQUIVO EXISTE:
        If ObjImportacoes.VerificaArquivoExiste(TxtCaminhoArq.Text) = False Then
            MessageBox.Show("O arquivo informado não foi encontrado. Verifique, por favor.", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            LblInformacao.Text = "Clique no botão 'Importar' para iniciar a importação."
            Me.HabilitaBotoes()
            Exit Sub
        End If

        LblInformacao.Text = "Importando..."
        LblInformacao.Refresh()

        ObjImportacoes.ImportarInteressado(ObjTratamentoArqsDirs.RetNomeDir(TxtCaminhoArq.Text), ObjTratamentoArqsDirs.RetNomeArq(TxtCaminhoArq.Text))

        Me.LblInformacao.Text = "Clique no botão 'Importar' para iniciar a importação."
        Me.HabilitaBotoes()
        ProgressBar1.Value = 0

    End Sub

    Private Sub CmdSair_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdSair.Click

        Me.Close()
        Me.Dispose()
        FormPrincipal.Show()

    End Sub

    Sub DesabilitaBotoes()

        With Me
            .CmdImportar.Enabled = False
            .CmdSair.Enabled = False
        End With

    End Sub

    Sub HabilitaBotoes()

        With Me
            .CmdImportar.Enabled = True
            .CmdSair.Enabled = True
        End With

    End Sub

End Class