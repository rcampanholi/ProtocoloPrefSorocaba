﻿Imports System.IO
Imports Microsoft.Office.Interop

Public Class ClassTratamentoDeArqsDirs

    Sub ConverteTXTParaDoc(ByVal Diretorio As String, ByVal NomeArq As String, ByVal Orientacao As OrientacaoDoc)

        Dim MSWordApp As New Word.Application
        Dim DocumentoWord As New Word.Document

        'ABRE DOCUMENTO:
        DocumentoWord = MSWordApp.Documents.Open(Diretorio & NomeArq & ".txt", True, _
            False, False, "", "", False, "", "", Word.WdOpenFormat.wdOpenFormatEncodedText)
        FormataDocWord(DocumentoWord, Orientacao) 'FORMATA PAGINA DO DOCUMENTO
        Try
            DocumentoWord.SaveAs(Diretorio & NomeArq & ".doc", Word.WdSaveFormat.wdFormatDocument) 'SALVA ARQUIVO NO FORMATO MSWORD 2003
            DocumentoWord.Close() 'FECHA DOCUMENTO WORD
            MSWordApp.Quit() 'FECHA APLICAÇÃO WORD
            ExcluiArquivoTxt(Diretorio, NomeArq & ".txt") 'EXLCUI O ARQUIVO TXT
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try

    End Sub

    Sub ExcluiArquivoTxt(ByVal Diretorio As String, ByVal NomeArq As String)

        Dim Arquivo As New FileInfo(Diretorio & "\" & NomeArq)
        If Arquivo.Exists Then
            Arquivo.Delete()
        End If

    End Sub

    Sub FormataDocWord(ByRef DocumentoWord As Word.Document, ByVal Orientacao As OrientacaoDoc)

        Dim Fonte As Short = 0
        Dim Margem As Short = 0

        Fonte = 10
        Margem = 25

        With DocumentoWord.PageSetup
            .TopMargin = Margem
            .BottomMargin = Margem
            .LeftMargin = Margem
            .RightMargin = Margem
            .Orientation = Orientacao
        End With

        With DocumentoWord.Application.Selection
            .WholeStory()
            .Font.Size = Fonte
        End With

    End Sub

    Function DiretorioExiste(ByVal CaminhoDiretorio As String) As Boolean

        Dim Diretorio As New DirectoryInfo(CaminhoDiretorio)
        If Diretorio.Exists Then
            Return True
        Else
            Return False
        End If

    End Function

    Function RetNomeArq(ByRef CaminhoArq As String) As String

        Dim NomeArq As String = String.Empty
        Dim TamanhoNome As Short

        TamanhoNome = Len(CaminhoArq)

        For i As Integer = TamanhoNome To 1 Step -1
            If (Mid(CaminhoArq, i, 1) <> "/") And (Mid(CaminhoArq, i, 1) <> "\") Then
                NomeArq = Mid(CaminhoArq, i, 1) & NomeArq
            Else
                Exit For
            End If
        Next i

        Return NomeArq

    End Function

    Function RetNomeDir(ByRef CaminhoArq As String) As String

        Dim NomeDir As String
        Dim TamanhoNomeArq As Short
        Dim TamanhoNomeDir As Short = Len(CaminhoArq)

        TamanhoNomeArq = Len(RetNomeArq(CaminhoArq))
        NomeDir = Left(CaminhoArq, (TamanhoNomeDir - TamanhoNomeArq))

        Return NomeDir

    End Function

End Class
