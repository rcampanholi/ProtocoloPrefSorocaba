﻿Imports FirebirdSql.Data.FirebirdClient
Imports System.IO

Public Class ClassConexaoBanco

    Dim ObjMetodosGlobais As New ClassMetodosGlobais

    Sub EspecificaCaminhoDB(ByVal CaminhoArqBanco As String)

        'CRIA ARQUIVO QUE ESPECIFICA O CAMINHO PARA O BANCO DE DADOS:
        Dim Escritor As StreamWriter = File.CreateText(My.Application.Info.DirectoryPath & "\CaminhoBanco.txt")
        Escritor.Write(CaminhoArqBanco)
        Escritor.Close()
        MessageBox.Show("Processo concluído com sucesso.", "DeCalc", MessageBoxButtons.OK, MessageBoxIcon.Information)

    End Sub

    Sub CarregaStringConexao()

        Dim StrCaminhoBanco As String = LeArqCaminhoBanco()
        ''CARREGA A STRING DE CONEXÃO:
        'StringConexao = "Provider=LCPI.IBProvider;data source=" & StrCaminhoBanco & ";ctype=ANSI;" & _
        '                "user=SYSDBA;password=masterkey;dialect=3;auto_commit=true;auto_commit_level=0x1000;unicode_mode=FALSE;unicode_stmt=FALSE"

        StringConexao = "user=SYSDBA;password=masterkey;database=" & StrCaminhoBanco & ";dialect=3;auto_commit=true;"

    End Sub

    Function LeArqCaminhoBanco() As String

        'LÊ O ARQUIVO QUE ESPECIFICA O CAMINHO PARA O BANCO DE DADOS:
        Try
            Dim Leitor As StreamReader = File.OpenText(My.Application.Info.DirectoryPath & "\CaminhoBanco.txt")
            Dim StrCaminhoBanco As String = Leitor.ReadLine
            Leitor.Close()
            Return StrCaminhoBanco
        Catch Ex As Exception
            Return String.Empty
        End Try

    End Function

    Function EncontraMaxID(ByVal NomeTabela As String, ByVal NomeCampo As String) As Integer

        Dim MaxID As Integer
        Dim COMANDO As New FbCommand(String.Empty, Conexao)

        Try
            COMANDO.CommandText = "select max(" & NomeCampo & ") from " & NomeTabela
            Conexao.Open()
            MaxID = COMANDO.ExecuteScalar()
            Conexao.Close()
        Catch Ex As Exception
            MessageBox.Show(Ex.Message)
            Exit Function
        End Try
        Return MaxID

    End Function

End Class
