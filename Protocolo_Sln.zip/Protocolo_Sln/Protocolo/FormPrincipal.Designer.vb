﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormPrincipal
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormPrincipal))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.AdministraçãoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CadastroDeUsuáriosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConsultaSQLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImportarInteressadosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CadastroToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FuncionáriosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemetentesDestinatáriosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TiposDeDocumentosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProtocoloToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegistrosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CaixaDeEntradaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConsultaAvançadaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RelatóriosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RelatórioDeInclusõesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SairToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.LblBoasVindas = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AdministraçãoToolStripMenuItem, Me.CadastroToolStripMenuItem, Me.ProtocoloToolStripMenuItem, Me.RelatóriosToolStripMenuItem, Me.SairToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(828, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'AdministraçãoToolStripMenuItem
        '
        Me.AdministraçãoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CadastroDeUsuáriosToolStripMenuItem, Me.ConsultaSQLToolStripMenuItem, Me.ImportarInteressadosToolStripMenuItem})
        Me.AdministraçãoToolStripMenuItem.Name = "AdministraçãoToolStripMenuItem"
        Me.AdministraçãoToolStripMenuItem.Size = New System.Drawing.Size(96, 20)
        Me.AdministraçãoToolStripMenuItem.Text = "&Administração"
        '
        'CadastroDeUsuáriosToolStripMenuItem
        '
        Me.CadastroDeUsuáriosToolStripMenuItem.Name = "CadastroDeUsuáriosToolStripMenuItem"
        Me.CadastroDeUsuáriosToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.CadastroDeUsuáriosToolStripMenuItem.Text = "Cadastro de &Usuários"
        '
        'ConsultaSQLToolStripMenuItem
        '
        Me.ConsultaSQLToolStripMenuItem.Name = "ConsultaSQLToolStripMenuItem"
        Me.ConsultaSQLToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.ConsultaSQLToolStripMenuItem.Text = "Consulta &SQL"
        '
        'ImportarInteressadosToolStripMenuItem
        '
        Me.ImportarInteressadosToolStripMenuItem.Name = "ImportarInteressadosToolStripMenuItem"
        Me.ImportarInteressadosToolStripMenuItem.Size = New System.Drawing.Size(188, 22)
        Me.ImportarInteressadosToolStripMenuItem.Text = "&Importar Interessados"
        '
        'CadastroToolStripMenuItem
        '
        Me.CadastroToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FuncionáriosToolStripMenuItem, Me.RemetentesDestinatáriosToolStripMenuItem, Me.TiposDeDocumentosToolStripMenuItem})
        Me.CadastroToolStripMenuItem.Name = "CadastroToolStripMenuItem"
        Me.CadastroToolStripMenuItem.Size = New System.Drawing.Size(66, 20)
        Me.CadastroToolStripMenuItem.Text = "&Cadastro"
        '
        'FuncionáriosToolStripMenuItem
        '
        Me.FuncionáriosToolStripMenuItem.Name = "FuncionáriosToolStripMenuItem"
        Me.FuncionáriosToolStripMenuItem.Size = New System.Drawing.Size(209, 22)
        Me.FuncionáriosToolStripMenuItem.Text = "&Interessados"
        '
        'RemetentesDestinatáriosToolStripMenuItem
        '
        Me.RemetentesDestinatáriosToolStripMenuItem.Name = "RemetentesDestinatáriosToolStripMenuItem"
        Me.RemetentesDestinatáriosToolStripMenuItem.Size = New System.Drawing.Size(209, 22)
        Me.RemetentesDestinatáriosToolStripMenuItem.Text = "&Remetentes/Destinatários"
        '
        'TiposDeDocumentosToolStripMenuItem
        '
        Me.TiposDeDocumentosToolStripMenuItem.Name = "TiposDeDocumentosToolStripMenuItem"
        Me.TiposDeDocumentosToolStripMenuItem.Size = New System.Drawing.Size(209, 22)
        Me.TiposDeDocumentosToolStripMenuItem.Text = "&Tipos de Documentos"
        '
        'ProtocoloToolStripMenuItem
        '
        Me.ProtocoloToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RegistrosToolStripMenuItem, Me.CaixaDeEntradaToolStripMenuItem, Me.ConsultaAvançadaToolStripMenuItem})
        Me.ProtocoloToolStripMenuItem.Name = "ProtocoloToolStripMenuItem"
        Me.ProtocoloToolStripMenuItem.Size = New System.Drawing.Size(71, 20)
        Me.ProtocoloToolStripMenuItem.Text = "&Protocolo"
        '
        'RegistrosToolStripMenuItem
        '
        Me.RegistrosToolStripMenuItem.Name = "RegistrosToolStripMenuItem"
        Me.RegistrosToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.RegistrosToolStripMenuItem.Text = "&Registros"
        '
        'CaixaDeEntradaToolStripMenuItem
        '
        Me.CaixaDeEntradaToolStripMenuItem.Name = "CaixaDeEntradaToolStripMenuItem"
        Me.CaixaDeEntradaToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.CaixaDeEntradaToolStripMenuItem.Text = "Caixa de &Entrada"
        '
        'ConsultaAvançadaToolStripMenuItem
        '
        Me.ConsultaAvançadaToolStripMenuItem.Name = "ConsultaAvançadaToolStripMenuItem"
        Me.ConsultaAvançadaToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.ConsultaAvançadaToolStripMenuItem.Text = "&Consulta Avançada"
        '
        'RelatóriosToolStripMenuItem
        '
        Me.RelatóriosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RelatórioDeInclusõesToolStripMenuItem})
        Me.RelatóriosToolStripMenuItem.Name = "RelatóriosToolStripMenuItem"
        Me.RelatóriosToolStripMenuItem.Size = New System.Drawing.Size(71, 20)
        Me.RelatóriosToolStripMenuItem.Text = "&Relatórios"
        '
        'RelatórioDeInclusõesToolStripMenuItem
        '
        Me.RelatórioDeInclusõesToolStripMenuItem.Name = "RelatórioDeInclusõesToolStripMenuItem"
        Me.RelatórioDeInclusõesToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.RelatórioDeInclusõesToolStripMenuItem.Text = "&Relatório de Inclusões"
        '
        'SairToolStripMenuItem
        '
        Me.SairToolStripMenuItem.Name = "SairToolStripMenuItem"
        Me.SairToolStripMenuItem.Size = New System.Drawing.Size(38, 20)
        Me.SairToolStripMenuItem.Text = "&Sair"
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(12, 369)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(804, 41)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Secretaria de Recursos Humanos"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 330)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(804, 39)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Prefeitura de Sorocaba"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 84)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(804, 39)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Protocolo Interno"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(232, 143)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(360, 172)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1.TabIndex = 5
        Me.PictureBox1.TabStop = False
        '
        'LblBoasVindas
        '
        Me.LblBoasVindas.AutoSize = True
        Me.LblBoasVindas.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblBoasVindas.Location = New System.Drawing.Point(12, 40)
        Me.LblBoasVindas.Name = "LblBoasVindas"
        Me.LblBoasVindas.Size = New System.Drawing.Size(85, 13)
        Me.LblBoasVindas.TabIndex = 9
        Me.LblBoasVindas.Text = "Bem vindo(a)."
        '
        'FormPrincipal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(828, 493)
        Me.Controls.Add(Me.LblBoasVindas)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "FormPrincipal"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Protocolo - SEAD"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents CadastroToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FuncionáriosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemetentesDestinatáriosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TiposDeDocumentosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SairToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents LblBoasVindas As System.Windows.Forms.Label
    Friend WithEvents AdministraçãoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CadastroDeUsuáriosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProtocoloToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RelatóriosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RegistrosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConsultaAvançadaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RelatórioDeInclusõesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConsultaSQLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CaixaDeEntradaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImportarInteressadosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
