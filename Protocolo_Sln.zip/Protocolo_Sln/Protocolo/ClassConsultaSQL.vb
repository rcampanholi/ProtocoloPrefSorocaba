﻿Public Class ClassConsultaSQL

    Sub LimpaCampos()

        With FormConsultaSQL
            .TxtConsultaSQL.Text = CStr(Nothing)
            .DataGridView1.DataSource = Nothing
        End With

        DesabilitaBotoesSQL()
        DesabilitaBotoesFlexGrid()

    End Sub

    Sub DesabilitaBotoesSQL()

        With FormConsultaSQL
            .CmdExecutar.Enabled = False
            .CmdApagar.Enabled = False
        End With

    End Sub

    Sub HabilitaBotoesSQL()

        With FormConsultaSQL
            .CmdExecutar.Enabled = True
            .CmdApagar.Enabled = True
        End With

    End Sub

    Sub DesabilitaBotoesFlexGrid()

        With FormConsultaSQL
            .CmdExportXLS.Enabled = False
            .CmdExportTXT.Enabled = False
            .CmdApagarGrid.Enabled = False
        End With

    End Sub

    Sub HabilitaBotoesFlexGrid()

        With FormConsultaSQL
            .CmdExportXLS.Enabled = True
            .CmdExportTXT.Enabled = True
            .CmdApagarGrid.Enabled = True
        End With

    End Sub

    Sub CarregaModeloSQL()

        Dim ConsultaModelo As String

        With FormConsultaSQL.TxtConsultaSQL
            .Text = String.Empty
            ConsultaModelo = "SELECT (CAMPO_1, CAMPO_2, CAMPO_N) " & vbNewLine & vbTab & "FROM 'NOME_DA_TABELA' " & vbNewLine & vbTab & vbTab & "WHERE (CONDIÇÃO)"
            .Text = ConsultaModelo
            .Refresh()
            .Focus()
        End With

    End Sub

    Sub LimpaLblInformacao()

        With FormConsultaSQL.LblInformacao
            .Text = String.Empty
            .Refresh()
        End With

    End Sub

End Class
