﻿
Public Module DeclaracoesGlobais

    Enum AcaoUsuario
        Incluindo = 1
        Alterando = 2
        Excluindo = 3
    End Enum

    Enum TipoInstrucao
        INSERT = 1
        UPDATE = 2
    End Enum

    Enum ObjFormPai
        Principal = 1
        Historicos = 2
        Registos = 3
        ConsultaAvancada = 4
        CaixaEntrada = 5
    End Enum

    Structure Usuario
        Dim IDUsuario As Integer
        Dim PermissaoIncluir As Boolean
        Dim PermissaoAlterar As Boolean
        Dim PermissaoExcluir As Boolean
    End Structure

    Enum OrientacaoDoc
        Retrato = 0
        Paisagem = 1
    End Enum

    Public ObjEstrUsuario As Usuario

    'CONEXÃO COM O BANCO (CONNECTION):
    Public Conexao As New FirebirdSql.Data.FirebirdClient.FbConnection
    'Public Conexao As New OleDb.OleDbConnection


    'COMANDO - INSERT, DELETE, UPDATE (COMMAND):
    '    Public COMANDO As New FirebirdSql.Data.FirebirdClient.FbCommand(String.Empty, Conexao)

    'Public COMANDO As New FBCOMMAND(String.Empty, Conexao)

    'BOOLEANS:
    Public UserAdm As Boolean
    Public CancelaEventos As Boolean = False

    'ENUMS
    Public ObjTipoInstrucao As TipoInstrucao

    'INTEGERS
    'Public IDUsuario As Integer
    'Public IdFuncionario As Integer
    'Public IdDocumento As Integer

    'STRINGS:
    Public StringConexao As String
    Public DataNula As String = "__/__/____"
    Public HoraNula As String = "__:__"

End Module
