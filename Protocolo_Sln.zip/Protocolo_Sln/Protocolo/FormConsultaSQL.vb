﻿Public Class FormConsultaSQL

    Dim ObjConsultaSQL As New ClassConsultaSQL
    Dim ObjMetodosGlobais As New ClassMetodosGlobais
    Dim ObjControles As New ClassControles
    Dim ObjRelatorios As New ClassRelatorios
    Dim ObjTratamentoArqsDirs As New ClassTratamentoDeArqsDirs

    Private Sub CmdExecutar_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdExecutar.Click

        DataGridView1.DataSource = Nothing
        ObjConsultaSQL.LimpaLblInformacao()

        Try
            ObjControles.PreencheDataGridView(Me.TxtConsultaSQL.Text, Me.DataGridView1, ClassControles.LinhaDataGridSelecionar.Primeira)
        Catch Ex As Exception
            MessageBox.Show("Houve um erro ao realizar a consulta: " & Ex.Message, "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.DataGridView1.DataSource = Nothing
            TxtConsultaSQL.Focus()
            Exit Sub
        End Try
        DataGridView1.Focus()
        Me.LblInformacao.Text = Me.DataGridView1.Rows.Count & " Registro(s) encontrado(s)."
        ObjConsultaSQL.HabilitaBotoesFlexGrid()

    End Sub

    Private Sub TxtConsultaSQL_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles TxtConsultaSQL.TextChanged

        If TxtConsultaSQL.Text = String.Empty Then
            ObjConsultaSQL.DesabilitaBotoesSQL()
        Else
            ObjConsultaSQL.HabilitaBotoesSQL()
        End If

    End Sub

    Private Sub TxtConsultaSQL_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtConsultaSQL.KeyDown

        Select Case e.KeyCode
            Case 116 'F5
                Call CmdExecutar_Click(CmdExecutar, New System.EventArgs())
            Case 117 'F6
                Call CmdCriarModelo_Click(CmdCriarModelo, New System.EventArgs())
            Case 118 'F7
                Call CmdApagar_Click(CmdApagar, New System.EventArgs())
            Case Else
                Exit Sub
        End Select

    End Sub

    Private Sub CmdCriarModelo_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdCriarModelo.Click

        Dim Pergunta As String

        Pergunta = MsgBox("Esta operação apagará o texto atual. Deseja continuar?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Atenção!")
        If (Pergunta = MsgBoxResult.No) Then
            TxtConsultaSQL.Focus()
            Exit Sub
        End If

        ObjConsultaSQL.LimpaLblInformacao()
        ObjConsultaSQL.CarregaModeloSQL()

    End Sub

    Private Sub CmdApagar_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdApagar.Click

        Dim Pergunta As String

        Pergunta = MsgBox("Deseja realmente apagar o texto da consulta?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Atenção!")
        If (Pergunta = MsgBoxResult.No) Then
            Exit Sub
        Else
            ObjConsultaSQL.LimpaLblInformacao()
            TxtConsultaSQL.Text = String.Empty
            TxtConsultaSQL.Focus()
        End If

    End Sub

    Private Sub DataGridView1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles DataGridView1.KeyDown

        Select Case e.KeyCode
            Case 116 'F5
                Call CmdExportXLS_Click(CmdExportXLS, New System.EventArgs())
            Case 117 'F6
                Call CmdExportTXT_Click(CmdExportTXT, New System.EventArgs())
            Case 118 'F7
                Call CmdApagarGrid_Click(CmdApagarGrid, New System.EventArgs())
            Case Else
                Exit Sub
        End Select

    End Sub

    Private Sub CmdExportXLS_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdExportXLS.Click

        'USUARIO ESCOLHE ONDE O ARQUIVO SERÁ SALVO:
        SaveFileDialog1.FileName = String.Empty
        SaveFileDialog1.Title = "Exportar para Excel"
        If SaveFileDialog1.ShowDialog() = Windows.Forms.DialogResult.Cancel Then
            Exit Sub
        End If
        Dim CaminhoArquivo As String = SaveFileDialog1.FileName
        ObjRelatorios.GerarRelatorioXLS(Me.DataGridView1, ObjTratamentoArqsDirs.RetNomeDir(CaminhoArquivo), ObjTratamentoArqsDirs.RetNomeArq(CaminhoArquivo))
        MessageBox.Show("Processo finalizado com sucesso.", "DeCalc", MessageBoxButtons.OK, MessageBoxIcon.Information)

    End Sub

    Private Sub CmdExportTXT_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdExportTXT.Click

        'USUARIO ESCOLHE ONDE O ARQUIVO SERÁ SALVO:
        SaveFileDialog1.FileName = String.Empty
        SaveFileDialog1.Title = "Exportar para TXT"
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.Cancel Then
            Exit Sub
        End If
        ObjRelatorios.GerarRelatorioTXT(Me.DataGridView1, ObjTratamentoArqsDirs.RetNomeDir(SaveFileDialog1.FileName), ObjTratamentoArqsDirs.RetNomeArq(SaveFileDialog1.FileName))
        MessageBox.Show("Processo finalizado com sucesso.", "DeCalc", MessageBoxButtons.OK, MessageBoxIcon.Information)

    End Sub

    Private Sub CmdApagarGrid_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdApagarGrid.Click

        Dim Pergunta As String
        Pergunta = CStr(MsgBox("Deseja realmente apagar o conteúdo?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Atenção!"))
        If (Pergunta = CStr(MsgBoxResult.No)) Then
            Exit Sub
        Else
            DataGridView1.DataSource = Nothing
        End If

        ObjConsultaSQL.DesabilitaBotoesFlexGrid()

    End Sub

    Private Sub CmdSair_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdSair.Click

        Call ObjConsultaSQL.LimpaCampos()
        Me.Close()
        Me.Dispose()

    End Sub

End Class