﻿Imports FirebirdSql.Data.FirebirdClient

Public Class FormRegistros

    Dim ObjControles As New ClassControles
    Public ColunasOcultarRegistros() As Short = {0}
    Public LarguraColunasRegistros() As Short = {1, 320, 2, 245, 3, 110, 4, 100}
    Public LinhaSelecionadaDataGridRegistros As Integer = 0
    Dim IdRegistro As Integer

    Private Sub FormRegistros_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Me.TxtCodigo.Focus()

    End Sub

    Private Sub FormRegistros_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        Dim ObjMensagens As New ClassMensagens

        If e.Alt = False Then
            Select Case e.KeyCode
                Case 113 'F2 - Consultar Nome / Registro
                    If Me.DataGridRegistros.RowCount = 0 Then
                        Exit Sub
                    End If
                    If Me.TxtCodigo.Focused = True Then
                        Exit Sub
                    End If
                    Me.Hide()
                    FormHistoricos.ObjFormPaiHistoricos = ObjFormPai.Registos
                    FormHistoricos.IdRegistroAtual = Me.DataGridRegistros.Rows(Me.DataGridRegistros.CurrentCellAddress.Y).Cells(0).Value
                    FormHistoricos.ObjTipoManutencao = FormHistoricos.TipoManutencao.Consulta
                    FormHistoricos.Show()
                Case 114 'F3 - Incluir Novo
                    If ObjEstrUsuario.PermissaoIncluir = False Then
                        ObjMensagens.UsuarioNaoHabilitado()
                        Exit Sub
                    End If
                    Me.Hide()
                    FormHistoricos.ObjFormPaiHistoricos = ObjFormPai.Registos
                    FormHistoricos.ObjTipoManutencao = FormHistoricos.TipoManutencao.NovoDocumento
                    FormHistoricos.Show()
                Case 115 'F4 - Incluir Histórico
                    If Me.DataGridRegistros.RowCount = 0 Then
                        Exit Sub
                    End If
                    If ObjEstrUsuario.PermissaoAlterar = False Then
                        ObjMensagens.UsuarioNaoHabilitado()
                        Exit Sub
                    End If
                    Me.Hide()
                    FormHistoricos.ObjFormPaiHistoricos = ObjFormPai.Registos
                    FormHistoricos.IdRegistroAtual = Me.DataGridRegistros.Rows(Me.DataGridRegistros.CurrentCellAddress.Y).Cells(0).Value
                    FormHistoricos.ObjTipoManutencao = FormHistoricos.TipoManutencao.NovoHistorico
                    FormHistoricos.Show()
                Case 116 'F5 - Alterar Trâmite
                    If Me.DataGridRegistros.RowCount = 0 Then
                        Exit Sub
                    End If
                    If ObjEstrUsuario.PermissaoAlterar = False Then
                        ObjMensagens.UsuarioNaoHabilitado()
                        Exit Sub
                    End If
                    Me.Hide()
                    FormHistoricos.ObjFormPaiHistoricos = ObjFormPai.Registos
                    FormHistoricos.IdRegistroAtual = Me.DataGridRegistros.Rows(Me.DataGridRegistros.CurrentCellAddress.Y).Cells(0).Value
                    FormHistoricos.ObjTipoManutencao = FormHistoricos.TipoManutencao.AlteracaoHistorico
                    FormHistoricos.Show()
                Case 117 'F6
                    If Me.DataGridRegistros.RowCount = 0 Then
                        Exit Sub
                    End If
                    If ObjEstrUsuario.PermissaoExcluir = False Then
                        ObjMensagens.UsuarioNaoHabilitado()
                        Exit Sub
                    End If
                    If MessageBox.Show("Esta ação excluirá o registro e todo seu histórico permanentemente. Tem certeza que deseja continuar?", "Atenção", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.No Then
                        Exit Sub
                    End If
                    IdRegistro = Me.DataGridRegistros.Rows(Me.DataGridRegistros.CurrentCellAddress.Y).Cells(0).Value
                    Dim ObjRegistros As New ClassRegistros
                    ObjRegistros.ExcluirHistoricoPorIDRegistro(IdRegistro)
                    ObjRegistros.ExcluirRegistroPorID(IdRegistro)
                    Me.TxtCodigo_LostFocus(Nothing, Nothing)
                    Me.TxtCodigo.Focus()
                Case 27 'ESC - SAIR
                    CmdSair_Click(Nothing, Nothing)
            End Select
        ElseIf e.Alt = True Then
            If e.KeyCode = Keys.F4 Then
                CmdSair_Click(Nothing, Nothing)
            End If
        End If

    End Sub

    Private Sub TxtCodigo_GotFocus(sender As Object, e As EventArgs) Handles TxtCodigo.GotFocus

        Dim ObjControles As New ClassControles
        ObjControles.SelecionaTodoTexto(Me.TxtCodigo)

    End Sub

    Sub TxtCodigo_LostFocus(sender As Object, e As EventArgs) Handles TxtCodigo.LostFocus

        Dim ObjInteressados As New ClassInteressado
        Dim DescrInteressadoAux As String = String.Empty

        If Me.TxtCodigo.Text <> String.Empty And IsNumeric(Me.TxtCodigo.Text) Then
            DescrInteressadoAux = ObjInteressados.RetornaDescrInteressado(Me.TxtCodigo.Text)
            If DescrInteressadoAux = String.Empty Then
                Me.TxtDescricao.Text = String.Empty
                Me.LblInformacao.Text = "Código não encontrado."
                Me.TxtCodigo.Focus()
                Dim ObjControle As New ClassControles
                ObjControle.SelecionaTodoTexto(Me.TxtCodigo)
                Exit Sub
            Else 'CARREGA DADOS DE ACORDO COM CODIGO INFORMADO
                TxtDescricao.Text = DescrInteressadoAux
                Me.LblInformacao.Text = String.Empty
                ObjControles.PreencheDataGridView(Me.TextoConsultaSQLRegistros, Me.DataGridRegistros, ClassControles.LinhaDataGridSelecionar.Ultima)
                ObjControles.FormataDataGridView(Me.DataGridRegistros, Me.ColunasOcultarRegistros, Me.LarguraColunasRegistros)
                If Me.DataGridRegistros.RowCount > 0 Then
                    Me.DataGridRegistros_SelectionChanged(Nothing, Nothing)
                    Me.DataGridRegistros.Focus()
                Else
                    Me.LblInformacao.Text = "Nenhum registro encontrado para os dados informados."
                End If

            End If
        Else
            Me.TxtDescricao.Text = String.Empty
            Me.LblInformacao.Text = "Código não encontrado."
            Me.TxtCodigo.Focus()
            Dim ObjControle As New ClassControles
            ObjControle.SelecionaTodoTexto(Me.TxtCodigo)
        End If

    End Sub

    Private Sub TxtCodigo_KeyDown(sender As Object, e As KeyEventArgs) Handles TxtCodigo.KeyDown

        If e.KeyCode = Keys.Enter Then
            Me.TxtCodigo_LostFocus(Nothing, Nothing)
            Exit Sub
        End If

        If e.Alt = False Then
            If e.KeyCode = 113 Then 'F2 - Consultar Código
                If Me.CmdPesquisa.Enabled = True Then
                    Me.Hide()
                    Me.CmdPesquisa_Click(Nothing, Nothing)
                End If
            End If
        End If

    End Sub

    Private Sub TxtCodigo_TextChanged(sender As Object, e As EventArgs) Handles TxtCodigo.TextChanged

        If Me.TxtDescricao.Text <> String.Empty Then 'SIGNIFICA QUE JÁ HAVIA UM REGISTRO ENCONTRADO E O CÓDIGO FOI ALTERADO
            Me.TxtDescricao.Text = String.Empty
            Me.DataGridRegistros.DataSource = Nothing
            Me.LblInformacao.Text = String.Empty
            Me.MskDataEntrada.Text = DataNula
            Me.TxtProcedencia.Text = String.Empty
            Me.MskDataSaida.Text = DataNula
            Me.TxtDestino.Text = String.Empty
        End If

    End Sub

    Private Sub CmdPesquisa_Click(sender As Object, e As EventArgs) Handles CmdPesquisa.Click

        FormPesquisaNome.ObjFormularioPaiPesquisa = ObjFormPai.Registos
        FormPesquisaNome.Show(Me)

    End Sub

    Public Sub DataGridRegistros_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGridRegistros.SelectionChanged

        If DataGridRegistros.RowCount > 0 Then
            If LinhaSelecionadaDataGridRegistros > 0 Then
                Me.CarregaCamposRegistros(LinhaSelecionadaDataGridRegistros)
                LinhaSelecionadaDataGridRegistros = 0
            Else
                Me.CarregaCamposRegistros(Me.DataGridRegistros.CurrentCellAddress.Y)
            End If
        End If

    End Sub

    ' *** SAIR ***
    Private Sub CmdSair_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdSair.Click

        Me.Close()
        Me.Dispose()

    End Sub

    Function TextoConsultaSQLRegistros() As String

        Dim CodInteressado As Integer = Me.TxtCodigo.Text

        Dim ComandoSql As String = "SELECT R.ID_REGISTRO, R.ASSUNTO, DC.DESCRICAO AS " & """TIPO DE DOCUMENTO""" & ", " & _
                                   "R.NUM_DOC AS " & """Nº DOC """ & ", R.ANO_DOC AS " & """ANO DOC""" & " " & _
                                   "FROM REGISTROS R, DOCUMENTOS DC, INTERESSADOS I " & _
                                   "WHERE DC.ID_DOCUMENTO = R.ID_TIPO_DOC " & _
                                   "AND R.ID_INTERESSADO = I.ID_INTERESSADO " & _
                                   "AND I.CODIGO = " & CodInteressado
        Return ComandoSql

    End Function

    Sub CarregaCamposRegistros(ByRef linha As Integer)

        If linha < 0 Then
            Exit Sub
        End If

        Dim IDRegistroAux As Integer = Me.DataGridRegistros.Rows(linha).Cells(0).Value
        Dim Comando As New FbCommand(String.Empty, Conexao)
        Comando.CommandText = "SELECT H.DATA_ENTRADA, R.PROCEDENCIA, H.DATA_SAIDA, DT.DESCRICAO AS DESTINO " & _
                                  "FROM REGISTROS R, HISTORICO_REGISTROS H, DESTINATARIOS DT " & _
                                  "WHERE DT.ID_DESTINATARIO = H.ID_DESTINAT_DESTINO " & _
                                  "AND R.ID_REGISTRO = H.id_registro " & _
                                  "AND H.ID_HISTORICO = (SELECT MAX(ID_HISTORICO) " & _
                                                        "FROM HISTORICO_REGISTROS WHERE ID_REGISTRO = " & IDRegistroAux & ")"
        Dim Tabela As FbDataReader
        Conexao.Open()
        Tabela = Comando.ExecuteReader
        If Tabela.Read Then
            With Me
                If Not IsDBNull(Tabela!DATA_ENTRADA) Then
                    .MskDataEntrada.Text = Tabela!DATA_ENTRADA 'DATA ENTRADA
                End If
                .TxtProcedencia.Text = Tabela!PROCEDENCIA 'PROCEDENCIA
                If Not IsDBNull(Tabela!DATA_SAIDA) Then
                    .MskDataSaida.Text = Tabela!DATA_SAIDA 'DATA SAÍDA
                End If
                .TxtDestino.Text = Tabela!DESTINO 'DESTINO
            End With
        End If
        Tabela.Close()
        Comando.Dispose()
        Conexao.Close()

    End Sub

    Sub LimpaCampos()

        With Me
            .MskDataEntrada.Text = DataNula
            .TxtProcedencia.Text = String.Empty
            .MskDataSaida.Text = DataNula
            .TxtDestino.Text = String.Empty
        End With

    End Sub

End Class