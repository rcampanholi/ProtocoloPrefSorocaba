﻿Imports FirebirdSql.Data.FirebirdClient

Public Class FormInteressados

    Dim ObjUsuarios As New ClassUsuarios
    Dim ObjControles As New ClassControles
    Dim ObjInteressados As New ClassInteressado
    Dim ColunasOcultar() As Short = {0}
    Dim LarguraColunas() As Short = {1, 100, 2, 376}
    Dim IdInteressado As Integer
    Dim CodigoInteressadoAux As Integer = 0
    Friend ObjFormularioPaiInteressados As ObjFormPai = ObjFormPai.Principal

    Private Sub FormInteressados_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed

        Me.Close()

        If Me.ObjFormularioPaiInteressados = ObjFormPai.Principal Then
            FormPrincipal.Show()
        ElseIf Me.ObjFormularioPaiInteressados = ObjFormPai.Historicos Then
            FormHistoricos.Show()
        End If

    End Sub

    Private Sub FormInteressados_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ObjControles.PreencheDataGridView(Me.TextoConsultaSQL, Me.DataGridView1, ClassControles.LinhaDataGridSelecionar.Primeira)
        ObjControles.FormataDataGridView(Me.DataGridView1, Me.ColunasOcultar, Me.LarguraColunas)

    End Sub

    Private Sub FormInteressados_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If e.Alt = False Then
            Select Case e.KeyCode
                Case 27 'ESC - SAIR
                    If Me.CmdSair.Enabled = True Then
                        CmdSair_Click(Nothing, Nothing)
                    End If
            End Select
        End If

        If (e.Control = True) Then
            Dim ObjBotao As New Button
            Select Case e.KeyCode
                Case 65 'A
                    CmdAlterar_Click(Nothing, Nothing)
                Case 78 'N
                    CmdNovo_Click(Nothing, Nothing)
                Case 83 'S
                    CmdSalvar_Click(Nothing, Nothing)
                Case 90 'Z
                    CmdCancel_Click(Nothing, Nothing)
            End Select
        End If

    End Sub

    ' *** SETA O FOCO PARA O GRID AO INICIAR O FORM ***
    Private Sub FormInteressados_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated

        If (DataGridView1.Enabled = True) Then
            DataGridView1.Focus()
        End If

    End Sub

    'CARREGA CAMPOS, CONFORME USUÁRIO NAVEGAR PELO GRID:
    Private Sub DataGridView1_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGridView1.SelectionChanged

        If DataGridView1.CurrentCellAddress.Y >= 0 Then
            Me.CarregaCampos(Me.DataGridView1.CurrentCellAddress.Y)
        End If

    End Sub

    ' *** NOVO ***
    Public Sub CmdNovo_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdNovo.Click

        If ObjUsuarios.PermiteUsuario(AcaoUsuario.Incluindo) = False Then
            Exit Sub
        End If
        Me.LimpaCampos()
        Me.HabilDesabilGrid(False)
        Me.HabilDesabilCampos(True)
        Me.HabilDesabilBotoesSuperiores(False)
        Me.HabilDesabilBotoesInferiores(True)
        ObjTipoInstrucao = TipoInstrucao.INSERT
        TxtCodigo.Focus()

    End Sub

    ' *** ALTERAR ***
    Public Sub CmdAlterar_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdAlterar.Click

        If ObjUsuarios.PermiteUsuario(AcaoUsuario.Alterando) = False Then
            Exit Sub
        End If

        If (Me.DataGridView1.RowCount = 0) Then
            MsgBox("Não há dados a serem alterados.", MsgBoxStyle.Exclamation, "Atenção!")
            Exit Sub
        End If
        IdInteressado = Me.DataGridView1.CurrentRow.Cells(0).Value
        CodigoInteressadoAux = Me.TxtCodigo.Text
        Me.HabilDesabilBotoesSuperiores(False)
        Me.HabilDesabilBotoesInferiores(True)
        Me.HabilDesabilCampos(True)
        Me.HabilDesabilGrid(False)
        ObjTipoInstrucao = TipoInstrucao.UPDATE
        TxtCodigo.Focus()

    End Sub

    ' *** SAIR ***
    Private Sub CmdSair_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdSair.Click

        Me.Close()
        Me.Dispose()

        If Me.ObjFormularioPaiInteressados = ObjFormPai.Principal Then
            FormPrincipal.Show()
        ElseIf Me.ObjFormularioPaiInteressados = ObjFormPai.Historicos Then
            FormHistoricos.Show()
        End If

    End Sub

    ' *** SALVAR ***
    Private Sub CmdSalvar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdSalvar.Click

        If Me.CamposInconsistentes = True Then
            Exit Sub
        End If
        If ObjTipoInstrucao = TipoInstrucao.INSERT Then
            If ObjInteressados.CodigoJaExiste(Me.TxtCodigo.Text) = True Then
                Me.TxtCodigo.Focus()
                Exit Sub
            End If
        ElseIf ObjTipoInstrucao = TipoInstrucao.UPDATE Then
            If CodigoInteressadoAux <> Me.TxtCodigo.Text Then 'HOUVE ALTERAÇÃO DO CÓDIGO
                If ObjInteressados.CodigoJaExiste(Me.TxtCodigo.Text, IdInteressado) = True Then
                    Me.TxtCodigo.Focus()
                    Exit Sub
                End If
            End If
        End If

        If ObjTipoInstrucao = TipoInstrucao.INSERT Then 'INSERT
            ObjInteressados.IncluiFuncionario(Me.ComandoInclusao)
            ObjControles.PreencheDataGridView(Me.TextoConsultaSQL, Me.DataGridView1, ClassControles.LinhaDataGridSelecionar.Primeira)
            ObjControles.FormataDataGridView(Me.DataGridView1, Me.ColunasOcultar, Me.LarguraColunas)
            'PROCURA ID INSERIDO PARA SETAR NO GRID:
            Dim LinhaSelecionada As Integer = ObjControles.EncontraPosicaoRegistroDataGrid(Me.DataGridView1, Me.TxtCodigo.Text, 1)
            Me.DataGridView1.CurrentCell = Me.DataGridView1.Rows(LinhaSelecionada).Cells(1)
            Me.CarregaCampos(LinhaSelecionada)
        ElseIf ObjTipoInstrucao = TipoInstrucao.UPDATE Then 'UPDATE
            ObjInteressados.AtualizaFuncionario(Me.ComandoAtualizacao)
            ObjControles.PreencheDataGridView(Me.TextoConsultaSQL, Me.DataGridView1, ClassControles.LinhaDataGridSelecionar.Primeira)
            ObjControles.FormataDataGridView(Me.DataGridView1, Me.ColunasOcultar, Me.LarguraColunas)
            Dim LinhaSelecionada As Integer = ObjControles.EncontraPosicaoRegistroDataGrid(Me.DataGridView1, IdInteressado, 0)
            Me.DataGridView1.CurrentCell = Me.DataGridView1.Rows(LinhaSelecionada).Cells(1)
            Me.CarregaCampos(LinhaSelecionada)
        End If

        Me.HabilDesabilBotoesInferiores(False)
        Me.HabilDesabilBotoesSuperiores(True)
        Me.HabilDesabilGrid(True)
        Me.HabilDesabilCampos(False)
        Me.DataGridView1.Focus()

    End Sub

    ' *** CANCELAR ***
    Public Sub CmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdCancel.Click

        Me.HabilDesabilCampos(False)
        Me.HabilDesabilGrid(True)
        Me.HabilDesabilBotoesSuperiores(True)
        Me.HabilDesabilBotoesInferiores(False)
        Me.CarregaCampos(Me.DataGridView1.CurrentCellAddress.Y)
        DataGridView1.Focus()

    End Sub

    Sub LimpaCampos()

        With Me
            .TxtCodigo.Text = String.Empty
            .TxtDescricao.Text = String.Empty
        End With

    End Sub

    Sub HabilDesabilCampos(ByVal Acao As Boolean)

        With Me
            .TxtCodigo.Enabled = Acao
            .TxtDescricao.Enabled = Acao
        End With

    End Sub

    Sub HabilDesabilGrid(ByVal Acao As Boolean)

        With Me
            .DataGridView1.Enabled = Acao
        End With

    End Sub

    Sub HabilDesabilBotoesSuperiores(ByVal Acao As Boolean)

        With Me
            .CmdNovo.Enabled = Acao
            .CmdAlterar.Enabled = Acao
            .CmdSair.Enabled = Acao
        End With

    End Sub

    Sub HabilDesabilBotoesInferiores(ByVal Acao As Boolean)

        With Me
            .CmdSalvar.Enabled = Acao
            .CmdCancel.Enabled = Acao
        End With

    End Sub

    Function CamposInconsistentes() As Boolean

        With Me
            'CAMPO CÓDIGO:
            If (.TxtCodigo.Text = String.Empty) Then
                MessageBox.Show("Todos os campos devem ser preenchidos.", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                .TxtCodigo.Focus()
                Return True
            ElseIf Not IsNumeric(.TxtCodigo.Text) = True Then
                MsgBox("O campo 'Matrícula' aceita somente números.", MsgBoxStyle.Exclamation, "Atenção!")
                .TxtCodigo.Focus()
                Return True
            End If

            'CAMPO DESCRIÇÃO:
            If (.TxtDescricao.Text = String.Empty) Then
                MsgBox("Todos os campos devem ser preenchidos.", MsgBoxStyle.Exclamation, "Atenção!")
                .TxtDescricao.Focus()
                Return True
            End If
        End With

    End Function

    Function TextoConsultaSQL() As String

        Dim ComandoSQL As String = "SELECT ID_INTERESSADO, CODIGO, DESCRICAO " & _
                                   "FROM INTERESSADOS " & _
                                   "ORDER BY DESCRICAO"
        Return ComandoSQL

    End Function

    Sub CarregaCampos(ByRef linha As Integer)

        With Me
            If (.DataGridView1.RowCount > 0) Then
                .TxtCodigo.Text = Format(.DataGridView1.Rows(linha).Cells(1).Value, "000000") 'CODIGO
                .TxtDescricao.Text = .DataGridView1.Rows(linha).Cells(2).Value 'DESCRICAO
            End If
        End With

    End Sub

    Function ComandoInclusao() As FBCOMMAND

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)

        With Me
            Comando.CommandText = "INSERT INTO INTERESSADOS(CODIGO, DESCRICAO) VALUES (?, ?) "
            Comando.Parameters.Add(String.Empty, FbDbType.Integer)
            Comando.Parameters(0).Value = .TxtCodigo.Text
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar)
            Comando.Parameters(1).Value = .TxtDescricao.Text
        End With

        Return Comando

    End Function

    Function ComandoAtualizacao() As FBCOMMAND

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)

        With Me
            Comando.CommandText = "UPDATE INTERESSADOS SET CODIGO = ?, DESCRICAO = ? " & _
                                  "WHERE ID_INTERESSADO = " & IdInteressado
            Comando.Parameters.Add(String.Empty, FbDbType.Integer)
            Comando.Parameters(0).Value = .TxtCodigo.Text
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar)
            Comando.Parameters(1).Value = .TxtDescricao.Text
        End With

        Return Comando

    End Function

    Private Sub TxtEncontraCod_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtEncontraCod.KeyDown

        If e.KeyCode = 13 Then
            TxtEncontraCod.Text = String.Empty
            DataGridView1.Focus()
        End If

    End Sub

    Private Sub TxtEncontraCod_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtEncontraCod.LostFocus

        TxtEncontraCod.Text = String.Empty

    End Sub

    Private Sub TxtEncontraCod_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles TxtEncontraCod.TextChanged

        If TxtEncontraCod.Text <> String.Empty Then
            Dim Linha As Integer = ObjControles.EncontraRegistroDataGridView(Me.DataGridView1, 1, TxtEncontraCod.Text, Len(TxtEncontraCod.Text))
            If Linha > 0 Then
                Me.CarregaCampos(Linha)
            End If
        End If

    End Sub

    Private Sub TxtEncontraDescr_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtEncontraDescr.KeyDown

        If e.KeyCode = 13 Then
            TxtEncontraDescr.Text = String.Empty
            DataGridView1.Focus()
        End If

    End Sub

    Private Sub TxtEncontraDescr_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtEncontraDescr.LostFocus

        TxtEncontraDescr.Text = String.Empty

    End Sub

    Private Sub TxtEncontraDescr_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles TxtEncontraDescr.TextChanged

        If TxtEncontraDescr.Text <> String.Empty Then
            Dim Linha As Integer = ObjControles.EncontraRegistroDataGridView(Me.DataGridView1, 2, TxtEncontraDescr.Text, Len(TxtEncontraDescr.Text))
            If Linha > 0 Then
                Me.CarregaCampos(Linha)
            End If
        End If

    End Sub

End Class