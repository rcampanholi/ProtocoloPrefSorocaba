﻿Imports Microsoft.Office.Interop
Imports FirebirdSql.Data.FirebirdClient
Imports System.Drawing.Printing
Imports System.Data
Imports System.Math
Imports System.IO

Public Class ClassRelatorios

    Dim ObjMetodosGlobais As New ClassMetodosGlobais
    Dim EmailsInvalidos As String = String.Empty
    Dim DestinatSemEmailCadastrado As String = String.Empty
    Dim ObjEstrDestinat() As EstrDestinatario = Nothing
    Dim DestinatarioAux As Short = 1
    Dim MensagensAux As Short = 1

    Structure EstrDestinatario
        Dim Nome As String
        Dim MensagemImpr() As String
        Dim MensagemEmail As String
    End Structure

    Enum TipoRelatorio
        EMail = 1
        Impressao = 2
    End Enum

    Sub CriarRelatorio(ByVal ComandoSQL As String, ByVal ObjTipoRelatorio As TipoRelatorio, ByVal UsuariosSelecionados As Boolean)

        Dim CodDestinatario As Integer = 0
        Dim StrDestinatario As String = String.Empty
        Dim EMailDestinatario As String = String.Empty
        Dim PrimeiraLinha As Boolean = True
        Dim Mensagem As String = String.Empty
        Dim NumDestinat As Short = 0
        Dim NumMsg As Short = 0

        Dim Tabela As FbDataReader = Nothing
        Dim Comando As New FbCommand(String.Empty, Conexao)

        Comando.CommandText = ComandoSQL
        Conexao.Open()
        Tabela = Comando.ExecuteReader

        Do While Tabela.Read
            If PrimeiraLinha = True Then
                PrimeiraLinha = False
                NumDestinat += 1 'INCREMENTA CONTADOR DE Nº DE DESTINATARIOS
                NumMsg += 1 'INCREMENTA CONTADOR DE NUMERO DE MENSAGENS
                CodDestinatario = Tabela!COD_DESTINAT
                StrDestinatario = Tabela!DESTINATARIO
                If ObjTipoRelatorio = TipoRelatorio.Impressao Then 'IMPRESSAO
                    ReDim ObjEstrDestinat(1)
                    ReDim ObjEstrDestinat(1).MensagemImpr(1)
                    ObjEstrDestinat(NumDestinat).Nome = StrDestinatario
                    ObjEstrDestinat(NumDestinat).MensagemImpr(NumMsg) = RetornaMensagemMontada(Tabela!ORIGEM, Tabela!COD_DESTINAT, Tabela!DESTINATARIO, Tabela!COD_INTERESSADO, Tabela!INTERESSADO, Tabela!DATA_ENTRADA, Tabela!DATA_SAIDA, Tabela!PROCEDENCIA, Tabela!ASSUNTO, Tabela!TIPO_DOC, ObjMetodosGlobais.ConverteValorNuloStr(Tabela!NUM_DOC), ObjMetodosGlobais.ConverteValorNuloStr(Tabela!ANO_DOC), Tabela!OBSERVACAO, Tabela!DATA_INCLUSAO, Tabela!HORA_INCLUSAO)
                    NumMsg += 1
                ElseIf ObjTipoRelatorio = TipoRelatorio.EMail Then 'EMAIL
                    If Tabela!EMAIL Is System.DBNull.Value Then
                        EMailDestinatario = String.Empty
                        DestinatSemEmailCadastrado &= "* " & StrDestinatario & vbNewLine
                    Else
                        EMailDestinatario = Tabela!EMAIL
                    End If
                    Mensagem = RetornaMensagemMontada(Tabela!ORIGEM, Tabela!COD_DESTINAT, Tabela!DESTINATARIO, Tabela!COD_INTERESSADO, Tabela!INTERESSADO, Tabela!DATA_ENTRADA, Tabela!DATA_SAIDA, Tabela!PROCEDENCIA, Tabela!ASSUNTO, Tabela!TIPO_DOC, ObjMetodosGlobais.ConverteValorNuloStr(Tabela!NUM_DOC), ObjMetodosGlobais.ConverteValorNuloStr(Tabela!ANO_DOC), Tabela!OBSERVACAO, Tabela!DATA_INCLUSAO, Tabela!HORA_INCLUSAO)
                End If
            Else 'NÃO É PRIMEIRA LINHA
                If CodDestinatario = Tabela!COD_DESTINAT Then 'MESMO DESTINATARIO, CONTINUA A GRAVAR MENSAGEM
                    If ObjTipoRelatorio = TipoRelatorio.Impressao Then 'IMPRESSAO 
                        ReDim Preserve ObjEstrDestinat(NumDestinat).MensagemImpr(UBound(ObjEstrDestinat(NumDestinat).MensagemImpr) + 1)
                        ObjEstrDestinat(NumDestinat).MensagemImpr(NumMsg) = RetornaMensagemMontada(Tabela!ORIGEM, Tabela!COD_DESTINAT, Tabela!DESTINATARIO, Tabela!COD_INTERESSADO, Tabela!INTERESSADO, Tabela!DATA_ENTRADA, Tabela!DATA_SAIDA, Tabela!PROCEDENCIA, Tabela!ASSUNTO, Tabela!TIPO_DOC, ObjMetodosGlobais.ConverteValorNuloStr(Tabela!NUM_DOC), ObjMetodosGlobais.ConverteValorNuloStr(Tabela!ANO_DOC), Tabela!OBSERVACAO, Tabela!DATA_INCLUSAO, Tabela!HORA_INCLUSAO)
                        NumMsg += 1
                    ElseIf ObjTipoRelatorio = TipoRelatorio.EMail Then 'EMAIL
                        Mensagem &= RetornaMensagemMontada(Tabela!ORIGEM, Tabela!COD_DESTINAT, Tabela!DESTINATARIO, Tabela!COD_INTERESSADO, Tabela!INTERESSADO, Tabela!DATA_ENTRADA, Tabela!DATA_SAIDA, Tabela!PROCEDENCIA, Tabela!ASSUNTO, Tabela!TIPO_DOC, ObjMetodosGlobais.ConverteValorNuloStr(Tabela!NUM_DOC), ObjMetodosGlobais.ConverteValorNuloStr(Tabela!ANO_DOC), Tabela!OBSERVACAO, Tabela!DATA_INCLUSAO, Tabela!HORA_INCLUSAO)
                    End If
                Else 'NÃO É MESMO DESTINATARIO
                    'NOVO DESTINATARIO:
                    CodDestinatario = Tabela!COD_DESTINAT
                    StrDestinatario = Tabela!DESTINATARIO
                    If ObjTipoRelatorio = TipoRelatorio.Impressao Then 'IMPRESSAO
                        NumDestinat += 1 'INCREMENTA CONTADOR DE Nº DE DESTINATARIOS
                        NumMsg = 1 '"ZERA" Nº DE MENSAGENS PARA RECEBER NOVO DESTINATARIO
                        ReDim Preserve ObjEstrDestinat(UBound(ObjEstrDestinat) + 1)
                        ReDim ObjEstrDestinat(NumDestinat).MensagemImpr(1)
                        ObjEstrDestinat(NumDestinat).Nome = Tabela!DESTINATARIO
                        ObjEstrDestinat(NumDestinat).MensagemImpr(NumMsg) = RetornaMensagemMontada(Tabela!ORIGEM, Tabela!COD_DESTINAT, Tabela!DESTINATARIO, Tabela!COD_INTERESSADO, Tabela!INTERESSADO, Tabela!DATA_ENTRADA, Tabela!DATA_SAIDA, Tabela!PROCEDENCIA, Tabela!ASSUNTO, Tabela!TIPO_DOC, ObjMetodosGlobais.ConverteValorNuloStr(Tabela!NUM_DOC), ObjMetodosGlobais.ConverteValorNuloStr(Tabela!ANO_DOC), Tabela!OBSERVACAO, Tabela!DATA_INCLUSAO, Tabela!HORA_INCLUSAO)
                        NumMsg += 1
                    ElseIf ObjTipoRelatorio = TipoRelatorio.EMail Then
                        EnviarEMail(EMailDestinatario, "Protocolo", Mensagem)
                        If Tabela!EMAIL Is System.DBNull.Value Then
                            EMailDestinatario = String.Empty
                            DestinatSemEmailCadastrado &= "* " & StrDestinatario & vbNewLine
                        Else
                            EMailDestinatario = Tabela!EMAIL 'RECEBE EMAIL DO NOVO DESTINATARIO
                        End If
                        NumDestinat += 1 'INCREMENTA CONTADOR DE Nº DE DESTINATARIOS
                    End If
                    'NOVO DESTINATARIO:
                    'CodDestinatario = Tabela!COD_DESTINAT
                    'StrDestinatario = Tabela!DESTINATARIO
                    Mensagem = String.Empty
                    Mensagem = RetornaMensagemMontada(Tabela!ORIGEM, Tabela!COD_DESTINAT, Tabela!DESTINATARIO, Tabela!COD_INTERESSADO, Tabela!INTERESSADO, Tabela!DATA_ENTRADA, Tabela!DATA_SAIDA, Tabela!PROCEDENCIA, Tabela!ASSUNTO, Tabela!TIPO_DOC, ObjMetodosGlobais.ConverteValorNuloStr(Tabela!NUM_DOC), ObjMetodosGlobais.ConverteValorNuloStr(Tabela!ANO_DOC), Tabela!OBSERVACAO, Tabela!DATA_INCLUSAO, Tabela!HORA_INCLUSAO)
                End If
            End If
        Loop

        If NumDestinat = 0 Then
            Conexao.Close()
            Tabela.Close()
            Comando.Dispose()
            If UsuariosSelecionados = False Then
                Dim ObjUsuarios As New ClassUsuarios
                MessageBox.Show("Nenhum registro que tenha sido cadastrado pelo usuário '" & ObjUsuarios.RetornaNomeUsuario(ObjEstrUsuario.IDUsuario) & "' foi encontrado, de acordo com os parâmetros informados.", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            Else
                MessageBox.Show("Nenhum registro que tenha sido cadastrado pelos usuários selecionados foi encontrado, de acordo com os parâmetros informados.", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            End If
        End If
            If ObjTipoRelatorio = TipoRelatorio.Impressao Then 'ATRIBUI VARIAVEIS DO ULTIMO DESTINATARIO E CHAMA ROTINA DE IMPRESSAO
                ImprimirRelatorio()
            ElseIf ObjTipoRelatorio = TipoRelatorio.EMail Then
                EnviarEMail(EMailDestinatario, "Protocolo", Mensagem) 'ENVIA EMAIL DO ULTIMO DESTINATARIO DA TABELA
                Dim ObjMensagens As New ClassMensagens
                ObjMensagens.EmailsInvalidos(EmailsInvalidos)
                ObjMensagens.DestinatSemEmail(DestinatSemEmailCadastrado)
            End If

            Conexao.Close()
            Tabela.Close()
            Comando.Dispose()

    End Sub

    Private Sub EnviarEMail(ByVal EnderecoEMail As String, ByVal AssuntoEMail As String, ByVal Mensagem As String)

        If EnderecoEMail = String.Empty Then
            Exit Sub
        End If

        Dim ObjOutlookApp As New Outlook.Application

        Dim ObjEMail As Outlook.MailItem = Nothing
        Dim ObjEndereco As Outlook.Recipient = Nothing

        Try
            ObjEMail = ObjOutlookApp.CreateItem(Outlook.OlItemType.olMailItem)
            ObjEndereco = ObjEMail.Recipients.Add(EnderecoEMail)
            ObjEMail.Subject = AssuntoEMail
            ObjEMail.Body = "Olá. A SEAD protocolou os seguintes documentos: " & vbNewLine & vbNewLine & Mensagem
            ObjEndereco.Resolve()

            If (ObjEndereco.Resolved) Then
                ObjEMail.Send()
            Else
                EmailsInvalidos &= "* " & EnderecoEMail & vbNewLine
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Ocorreu uma exceção não tratada no aplicativo.", MessageBoxButtons.OK, MessageBoxIcon.Error)
            If Err.Number = 287 Then 'OUTLOOK FECHADO
                MessageBox.Show("Verifique se o Microsoft Outlook encontra-se em execução.", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            End If
        End Try

        ObjEMail = Nothing
        ObjEndereco = Nothing
        ObjOutlookApp = Nothing

    End Sub

    Public Sub ImprimirRelatorio()

        'DEFINE O OBJETO PRINT DOCUMMENT:
        Dim ObjImprimirDocumento As Printing.PrintDocument = New Printing.PrintDocument

        'DEFINE OS EVENTOS PRINTPAGE, BEGINPRINT E END PRINT:
        'AddHandler ObjImprimirDocumento.BeginPrint, New Printing.PrintEventHandler(AddressOf Me.PrintDocument1_BeginPrint)
        AddHandler ObjImprimirDocumento.PrintPage, New Printing.PrintPageEventHandler(AddressOf Me.ImprimirDocumento_Imprimir)
        AddHandler ObjImprimirDocumento.EndPrint, New Printing.PrintEventHandler(AddressOf Me.ImprimirDocumento_EndPrint)

        'DEFINE O OBJETO PARA INICIALIZAR A IMPRESSAO:
        Dim ObjPrintPreview As New PrintPreviewDialog
        'Try
        'DEFINE PROPRIEDADE DO PRINT VIEW:
        With ObjPrintPreview
            .Document = ObjImprimirDocumento
            .WindowState = FormWindowState.Maximized
            .Document.DefaultPageSettings.Landscape = False
            .PrintPreviewControl.Zoom = 1
            .Text = "Protocolo"
            ' Seta o estilo visual
            CType(.Controls(1), ToolStrip).RenderMode = ToolStripRenderMode.Professional
            CType(.Controls(1), ToolStrip).GripStyle = ToolStripGripStyle.Visible
            CType(.Controls(1), ToolStrip).Height = 25
            .ShowDialog()
        End With
        'Catch ex As Exception
        'MessageBox.Show(ex.ToString())
        'End Try

    End Sub

    Private Sub ImprimirDocumento_Imprimir(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs)

        Dim PaginaAtual As Short = 1
        Dim TituloRelatorio As String = "Protocolo"

        'Variaveis das linhas
        Dim LinhasPorPagina As Single = 0
        Dim PosicaoDaLinha As Single = 0
        Dim LinhaAtual As Integer = 0

        'Variaveis das margens
        Dim MargemEsquerda As Single = e.MarginBounds.Left - 50
        Dim MargemSuperior As Single = e.MarginBounds.Top + 50
        Dim MargemDireita As Single = e.MarginBounds.Right
        Dim MargemInferior As Single = e.MarginBounds.Bottom
        Dim CanetaDaImpressora As Pen = New Pen(Color.Black, 1)

        'Variaveis das fontes
        Dim FonteNegrito As New Font("Courier New", 9, FontStyle.Bold)
        Dim FonteTitulo As New Font("Courier New", 14, FontStyle.Bold)
        Dim FonteSubTitulo As New Font("Courier New", 12, FontStyle.Bold)
        Dim FonteRodape As New Font("Courier New", 8, FontStyle.Regular)
        Dim FonteNormal As New Font("Courier New", 9, FontStyle.Regular)

        'define valores para linha atual e para linha da impressao
        LinhaAtual = 0

        'NOME DA EMPRESA
        e.Graphics.DrawLine(CanetaDaImpressora, MargemEsquerda, 40, MargemDireita, 40)
        e.Graphics.DrawString("Prefeitura de Sorocaba", FonteSubTitulo, Brushes.Black, EncontraCentroPagina(e.PageBounds.Width, Len("Prefeitura de Sorocaba"), FonteSubTitulo.Size), 45)
        e.Graphics.DrawString("Secretaria de Recursos Humanos", FonteSubTitulo, Brushes.Black, EncontraCentroPagina(e.PageBounds.Width, Len("Secretaria de Recursos Humanos"), FonteSubTitulo.Size), 65)

        'TITULO DO RELATORIO
        e.Graphics.DrawString(TituloRelatorio, FonteTitulo, Brushes.Black, EncontraCentroPagina(e.PageBounds.Width, Len(TituloRelatorio), FonteTitulo.Size), 95)
        e.Graphics.DrawLine(CanetaDaImpressora, MargemEsquerda, 125, MargemDireita, 125)

        LinhasPorPagina = CInt(e.MarginBounds.Height / FonteNormal.GetHeight(e.Graphics) - 9)
        PosicaoDaLinha = MargemSuperior + (LinhaAtual * FonteNormal.GetHeight(e.Graphics))


        e.Graphics.DrawString("Destinatário: " & ObjEstrDestinat(DestinatarioAux).Nome, FonteSubTitulo, Brushes.Black, MargemEsquerda, PosicaoDaLinha)
        LinhaAtual += 2
        'LINHA ABAIXO: LINHA_ATUAL + 7 PARA GARANTIR QUE A PROXIMA MENSAGEM VAI CABER NA PÁGINA ATUAL
        While ((LinhaAtual + 7) < LinhasPorPagina AndAlso MensagensAux <= (ObjEstrDestinat(DestinatarioAux).MensagemImpr.Length - 1))
            PosicaoDaLinha = MargemSuperior + (LinhaAtual * FonteNormal.GetHeight(e.Graphics))
            e.Graphics.DrawString(ObjEstrDestinat(DestinatarioAux).MensagemImpr(MensagensAux), FonteNormal, Brushes.Black, MargemEsquerda, PosicaoDaLinha)
            LinhaAtual += 8
            MensagensAux += 1
        End While
        If MensagensAux > (ObjEstrDestinat(DestinatarioAux).MensagemImpr.Length - 1) Then
            DestinatarioAux += 1 'INCREMENTA DESTINATARIO QUANDO ACABAREM AS MENSAGENS
            MensagensAux = 1
            PaginaAtual = 1
        End If

        'Rodape
        e.Graphics.DrawLine(CanetaDaImpressora, MargemEsquerda, MargemInferior, MargemDireita, MargemInferior)
        e.Graphics.DrawString(System.DateTime.Now.ToString(), FonteRodape, Brushes.Black, MargemEsquerda, MargemInferior)
        LinhaAtual += CInt(FonteNormal.GetHeight(e.Graphics))
        LinhaAtual += 1
        e.Graphics.DrawString("Página : " & PaginaAtual, FonteRodape, Brushes.Black, MargemDireita - 70, MargemInferior)
        LinhaAtual += 1
        e.Graphics.DrawString("Recebido por: _______________________, em ___/___/_____.", FonteNegrito, Brushes.Black, MargemEsquerda, MargemInferior + 35)

        If DestinatarioAux <= (ObjEstrDestinat.Length - 1) Then
            e.HasMorePages = True
            PaginaAtual += 1
        Else
            e.HasMorePages = False
        End If

    End Sub

    'Private Sub PrintDocument1_BeginPrint(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintEventArgs)

    '    PaginaAtual = 1
    '    ObjEstrFuncionario = ObjEstruturas.CarregaEstruturaNomeacoesDetalhadas(ObjEstruturas.CarregaQueryNomeacoesDetalhadas("AND F.MATRICULA IN (" & Matricula & ")", Competencia), Competencia)
    '    ObjEstruturas.CarregaEstruturaNomeacoes(ObjEstrFuncionario, Competencia)
    '    ObjCalculoDecimos.CalculaDecimos(ObjEstrFuncionario, Competencia)

    'End Sub

    Private Sub ImprimirDocumento_EndPrint(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintEventArgs)

        DestinatarioAux = 1

    End Sub

    Function EncontraCentroPagina(ByVal LarguraPagina As Short, ByVal TamanhoTexo As Short, ByVal TamFonte As Short) As Short

        Dim Centro As Double = 0.0
        Dim CoeficienteLetras As Double = 0.862 'COEFICIENTE DE MUDANÇA DO TAMANHO DA FONTE (9 para 10, 10 para 11, 11 para 12.....)
        Dim Significancia = CoeficienteLetras * TamFonte 'REPRESENTA O QUE UMA LETRA SIGNIFICA EM RELAÇÃO À LERGURA DA PAGINA

        Dim NumLetrasLinha As Integer = Round(LarguraPagina / Significancia) 'NÚMERO DE LETRAS COMPORTADAS POR UMA LINHA CONSIDERANDO O TAMANHO DA FONTE
        Dim ProporcaoLetraLargura As Double = LarguraPagina / NumLetrasLinha 'Variavel que determina a proporção de cada letra para cada porção de largura da pagina
        Centro = (LarguraPagina - (TamanhoTexo * ProporcaoLetraLargura)) / 2
        Return Centro

    End Function

    Function RetornaMensagemMontada(ByVal StrOrigem As String, ByVal CodDestinat As Integer, ByVal StrDestinatario As String, ByVal CodInteressado As Integer, ByVal StrInteressado As String, ByVal DataEntrada As Date, ByVal DataSaida As Date, ByVal StrProcedencia As String, ByVal StrAssunto As String, ByVal StrTipoDoc As String, ByVal NumDoc As String, ByVal AnoDoc As String, ByVal StrObservacao As String, ByVal DataInclusao As Date, ByVal HoraInclusao As String) As String

        Dim Mensagem As String = "De: " & StrOrigem & "(" & DataEntrada & ")  Para: " & CodDestinat & " - " & StrDestinatario & "(" & DataSaida & ")" & vbNewLine & _
                                 "Interessado: " & CodInteressado & " - " & StrInteressado & vbNewLine & _
                                 "Procedência: " & StrProcedencia & "  Assunto: " & StrAssunto & vbNewLine & _
                                 "Documento: " & StrTipoDoc & "  Nº: " & NumDoc & "/" & AnoDoc & vbNewLine & _
                                 "Observação: " & StrObservacao & vbNewLine & _
                                 "Data e hora do cadastro: " & DataInclusao & " - " & HoraInclusao & _
                                 vbNewLine & vbNewLine 'PULA LINHA, CASO HAJA OUTROS DOCUMENTOS PARA O MESMO DESTINATARIO
        Return Mensagem

    End Function

    Sub GerarRelatorioXLS(ByRef ObjDatagridView As DataGridView, ByVal Diretorio As String, ByVal NomeArquivo As String)

        Dim MSExcelApp As New Excel.Application
        Dim PastaDeTrabalho As Excel.Workbook = MSExcelApp.Workbooks.Add
        Dim Planilha As Excel.Worksheet = PastaDeTrabalho.ActiveSheet
        Dim lin, col As Short

        With Planilha.Application
            'ESCREVE CABEÇALHO:
            For col = 0 To (ObjDatagridView.Columns.Count - 1)
                .Cells(1, col + 1) = ObjDatagridView.Columns(col).Name
            Next col
            'ESCREVE DADOS:
            For lin = 0 To (ObjDatagridView.Rows.Count - 1)
                For col = 0 To (ObjDatagridView.Columns.Count - 1)
                    .Cells(lin + 2, col + 1) = ObjDatagridView.Rows(lin).Cells(col).Value.ToString
                Next col
            Next lin
        End With
        PastaDeTrabalho.SaveAs(Diretorio & NomeArquivo & ".xls", Excel.XlFileFormat.xlWorkbookNormal)
        PastaDeTrabalho.Close()
        MSExcelApp.Quit()

    End Sub

    Public Sub GerarRelatorioXLS(ByRef Comando As FBCOMMAND, ByVal Diretorio As String, ByVal NomeArquivo As String)

        Dim TABELA As New DataTable()
        Dim DataAdapter As New fbDataAdapter(Comando)
        Dim MSExcelApp As New Excel.Application
        Dim PastaDeTrabalho As Excel.Workbook = MSExcelApp.Workbooks.Add
        Dim Planilha As Excel.Worksheet = PastaDeTrabalho.ActiveSheet
        Dim lin, col As Short

        DataAdapter.Fill(TABELA)

        Dim TotalRegistros As Integer = TABELA.Rows.Count

        With Planilha.Application
            'ESCREVE CABEÇALHO:
            For col = 0 To (TABELA.Columns.Count - 1)
                .Cells(1, col + 1) = TABELA.Columns.Item(col).Caption
            Next col

            'ESCREVE DADOS:
            For lin = 0 To (TABELA.Rows.Count - 1)
                For col = 0 To (TABELA.Columns.Count - 1)
                    If ((Not IsDBNull(TABELA.Rows(lin).Item(col))) = True) Then
                        .Cells(lin + 2, col + 1) = TABELA.Rows(lin).Item(col).ToString
                    Else
                        .Cells(lin + 2, col + 1) = String.Empty
                    End If
                    'ObjMetodosGlobais.AtualizaProgressBar(FormRelBatidas.ProgressBar1, lin, TotalRegistros)                    
                Next col
            Next lin
        End With
        PastaDeTrabalho.SaveAs(Diretorio & NomeArquivo & ".xls", Excel.XlFileFormat.xlWorkbookNormal)
        PastaDeTrabalho.Close()
        MSExcelApp.Quit()
        TABELA.Dispose()

    End Sub

    Sub GerarRelatorioTXT(ByRef ObjDatagridView As DataGridView, ByVal Diretorio As String, ByVal NomeArquivo As String)

        Dim Escritor As StreamWriter = File.CreateText(Diretorio & NomeArquivo & ".txt")
        Dim i, j As Short

        With Escritor
            'ESCREVE CABEÇALHO:
            For i = 0 To (ObjDatagridView.Columns.Count - 1)
                .Write((ObjDatagridView.Columns(i).Name & ";"))
            Next i
            .Write(vbNewLine)
            'ESCREVE DADOS:
            For i = 0 To (ObjDatagridView.Rows.Count - 1)
                For j = 0 To (ObjDatagridView.Columns.Count - 1)
                    .Write((ObjDatagridView.Rows(i).Cells(j).Value.ToString & ";"))
                Next j
                .Write(vbNewLine)
            Next i
        End With
        Escritor.Close()

    End Sub

    Public Sub GerarRelatorioTXT(ByRef Comando As FbCommand, ByVal Diretorio As String, ByVal NomeArquivo As String)

        Dim TABELA As New DataTable()
        Dim DataAdapter As New fbDataAdapter(Comando)
        Dim Escritor As StreamWriter = File.CreateText(Diretorio & NomeArquivo & ".txt")
        Dim lin, col As Short
        DataAdapter.Fill(TABELA)

        Dim TotalRegistros As Integer = TABELA.Rows.Count

        With Escritor
            'ESCREVE CABEÇALHO:
            For col = 0 To (TABELA.Columns.Count - 1)
                .Write(TABELA.Columns.Item(col).Caption & ";")
            Next col
            .Write(vbNewLine)

            'ESCREVE DADOS:
            For lin = 0 To (TABELA.Rows.Count - 1)
                For col = 0 To (TABELA.Columns.Count - 1)
                    If ((Not IsDBNull(TABELA.Rows(lin).Item(col))) = True) Then
                        .Write(TABELA.Rows(lin).Item(col).ToString & ";")
                    Else
                        .Write(String.Empty)
                    End If
                Next col
                .Write(vbNewLine)
            Next lin
        End With
        TABELA.Dispose()
        Escritor.Close()

    End Sub

End Class
