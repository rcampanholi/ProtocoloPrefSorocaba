﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormAlterarSenha
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormAlterarSenha))
        Me.CmdSair = New System.Windows.Forms.Button
        Me.CmdSalvar = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.TxtConfirmSenhaNova = New System.Windows.Forms.TextBox
        Me.TxtSenhaNova = New System.Windows.Forms.TextBox
        Me.TxtSenhaAntiga = New System.Windows.Forms.TextBox
        Me.TxtNomeUser = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'CmdSair
        '
        Me.CmdSair.Location = New System.Drawing.Point(192, 233)
        Me.CmdSair.Name = "CmdSair"
        Me.CmdSair.Size = New System.Drawing.Size(75, 23)
        Me.CmdSair.TabIndex = 5
        Me.CmdSair.Text = "Sair"
        Me.CmdSair.UseVisualStyleBackColor = True
        '
        'CmdSalvar
        '
        Me.CmdSalvar.Location = New System.Drawing.Point(111, 233)
        Me.CmdSalvar.Name = "CmdSalvar"
        Me.CmdSalvar.Size = New System.Drawing.Size(75, 23)
        Me.CmdSalvar.TabIndex = 4
        Me.CmdSalvar.Text = "Salvar"
        Me.CmdSalvar.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TxtConfirmSenhaNova)
        Me.GroupBox1.Controls.Add(Me.TxtSenhaNova)
        Me.GroupBox1.Controls.Add(Me.TxtSenhaAntiga)
        Me.GroupBox1.Controls.Add(Me.TxtNomeUser)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(255, 215)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Informe os Dados"
        '
        'TxtConfirmSenhaNova
        '
        Me.TxtConfirmSenhaNova.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtConfirmSenhaNova.Location = New System.Drawing.Point(6, 184)
        Me.TxtConfirmSenhaNova.MaxLength = 40
        Me.TxtConfirmSenhaNova.Name = "TxtConfirmSenhaNova"
        Me.TxtConfirmSenhaNova.Size = New System.Drawing.Size(243, 20)
        Me.TxtConfirmSenhaNova.TabIndex = 7
        Me.TxtConfirmSenhaNova.UseSystemPasswordChar = True
        '
        'TxtSenhaNova
        '
        Me.TxtSenhaNova.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtSenhaNova.Location = New System.Drawing.Point(6, 133)
        Me.TxtSenhaNova.MaxLength = 40
        Me.TxtSenhaNova.Name = "TxtSenhaNova"
        Me.TxtSenhaNova.Size = New System.Drawing.Size(243, 20)
        Me.TxtSenhaNova.TabIndex = 6
        Me.TxtSenhaNova.UseSystemPasswordChar = True
        '
        'TxtSenhaAntiga
        '
        Me.TxtSenhaAntiga.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtSenhaAntiga.Location = New System.Drawing.Point(6, 82)
        Me.TxtSenhaAntiga.MaxLength = 40
        Me.TxtSenhaAntiga.Name = "TxtSenhaAntiga"
        Me.TxtSenhaAntiga.Size = New System.Drawing.Size(243, 20)
        Me.TxtSenhaAntiga.TabIndex = 5
        Me.TxtSenhaAntiga.UseSystemPasswordChar = True
        '
        'TxtNomeUser
        '
        Me.TxtNomeUser.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtNomeUser.Location = New System.Drawing.Point(6, 35)
        Me.TxtNomeUser.MaxLength = 80
        Me.TxtNomeUser.Name = "TxtNomeUser"
        Me.TxtNomeUser.Size = New System.Drawing.Size(243, 20)
        Me.TxtNomeUser.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(6, 168)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(111, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Corfirmar Senha Nova"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(6, 117)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(67, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Senha Nova"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(6, 66)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Senha Antiga"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(6, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(89, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nome de Usuário"
        '
        'FormAlterarSenha
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(280, 266)
        Me.Controls.Add(Me.CmdSair)
        Me.Controls.Add(Me.CmdSalvar)
        Me.Controls.Add(Me.GroupBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Name = "FormAlterarSenha"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Alterar Senha"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents CmdSair As System.Windows.Forms.Button
    Friend WithEvents CmdSalvar As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TxtConfirmSenhaNova As System.Windows.Forms.TextBox
    Friend WithEvents TxtSenhaNova As System.Windows.Forms.TextBox
    Friend WithEvents TxtSenhaAntiga As System.Windows.Forms.TextBox
    Friend WithEvents TxtNomeUser As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
