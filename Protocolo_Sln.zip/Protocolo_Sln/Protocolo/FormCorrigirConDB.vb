﻿Public Class FormCorrigirConDB

    Dim ObjConexaoBanco As New ClassConexaoBanco

    Private Sub FormCorrigirConDB_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

        LblLocalInstalacao.Text = My.Application.Info.DirectoryPath
        If (ObjConexaoBanco.LeArqCaminhoBanco = String.Empty) Then
            LblLocalAtualDB.Text = "Nenhum"
        Else
            LblLocalAtualDB.Text = ObjConexaoBanco.LeArqCaminhoBanco
        End If

    End Sub

    Private Sub CmdEspecCaminDB_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdEspecCaminDB.Click

        Me.OpenFileDialog1.FileName = String.Empty
        If Me.OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.Cancel Then
            Exit Sub
        End If

        ObjConexaoBanco.EspecificaCaminhoDB(Me.OpenFileDialog1.FileName)
        FormCorrigirConDB_Load(Nothing, Nothing)

    End Sub

    Private Sub CmdSair_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdSair.Click

        End

    End Sub

End Class