﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormImportacoes
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormImportacoes))
        Me.Label3 = New System.Windows.Forms.Label()
        Me.CmdIndicarCaminhoArq = New System.Windows.Forms.Button()
        Me.TxtCaminhoArq = New System.Windows.Forms.TextBox()
        Me.CmdSair = New System.Windows.Forms.Button()
        Me.CmdImportar = New System.Windows.Forms.Button()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.LblInformacao = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SuspendLayout()
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(12, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(351, 13)
        Me.Label3.TabIndex = 23
        Me.Label3.Text = "Arquivo para Importação (Codigo e Descricao separado por "","" - vírgula):"
        '
        'CmdIndicarCaminhoArq
        '
        Me.CmdIndicarCaminhoArq.Location = New System.Drawing.Point(825, 27)
        Me.CmdIndicarCaminhoArq.Name = "CmdIndicarCaminhoArq"
        Me.CmdIndicarCaminhoArq.Size = New System.Drawing.Size(31, 21)
        Me.CmdIndicarCaminhoArq.TabIndex = 17
        Me.CmdIndicarCaminhoArq.Text = "..."
        Me.CmdIndicarCaminhoArq.UseVisualStyleBackColor = True
        '
        'TxtCaminhoArq
        '
        Me.TxtCaminhoArq.Location = New System.Drawing.Point(12, 28)
        Me.TxtCaminhoArq.Name = "TxtCaminhoArq"
        Me.TxtCaminhoArq.Size = New System.Drawing.Size(807, 20)
        Me.TxtCaminhoArq.TabIndex = 16
        '
        'CmdSair
        '
        Me.CmdSair.Location = New System.Drawing.Point(781, 117)
        Me.CmdSair.Name = "CmdSair"
        Me.CmdSair.Size = New System.Drawing.Size(75, 23)
        Me.CmdSair.TabIndex = 19
        Me.CmdSair.Text = "Sair"
        Me.CmdSair.UseVisualStyleBackColor = True
        '
        'CmdImportar
        '
        Me.CmdImportar.Enabled = False
        Me.CmdImportar.Location = New System.Drawing.Point(700, 117)
        Me.CmdImportar.Name = "CmdImportar"
        Me.CmdImportar.Size = New System.Drawing.Size(75, 23)
        Me.CmdImportar.TabIndex = 18
        Me.CmdImportar.Text = "Importar"
        Me.CmdImportar.UseVisualStyleBackColor = True
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(12, 87)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(844, 18)
        Me.ProgressBar1.TabIndex = 21
        '
        'LblInformacao
        '
        Me.LblInformacao.AutoSize = True
        Me.LblInformacao.Location = New System.Drawing.Point(9, 71)
        Me.LblInformacao.Name = "LblInformacao"
        Me.LblInformacao.Size = New System.Drawing.Size(247, 13)
        Me.LblInformacao.TabIndex = 20
        Me.LblInformacao.Text = "Clique no botão 'Importar' para iniciar a importação."
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'FormImportacoes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(868, 156)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.CmdIndicarCaminhoArq)
        Me.Controls.Add(Me.TxtCaminhoArq)
        Me.Controls.Add(Me.CmdSair)
        Me.Controls.Add(Me.CmdImportar)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.LblInformacao)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FormImportacoes"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Importar Interessados"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents CmdIndicarCaminhoArq As System.Windows.Forms.Button
    Friend WithEvents TxtCaminhoArq As System.Windows.Forms.TextBox
    Friend WithEvents CmdSair As System.Windows.Forms.Button
    Friend WithEvents CmdImportar As System.Windows.Forms.Button
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents LblInformacao As System.Windows.Forms.Label
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
End Class
