﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormUsuarios
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormUsuarios))
        Me.CmdCancel = New System.Windows.Forms.Button()
        Me.CmdSalvar = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.TxtEncontraNomeUser = New System.Windows.Forms.TextBox()
        Me.TxtEncontraNomeFunc = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.ChkExcluir = New System.Windows.Forms.CheckBox()
        Me.ChkAlterar = New System.Windows.Forms.CheckBox()
        Me.ChkIncluir = New System.Windows.Forms.CheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.OptNao = New System.Windows.Forms.RadioButton()
        Me.OptSim = New System.Windows.Forms.RadioButton()
        Me.TxtConfirmSenha = New System.Windows.Forms.TextBox()
        Me.TxtSenha = New System.Windows.Forms.TextBox()
        Me.TxtNomeUser = New System.Windows.Forms.TextBox()
        Me.TxtNomeFunc = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CmdSair = New System.Windows.Forms.Button()
        Me.CmdExcluir = New System.Windows.Forms.Button()
        Me.CmdAlterar = New System.Windows.Forms.Button()
        Me.CmdNovo = New System.Windows.Forms.Button()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'CmdCancel
        '
        Me.CmdCancel.Enabled = False
        Me.CmdCancel.Location = New System.Drawing.Point(600, 456)
        Me.CmdCancel.Name = "CmdCancel"
        Me.CmdCancel.Size = New System.Drawing.Size(75, 23)
        Me.CmdCancel.TabIndex = 28
        Me.CmdCancel.Text = "Cancelar"
        Me.CmdCancel.UseVisualStyleBackColor = True
        '
        'CmdSalvar
        '
        Me.CmdSalvar.Enabled = False
        Me.CmdSalvar.Location = New System.Drawing.Point(519, 456)
        Me.CmdSalvar.Name = "CmdSalvar"
        Me.CmdSalvar.Size = New System.Drawing.Size(75, 23)
        Me.CmdSalvar.TabIndex = 27
        Me.CmdSalvar.Text = "Salvar"
        Me.CmdSalvar.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.GroupBox4)
        Me.GroupBox3.Controls.Add(Me.DataGridView1)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.GroupBox3.Location = New System.Drawing.Point(12, 199)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(662, 250)
        Me.GroupBox3.TabIndex = 26
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Usuários Cadastrados"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.TxtEncontraNomeUser)
        Me.GroupBox4.Controls.Add(Me.TxtEncontraNomeFunc)
        Me.GroupBox4.Controls.Add(Me.Label6)
        Me.GroupBox4.Controls.Add(Me.Label5)
        Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(7, 175)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(649, 69)
        Me.GroupBox4.TabIndex = 16
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Localizar"
        '
        'TxtEncontraNomeUser
        '
        Me.TxtEncontraNomeUser.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TxtEncontraNomeUser.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtEncontraNomeUser.Location = New System.Drawing.Point(389, 37)
        Me.TxtEncontraNomeUser.MaxLength = 60
        Me.TxtEncontraNomeUser.Name = "TxtEncontraNomeUser"
        Me.TxtEncontraNomeUser.Size = New System.Drawing.Size(254, 20)
        Me.TxtEncontraNomeUser.TabIndex = 18
        '
        'TxtEncontraNomeFunc
        '
        Me.TxtEncontraNomeFunc.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TxtEncontraNomeFunc.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtEncontraNomeFunc.Location = New System.Drawing.Point(7, 37)
        Me.TxtEncontraNomeFunc.MaxLength = 80
        Me.TxtEncontraNomeFunc.Name = "TxtEncontraNomeFunc"
        Me.TxtEncontraNomeFunc.Size = New System.Drawing.Size(376, 20)
        Me.TxtEncontraNomeFunc.TabIndex = 17
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(386, 20)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(89, 13)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Nome de Usuário"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(7, 20)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(108, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Nome do Funcionário"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonFace
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.Location = New System.Drawing.Point(6, 19)
        Me.DataGridView1.MultiSelect = False
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridView1.RowHeadersWidth = 32
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGridView1.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridView1.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridView1.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(650, 150)
        Me.DataGridView1.StandardTab = True
        Me.DataGridView1.TabIndex = 15
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.GroupBox5)
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Controls.Add(Me.TxtConfirmSenha)
        Me.GroupBox1.Controls.Add(Me.TxtSenha)
        Me.GroupBox1.Controls.Add(Me.TxtNomeUser)
        Me.GroupBox1.Controls.Add(Me.TxtNomeFunc)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.GroupBox1.Location = New System.Drawing.Point(12, 75)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(662, 118)
        Me.GroupBox1.TabIndex = 25
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Dados do Usuário"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.ChkExcluir)
        Me.GroupBox5.Controls.Add(Me.ChkAlterar)
        Me.GroupBox5.Controls.Add(Me.ChkIncluir)
        Me.GroupBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(454, 67)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(202, 37)
        Me.GroupBox5.TabIndex = 11
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Permissões"
        '
        'ChkExcluir
        '
        Me.ChkExcluir.AutoSize = True
        Me.ChkExcluir.Enabled = False
        Me.ChkExcluir.Location = New System.Drawing.Point(132, 18)
        Me.ChkExcluir.Name = "ChkExcluir"
        Me.ChkExcluir.Size = New System.Drawing.Size(57, 17)
        Me.ChkExcluir.TabIndex = 14
        Me.ChkExcluir.Text = "Excluir"
        Me.ChkExcluir.UseVisualStyleBackColor = True
        '
        'ChkAlterar
        '
        Me.ChkAlterar.AutoSize = True
        Me.ChkAlterar.Enabled = False
        Me.ChkAlterar.Location = New System.Drawing.Point(70, 18)
        Me.ChkAlterar.Name = "ChkAlterar"
        Me.ChkAlterar.Size = New System.Drawing.Size(56, 17)
        Me.ChkAlterar.TabIndex = 13
        Me.ChkAlterar.Text = "Alterar"
        Me.ChkAlterar.UseVisualStyleBackColor = True
        '
        'ChkIncluir
        '
        Me.ChkIncluir.AutoSize = True
        Me.ChkIncluir.Enabled = False
        Me.ChkIncluir.Location = New System.Drawing.Point(6, 18)
        Me.ChkIncluir.Name = "ChkIncluir"
        Me.ChkIncluir.Size = New System.Drawing.Size(54, 17)
        Me.ChkIncluir.TabIndex = 12
        Me.ChkIncluir.Text = "Incluir"
        Me.ChkIncluir.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.OptNao)
        Me.GroupBox2.Controls.Add(Me.OptSim)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(324, 67)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(122, 37)
        Me.GroupBox2.TabIndex = 8
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Administrador"
        '
        'OptNao
        '
        Me.OptNao.AutoSize = True
        Me.OptNao.Enabled = False
        Me.OptNao.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OptNao.Location = New System.Drawing.Point(63, 17)
        Me.OptNao.Name = "OptNao"
        Me.OptNao.Size = New System.Drawing.Size(45, 17)
        Me.OptNao.TabIndex = 10
        Me.OptNao.TabStop = True
        Me.OptNao.Text = "Não"
        Me.OptNao.UseVisualStyleBackColor = True
        '
        'OptSim
        '
        Me.OptSim.AutoSize = True
        Me.OptSim.Enabled = False
        Me.OptSim.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OptSim.Location = New System.Drawing.Point(8, 17)
        Me.OptSim.Name = "OptSim"
        Me.OptSim.Size = New System.Drawing.Size(42, 17)
        Me.OptSim.TabIndex = 9
        Me.OptSim.TabStop = True
        Me.OptSim.Text = "Sim"
        Me.OptSim.UseVisualStyleBackColor = True
        '
        'TxtConfirmSenha
        '
        Me.TxtConfirmSenha.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TxtConfirmSenha.Enabled = False
        Me.TxtConfirmSenha.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtConfirmSenha.Location = New System.Drawing.Point(165, 83)
        Me.TxtConfirmSenha.MaxLength = 20
        Me.TxtConfirmSenha.Name = "TxtConfirmSenha"
        Me.TxtConfirmSenha.Size = New System.Drawing.Size(153, 20)
        Me.TxtConfirmSenha.TabIndex = 7
        Me.TxtConfirmSenha.UseSystemPasswordChar = True
        '
        'TxtSenha
        '
        Me.TxtSenha.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TxtSenha.Enabled = False
        Me.TxtSenha.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtSenha.Location = New System.Drawing.Point(6, 82)
        Me.TxtSenha.MaxLength = 20
        Me.TxtSenha.Name = "TxtSenha"
        Me.TxtSenha.Size = New System.Drawing.Size(153, 20)
        Me.TxtSenha.TabIndex = 6
        Me.TxtSenha.UseSystemPasswordChar = True
        '
        'TxtNomeUser
        '
        Me.TxtNomeUser.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TxtNomeUser.Enabled = False
        Me.TxtNomeUser.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtNomeUser.Location = New System.Drawing.Point(396, 36)
        Me.TxtNomeUser.MaxLength = 60
        Me.TxtNomeUser.Name = "TxtNomeUser"
        Me.TxtNomeUser.Size = New System.Drawing.Size(260, 20)
        Me.TxtNomeUser.TabIndex = 5
        '
        'TxtNomeFunc
        '
        Me.TxtNomeFunc.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TxtNomeFunc.Enabled = False
        Me.TxtNomeFunc.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtNomeFunc.Location = New System.Drawing.Point(6, 36)
        Me.TxtNomeFunc.MaxLength = 80
        Me.TxtNomeFunc.Name = "TxtNomeFunc"
        Me.TxtNomeFunc.Size = New System.Drawing.Size(384, 20)
        Me.TxtNomeFunc.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(162, 67)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(85, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Confirmar Senha"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(6, 66)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Senha"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(393, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Nome de Usuário"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(7, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(108, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nome do Funcionário"
        '
        'CmdSair
        '
        Me.CmdSair.Image = CType(resources.GetObject("CmdSair.Image"), System.Drawing.Image)
        Me.CmdSair.Location = New System.Drawing.Point(177, 12)
        Me.CmdSair.Name = "CmdSair"
        Me.CmdSair.Size = New System.Drawing.Size(49, 57)
        Me.CmdSair.TabIndex = 24
        Me.CmdSair.Text = "Sair"
        Me.CmdSair.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.CmdSair.UseVisualStyleBackColor = True
        '
        'CmdExcluir
        '
        Me.CmdExcluir.Image = CType(resources.GetObject("CmdExcluir.Image"), System.Drawing.Image)
        Me.CmdExcluir.Location = New System.Drawing.Point(122, 12)
        Me.CmdExcluir.Name = "CmdExcluir"
        Me.CmdExcluir.Size = New System.Drawing.Size(49, 57)
        Me.CmdExcluir.TabIndex = 23
        Me.CmdExcluir.Text = "Excluir"
        Me.CmdExcluir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.CmdExcluir.UseVisualStyleBackColor = True
        '
        'CmdAlterar
        '
        Me.CmdAlterar.Image = CType(resources.GetObject("CmdAlterar.Image"), System.Drawing.Image)
        Me.CmdAlterar.Location = New System.Drawing.Point(67, 12)
        Me.CmdAlterar.Name = "CmdAlterar"
        Me.CmdAlterar.Size = New System.Drawing.Size(49, 57)
        Me.CmdAlterar.TabIndex = 22
        Me.CmdAlterar.Text = "Alterar"
        Me.CmdAlterar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.CmdAlterar.UseVisualStyleBackColor = True
        '
        'CmdNovo
        '
        Me.CmdNovo.Image = CType(resources.GetObject("CmdNovo.Image"), System.Drawing.Image)
        Me.CmdNovo.Location = New System.Drawing.Point(12, 12)
        Me.CmdNovo.Name = "CmdNovo"
        Me.CmdNovo.Size = New System.Drawing.Size(49, 57)
        Me.CmdNovo.TabIndex = 21
        Me.CmdNovo.Text = "Novo"
        Me.CmdNovo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.CmdNovo.UseVisualStyleBackColor = True
        '
        'FormUsuarios
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(686, 500)
        Me.Controls.Add(Me.CmdCancel)
        Me.Controls.Add(Me.CmdSalvar)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.CmdSair)
        Me.Controls.Add(Me.CmdExcluir)
        Me.Controls.Add(Me.CmdAlterar)
        Me.Controls.Add(Me.CmdNovo)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Name = "FormUsuarios"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cadastro de Usuários"
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents CmdCancel As System.Windows.Forms.Button
    Friend WithEvents CmdSalvar As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents TxtEncontraNomeUser As System.Windows.Forms.TextBox
    Friend WithEvents TxtEncontraNomeFunc As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents ChkExcluir As System.Windows.Forms.CheckBox
    Friend WithEvents ChkAlterar As System.Windows.Forms.CheckBox
    Friend WithEvents ChkIncluir As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents OptNao As System.Windows.Forms.RadioButton
    Friend WithEvents OptSim As System.Windows.Forms.RadioButton
    Friend WithEvents TxtConfirmSenha As System.Windows.Forms.TextBox
    Friend WithEvents TxtSenha As System.Windows.Forms.TextBox
    Friend WithEvents TxtNomeUser As System.Windows.Forms.TextBox
    Friend WithEvents TxtNomeFunc As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CmdSair As System.Windows.Forms.Button
    Friend WithEvents CmdExcluir As System.Windows.Forms.Button
    Friend WithEvents CmdAlterar As System.Windows.Forms.Button
    Friend WithEvents CmdNovo As System.Windows.Forms.Button
End Class
