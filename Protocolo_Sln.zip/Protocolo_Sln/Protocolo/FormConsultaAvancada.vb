﻿Imports FirebirdSql.Data.FirebirdClient

Public Class FormConsultaAvancada

    Enum TipoPesquisa
        Interessado = 1
        Assunto = 2
        NumDocumento = 3
        NumAnoDocumento = 4
        Agregado = 5
    End Enum

    Dim ObjControles As New ClassControles
    Dim ObjTipoPesquisa As TipoPesquisa = TipoPesquisa.Interessado
    Dim ColunasOcultar() As Short = {0}
    Dim LarguraColunas() As Short = {1, 250, 2, 240, 3, 100, 4, 80, 5, 240, 6, 150}
    Dim LarguraColunasAgregado() As Short = {1, 230, 2, 230, 3, 220, 4, 80, 5, 60, 6, 200, 7, 130}

    Private Sub FormConsultaAvancada_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        AlterarTipoPesquisa()
        Me.TxtPesquisa.Focus()

    End Sub

    Private Sub FormConsultaAvancada_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If e.Alt = False Then
            Select Case e.KeyCode
                Case 113 'F2 - Consultar Registro
                    If Me.DataGridView1.RowCount > 0 Then
                        Me.Hide()
                        FormHistoricos.ObjFormPaiHistoricos = ObjFormPai.ConsultaAvancada
                        FormHistoricos.IdRegistroAtual = Me.DataGridView1.Rows(Me.DataGridView1.CurrentCellAddress.Y).Cells(0).Value
                        FormHistoricos.ObjTipoManutencao = FormHistoricos.TipoManutencao.Consulta
                        FormHistoricos.Show()
                    End If
                Case 114 'F3 - ALTERAR TIPO DE PESQUISA
                    If ObjTipoPesquisa = 5 Then
                        ObjTipoPesquisa = 1
                    Else
                        ObjTipoPesquisa += 1
                    End If
                    Me.AlterarTipoPesquisa()
                    Me.TxtPesquisa.Text = String.Empty
                    Me.TxtPesquisa.Focus()
                    Me.DataGridView1.DataSource = Nothing
                    Me.DataGridView1.Refresh()
                    Me.DataGridView1.Enabled = False
                Case 27 'ESC - SAIR
                    CmdSair_Click(Nothing, Nothing)
            End Select
        End If

    End Sub

    Private Sub AlterarTipoPesquisa()

        With Me
            Select Case ObjTipoPesquisa
                Case 1 'INTERESSADO
                    NegritaTituloDePesquisa(.LblAgregado, LblInteressado)
                Case 2 'ASSUNTO
                    NegritaTituloDePesquisa(.LblInteressado, LblAssunto)
                Case 3 'NºDOCUMENTO
                    NegritaTituloDePesquisa(.LblAssunto, .LblNumDocumento)
                Case 4 'Nº E ANO DOCUMENTO
                    NegritaTituloDePesquisa(.LblNumDocumento, .LblNumAnoDocumento)
                Case 5
                    NegritaTituloDePesquisa(.LblNumAnoDocumento, .LblAgregado)
            End Select
        End With

    End Sub

    Private Sub TxtPesquisa_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtPesquisa.GotFocus

        If Me.TxtPesquisa.Text <> String.Empty Then
            ObjControles.SelecionaTodoTexto(Me.TxtPesquisa)
        End If

    End Sub

    Private Sub TxtPesquisa_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtPesquisa.KeyDown

        If e.KeyCode = Keys.Enter Then
            CmdPesquisa_Click(Nothing, Nothing)
        End If

    End Sub

    Private Sub CmdPesquisa_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdPesquisa.Click

        If CamposInconsistentes() = True Then
            Exit Sub
        End If
        If ObjTipoPesquisa = TipoPesquisa.Agregado Then
            ObjControles.PreencheDataGridView(TextoConsultaAvancadaAgregado, Me.DataGridView1, ClassControles.LinhaDataGridSelecionar.Primeira)
            ObjControles.FormataDataGridView(Me.DataGridView1, ColunasOcultar, LarguraColunasAgregado)
        Else
            ObjControles.PreencheDataGridView(TextoConsultaAvancada(RetornaFiltroPesquisa), Me.DataGridView1, ClassControles.LinhaDataGridSelecionar.Primeira)
            ObjControles.FormataDataGridView(Me.DataGridView1, ColunasOcultar, LarguraColunas)
        End If

        If Me.DataGridView1.RowCount > 0 Then
            Me.DataGridView1.Enabled = True
            Me.DataGridView1.Focus()
        Else
            MessageBox.Show("Nenhum registro encontrado.", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Me.DataGridView1.DataSource = Nothing
            Me.DataGridView1.Enabled = False
            Me.DataGridView1.Refresh()
            Me.TxtPesquisa.Focus()
            ObjControles.SelecionaTodoTexto(Me.TxtPesquisa)
        End If

    End Sub

    Private Sub NegritaTituloDePesquisa(ByRef ObjLabelNormal As Windows.Forms.Label, ByRef ObjLabelNegrito As Windows.Forms.Label)

        ObjLabelNormal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ObjLabelNegrito.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))

    End Sub

    Private Sub CmdSair_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdSair.Click

        Me.Close()
        Me.Dispose()
        FormPrincipal.Show()

    End Sub

    Private Function TextoConsultaAvancada(ByVal StrFiltro As String) As String

        Dim ConsultaSQL As String = "SELECT R.ID_REGISTRO, I.DESCRICAO AS INTERESSADO, R.ASSUNTO, R.NUM_DOC AS " & """Nº DOCUMENTO """ & "," & _
                                        "R.ANO_DOC AS ANO, R.PROCEDENCIA, DC.DESCRICAO AS " & """TIPO DOC""" & " " & _
                                        "FROM REGISTROS R, DOCUMENTOS DC, INTERESSADOS I " & _
                                        "WHERE DC.ID_DOCUMENTO = R.ID_TIPO_DOC " & _
                                        "AND R.ID_INTERESSADO = I.ID_INTERESSADO " & StrFiltro

        Return ConsultaSQL

    End Function

    Private Function TextoConsultaAvancadaAgregado() As String

        Dim ConsultaSQL As String = "SELECT R.ID_REGISTRO, I.DESCRICAO AS " & """INTERESSADO PRINCIPAL """ & ", A.DESCRICAO AS AGREGADO, " & _
                                    "R.ASSUNTO, R.NUM_DOC AS " & """Nº DOCUMENTO """ & "," & _
                                    "R.ANO_DOC AS ANO, R.PROCEDENCIA, DC.DESCRICAO AS " & """TIPO DOC""" & " " & _
                                    "FROM REGISTROS R, DOCUMENTOS DC, INTERESSADOS I, AGREGADOS A " & _
                                    "WHERE DC.ID_DOCUMENTO = R.ID_TIPO_DOC " & _
                                    "AND R.ID_INTERESSADO = I.ID_INTERESSADO " & _
                                    "AND I.ID_INTERESSADO = A.ID_INTERESSADO_PRINCIPAL " & _
                                    "AND R.ID_REGISTRO = A.ID_REGISTRO " & _
                                    "AND A.DESCRICAO LIKE '%" & Me.TxtPesquisa.Text & "%'"

        Return ConsultaSQL

    End Function

    Function RetornaFiltroPesquisa() As String

        Dim StrFiltro As String = String.Empty

        Select Case ObjTipoPesquisa
            Case TipoPesquisa.Interessado
                StrFiltro = "AND I.DESCRICAO LIKE '%" & Me.TxtPesquisa.Text & "%'"
            Case TipoPesquisa.Assunto
                StrFiltro = "and R.id_registro in (" & RetornaIDsPorAssunto() & ")"
            Case TipoPesquisa.NumDocumento
                StrFiltro = "AND R.NUM_DOC LIKE '%" & Me.TxtPesquisa.Text & "%'"
            Case TipoPesquisa.NumAnoDocumento
                Dim NumDocAux As String = String.Empty
                Dim AnoDocAux As String = String.Empty
                NumDocAux = RetornaNumDocumento(Me.TxtPesquisa.Text)
                AnoDocAux = RetornaAnoDocumento(Me.TxtPesquisa.Text)
                StrFiltro = "AND R.NUM_DOC LIKE '%" & NumDocAux & "%' " & _
                            "AND R.ANO_DOC = " & AnoDocAux
        End Select

        Return StrFiltro

    End Function

    Function RetornaIDsPorAssunto() As String

        Dim IDsRegistro As String = String.Empty
        Dim Tabela As FbDataReader
        Dim Comando As New FbCommand(String.Empty, Conexao)

        Comando.CommandText = "SELECT ID_REGISTRO " & _
                              "FROM REGISTROS " & _
                              "WHERE ASSUNTO LIKE '%" & Me.TxtPesquisa.Text & "%'"
        Conexao.Open()
        Tabela = Comando.ExecuteReader

        Do While Tabela.Read
            IDsRegistro &= Tabela(0).ToString & ","
        Loop

        If IDsRegistro <> String.Empty Then
            IDsRegistro = Strings.Left(IDsRegistro, Strings.Len(IDsRegistro) - 1)
        Else
            IDsRegistro = "0"
        End If

        Conexao.Close()

        Return IDsRegistro

    End Function

    Function RetornaNumDocumento(ByVal NumEAnoDocumento As String) As String

        Dim NumDocAux As String = String.Empty

        For i As Short = 1 To Len(NumEAnoDocumento)
            If Mid(NumEAnoDocumento, i, 1) = "/" Then
                Exit For
            End If
            NumDocAux &= Mid(NumEAnoDocumento, i, 1)
        Next

        Return NumDocAux

    End Function

    Function RetornaAnoDocumento(ByVal NumEAnoDocumento As String) As String

        Dim AnoDocAux As String = String.Empty

        For i As Short = Len(NumEAnoDocumento) To 1 Step -1
            If Mid(NumEAnoDocumento, i, 1) = "/" Then
                Exit For
            End If
            AnoDocAux = Mid(NumEAnoDocumento, i, 1) & AnoDocAux
        Next

        Return AnoDocAux

    End Function

    Function CamposInconsistentes() As Boolean

        If Me.TxtPesquisa.Text = String.Empty Then
            Return True
        End If

        If ObjTipoPesquisa = TipoPesquisa.NumAnoDocumento Then
            If Not Me.TxtPesquisa.Text.ToString.Contains("/") Then
                MessageBox.Show("Quando a chave de localização for 'Nº/Ano Documento', o número e ano deverão ser separados pelo caracter '/' (barra).", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information)
                ObjControles.SelecionaTodoTexto(Me.TxtPesquisa)
                Me.TxtPesquisa.Focus()
                Return True
            End If
        End If

    End Function

End Class