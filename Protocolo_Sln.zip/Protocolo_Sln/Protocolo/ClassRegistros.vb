﻿Imports FirebirdSql.Data.FirebirdClient

Public Class ClassRegistros

    ' *** INSERT ***
    Sub IncluiRegistro(ByVal ObjComando As FBCOMMAND)

        Conexao.Open()
        Try
            ObjComando.ExecuteNonQuery()
        Catch Ex As Exception
            MessageBox.Show(Ex.Message)
        End Try
        Conexao.Close()
        ObjComando.Parameters.Clear()

    End Sub

    'UPDATE
    Sub AtualizaRegistro(ByVal ObjComando As FbCommand)

        Conexao.Open()
        Try
            ObjComando.ExecuteNonQuery()
        Catch Ex As Exception
            MessageBox.Show(Ex.Message)
        End Try
        Conexao.Close()
        ObjComando.Parameters.Clear()

    End Sub

    Function RetornaMaxIDRegistro() As Integer

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)
        Dim MaxIDRegistroAux As Integer = 0

        Comando.CommandText = "SELECT MAX(ID_REGISTRO) FROM REGISTROS"
        Conexao.Open()
        MaxIDRegistroAux = Comando.ExecuteScalar
        Conexao.Close()
        Comando.Dispose()

        Return MaxIDRegistroAux

    End Function

    Sub ExcluirHistoricoPorIDRegistro(ByVal IdRegistro As Integer)

        Dim Comando As New FbCommand(String.Empty, Conexao)

        Comando.CommandText = "DELETE FROM HISTORICO_REGISTROS " & _
                              "WHERE ID_REGISTRO = " & IdRegistro

        Conexao.Open()
        Try
            Comando.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        Conexao.Close()

    End Sub


    Sub ExcluirRegistroPorID(ByVal IdRegistro As Integer)

        Dim COMANDO As New FbCommand(String.Empty, Conexao)

        COMANDO.CommandText = "DELETE FROM REGISTROS " & _
                              "WHERE ID_REGISTRO = " & IdRegistro

        Conexao.Open()
        Try
            COMANDO.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        Conexao.Close()

    End Sub

End Class

