﻿Imports FirebirdSql.Data.FirebirdClient

Public Class FormDocumentos

    Dim ObjUsuarios As New ClassUsuarios
    Dim ObjControles As New ClassControles
    Dim ObjDocumentos As New ClassDocumentos
    Dim ColunasOcultar() As Short = {0}
    Dim LarguraColunas() As Short = {1, 85, 2, 290, 3, 80}
    Dim IdDocumento As Integer
    Dim CodDocumentoAux As Integer = 0

    Private Sub FormDocumentos_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ObjControles.PreencheDataGridView(Me.TextoConsultaSQL, Me.DataGridView1, ClassControles.LinhaDataGridSelecionar.Primeira)
        ObjControles.FormataDataGridView(Me.DataGridView1, Me.ColunasOcultar, Me.LarguraColunas)

    End Sub

    Private Sub FormDocumentos_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If e.Alt = False Then
            Select Case e.KeyCode
                Case 27 'ESC - SAIR
                    If Me.CmdSair.Enabled = True Then
                        CmdSair_Click(Nothing, Nothing)
                    End If
            End Select
        End If


        If (e.Control = True) Then
            Dim ObjBotao As New Button
            Select Case e.KeyCode
                Case 65 'A
                    CmdAlterar_Click(Nothing, Nothing)
                Case 78 'N
                    CmdNovo_Click(Nothing, Nothing)
                Case 83 'S
                    CmdSalvar_Click(Nothing, Nothing)
                Case 90 'Z
                    CmdCancel_Click(Nothing, Nothing)
            End Select
        End If

    End Sub

    ' *** SETA O FOCO PARA O GRID AO INICIAR O FORM ***
    Private Sub FormDocumentos_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated

        If (DataGridView1.Enabled = True) Then
            DataGridView1.Focus()
        End If

    End Sub

    'CARREGA CAMPOS, CONFORME USUÁRIO NAVEGAR PELO GRID:
    Private Sub DataGridView1_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGridView1.SelectionChanged

        If DataGridView1.CurrentCellAddress.Y >= 0 Then
            Me.CarregaCampos(Me.DataGridView1.CurrentCellAddress.Y)
        End If

    End Sub

    ' *** NOVO ***
    Public Sub CmdNovo_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdNovo.Click

        If ObjUsuarios.PermiteUsuario(AcaoUsuario.Incluindo) = False Then
            Exit Sub
        End If
        Me.LimpaCampos()
        Me.HabilDesabilGrid(False)
        Me.HabilDesabilCampos(True)
        Me.HabilDesabilBotoesSuperiores(False)
        Me.HabilDesabilBotoesInferiores(True)
        Me.OptNao.Checked = True
        ObjTipoInstrucao = TipoInstrucao.INSERT
        TxtCodDocumento.Focus()

    End Sub

    ' *** ALTERAR ***
    Public Sub CmdAlterar_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdAlterar.Click

        If ObjUsuarios.PermiteUsuario(AcaoUsuario.Alterando) = False Then
            Exit Sub
        End If

        If (Me.DataGridView1.RowCount = 0) Then
            MsgBox("Não há dados a serem alterados.", MsgBoxStyle.Exclamation, "Atenção!")
            Exit Sub
        End If
        IdDocumento = Me.DataGridView1.CurrentRow.Cells(0).Value
        CodDocumentoAux = Me.TxtCodDocumento.Text
        Me.HabilDesabilBotoesSuperiores(False)
        Me.HabilDesabilBotoesInferiores(True)
        Me.HabilDesabilCampos(True)
        Me.HabilDesabilGrid(False)
        ObjTipoInstrucao = TipoInstrucao.UPDATE
        TxtCodDocumento.Focus()

    End Sub

    ' *** SAIR ***
    Private Sub CmdSair_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdSair.Click

        Me.Close()
        Me.Dispose()

    End Sub

    ' *** SALVAR ***
    Private Sub CmdSalvar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdSalvar.Click

        If Me.CamposInconsistentes = True Then
            Exit Sub
        End If
        If ObjTipoInstrucao = TipoInstrucao.INSERT Then
            If ObjDocumentos.CodigoJaExiste(Me.TxtCodDocumento.Text) = True Then
                Me.TxtCodDocumento.Focus()
                Exit Sub
            End If
        ElseIf ObjTipoInstrucao = TipoInstrucao.UPDATE Then
            If CodDocumentoAux <> Me.TxtCodDocumento.Text Then 'HOUVE ALTERAÇÃO DO CÓDIGO
                If ObjDocumentos.CodigoJaExiste(Me.TxtCodDocumento.Text, IdDocumento) = True Then
                    Me.TxtCodDocumento.Focus()
                    Exit Sub
                End If
            End If
        End If

        If ObjTipoInstrucao = TipoInstrucao.INSERT Then 'INSERT
            ObjDocumentos.IncluiDocumento(Me.ComandoInclusao)
            ObjControles.PreencheDataGridView(Me.TextoConsultaSQL, Me.DataGridView1, ClassControles.LinhaDataGridSelecionar.Primeira)
            ObjControles.FormataDataGridView(Me.DataGridView1, Me.ColunasOcultar, Me.LarguraColunas)
            'PROCURA ID INSERIDO PARA SETAR NO GRID:
            Dim LinhaSelecionada As Integer = ObjControles.EncontraPosicaoRegistroDataGrid(Me.DataGridView1, Me.TxtCodDocumento.Text, 1)
            Me.DataGridView1.CurrentCell = Me.DataGridView1.Rows(LinhaSelecionada).Cells(1)
            Me.CarregaCampos(LinhaSelecionada)
        ElseIf ObjTipoInstrucao = TipoInstrucao.UPDATE Then 'UPDATE
            ObjDocumentos.AtualizaDocumento(Me.ComandoAtualizacao)
            ObjControles.PreencheDataGridView(Me.TextoConsultaSQL, Me.DataGridView1, ClassControles.LinhaDataGridSelecionar.Primeira)
            ObjControles.FormataDataGridView(Me.DataGridView1, Me.ColunasOcultar, Me.LarguraColunas)
            Dim LinhaSelecionada As Integer = ObjControles.EncontraPosicaoRegistroDataGrid(Me.DataGridView1, IdDocumento, 0)
            Me.DataGridView1.CurrentCell = Me.DataGridView1.Rows(LinhaSelecionada).Cells(1)
            Me.CarregaCampos(LinhaSelecionada)
        End If

        Me.HabilDesabilBotoesInferiores(False)
        Me.HabilDesabilBotoesSuperiores(True)
        Me.HabilDesabilGrid(True)
        Me.HabilDesabilCampos(False)
        Me.DataGridView1.Focus()

    End Sub

    ' *** CANCELAR ***
    Public Sub CmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdCancel.Click

        Me.HabilDesabilCampos(False)
        Me.HabilDesabilGrid(True)
        Me.HabilDesabilBotoesSuperiores(True)
        Me.HabilDesabilBotoesInferiores(False)
        Me.CarregaCampos(Me.DataGridView1.CurrentCellAddress.Y)
        DataGridView1.Focus()

    End Sub

    Sub LimpaCampos()

        With Me
            .TxtCodDocumento.Text = String.Empty
            .TxtDescrDocumento.Text = String.Empty
            .OptSim.Checked = False
            .OptNao.Checked = False
        End With

    End Sub

    Sub HabilDesabilCampos(ByVal Acao As Boolean)

        With Me
            .TxtCodDocumento.Enabled = Acao
            .TxtDescrDocumento.Enabled = Acao
            .OptSim.Enabled = Acao
            .OptNao.Enabled = Acao
        End With

    End Sub

    Sub HabilDesabilGrid(ByVal Acao As Boolean)

        With Me
            .DataGridView1.Enabled = Acao
        End With

    End Sub

    Sub HabilDesabilBotoesSuperiores(ByVal Acao As Boolean)

        With Me
            .CmdNovo.Enabled = Acao
            .CmdAlterar.Enabled = Acao
            .CmdSair.Enabled = Acao
        End With

    End Sub

    Sub HabilDesabilBotoesInferiores(ByVal Acao As Boolean)

        With Me
            .CmdSalvar.Enabled = Acao
            .CmdCancel.Enabled = Acao
        End With

    End Sub

    Function CamposInconsistentes() As Boolean

        With Me
            'CAMPO CÓDIGO:
            If (.TxtCodDocumento.Text = String.Empty) Then
                MessageBox.Show("Todos os campos devem ser preenchidos.", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                .TxtCodDocumento.Focus()
                Return True
            ElseIf Not IsNumeric(.TxtCodDocumento.Text) = True Then
                MsgBox("O campo 'Código' aceita somente números.", MsgBoxStyle.Exclamation, "Atenção!")
                .TxtCodDocumento.Focus()
                Return True
            End If

            'CAMPO DESCRIÇÃO:
            If (.TxtDescrDocumento.Text = String.Empty) Then
                MsgBox("Todos os campos devem ser preenchidos.", MsgBoxStyle.Exclamation, "Atenção!")
                .TxtDescrDocumento.Focus()
                Return True
            End If

            'CAMPO UTILIZA Nº E ANO
            If (.OptSim.Checked = False) And (.OptNao.Checked = False) Then
                MsgBox("Todos os campos devem ser preenchidos.", MsgBoxStyle.Exclamation, "Atenção!")
                .OptNao.Focus()
                Return True
            End If
        End With

    End Function

    Function TextoConsultaSQL() As String

        Dim ComandoSQL As String = "SELECT ID_DOCUMENTO, CODIGO, DESCRICAO, " & _
            "CASE WHEN UTILIZA_NUM_ANO = 0 " & _
            "THEN 'NÃO' " & _
            "ELSE 'SIM' " & _
            "END AS "" Nº E ANO """ & _
            "FROM DOCUMENTOS " & _
            "ORDER BY DESCRICAO "
        Return ComandoSQL

    End Function

    Sub CarregaCampos(ByRef linha As Integer)

        With Me
            If (.DataGridView1.RowCount > 0) Then
                .TxtCodDocumento.Text = Format(.DataGridView1.Rows(linha).Cells(1).Value, "0000") 'CÓDIGO
                .TxtDescrDocumento.Text = .DataGridView1.Rows(linha).Cells(2).Value 'DESCRIÇÃO
                If (.DataGridView1.Rows(linha).Cells(3).Value = "NÃO") Then 'UTILIZA NÚM. E ANO
                    .OptNao.Checked = True
                Else
                    .OptSim.Checked = True
                End If
            End If
        End With

    End Sub

    Function ComandoInclusao() As FbCommand



        Dim UtilizaNumEAno As Short = 0
        Dim Comando As New FbCommand(String.Empty, Conexao)

        With Me
            If .OptSim.Checked = True Then
                UtilizaNumEAno = 1
            End If
            Comando.CommandText = "INSERT INTO DOCUMENTOS(CODIGO, DESCRICAO, UTILIZA_NUM_ANO) VALUES (?, ?, ?) "
            Comando.Parameters.Add(String.Empty, FbDbType.Integer)
            Comando.Parameters(0).Value = .TxtCodDocumento.Text
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar)
            Comando.Parameters(1).Value = .TxtDescrDocumento.Text
            Comando.Parameters.Add(String.Empty, FbDbType.SmallInt)
            Comando.Parameters(2).Value = UtilizaNumEAno
        End With

        Return Comando

    End Function

    Function ComandoAtualizacao() As FbCommand

        Dim UtilizaNumEAno As Short = 0
        Dim Comando As New FbCommand(String.Empty, Conexao)

        With Me
            If .OptSim.Checked = True Then
                UtilizaNumEAno = 1
            End If
            Comando.CommandText = "UPDATE DOCUMENTOS SET CODIGO = ?, DESCRICAO = ?, UTILIZA_NUM_ANO = ? " & _
                                  "WHERE ID_DOCUMENTO = " & IdDocumento
            Comando.Parameters.Add(String.Empty, FbDbType.Integer)
            Comando.Parameters(0).Value = .TxtCodDocumento.Text
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar)
            Comando.Parameters(1).Value = .TxtDescrDocumento.Text
            Comando.Parameters.Add(String.Empty, FbDbType.SmallInt)
            Comando.Parameters(2).Value = UtilizaNumEAno
        End With

        Return Comando

    End Function

End Class