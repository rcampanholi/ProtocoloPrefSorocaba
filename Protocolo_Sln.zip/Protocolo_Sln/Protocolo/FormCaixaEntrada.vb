﻿Public Class FormCaixaEntrada

    Dim ObjControles As New ClassControles
    Public ColunasOcultarRegistros() As Short = {0}
    Public LarguraColunasRegistros() As Short = {1, 180, 2, 40, 3, 50, 4, 180, 5, 150, 6, 130, 7, 70, 8, 140, 9, 70, 10, 140, 11, 50}
    Public LinhaSelecionadaDataGrid As Integer = 0

    Private Sub FormCaixaEntrada_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim ObjUsuarios As New ClassUsuarios

        Me.LblUsuario.Text = "Usuário: " & ObjUsuarios.RetornaNomeUsuario(ObjEstrUsuario.IDUsuario)
        ObjControles.PreencheDataGridView(Me.TextoConsultaSQLRegistros, Me.DataGridRegistros, ClassControles.LinhaDataGridSelecionar.Primeira)
        ObjControles.FormataDataGridView(Me.DataGridRegistros, Me.ColunasOcultarRegistros, Me.LarguraColunasRegistros)
        ObjControles.ColoreCelulasGridView(Me.DataGridRegistros, 11, 1, 3)
        Me.LblQtRegistros.Text = "Registros em sua caixa: " & Me.DataGridRegistros.RowCount

        If Me.DataGridRegistros.Enabled = True Then
            Me.DataGridRegistros.Focus()
        End If

    End Sub

    Private Sub FormRegistros_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        Dim ObjMensagens As New ClassMensagens

        If e.Alt = False Then
            Select Case e.KeyCode
                Case 113 'F2 - Consultar Registro
                    If Me.DataGridRegistros.RowCount = 0 Then
                        Exit Sub
                    ElseIf Me.DataGridRegistros.CurrentCellAddress.Y < 0 Then
                        MessageBox.Show("Nenhum registro foi selecionado.", "Selecione um registro.", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Me.DataGridRegistros.Focus()
                        Exit Sub
                    End If
                    Me.Hide()
                    FormHistoricos.ObjFormPaiHistoricos = ObjFormPai.CaixaEntrada
                    FormHistoricos.IdRegistroAtual = Me.DataGridRegistros.Rows(Me.DataGridRegistros.CurrentCellAddress.Y).Cells(0).Value
                    FormHistoricos.ObjTipoManutencao = FormHistoricos.TipoManutencao.Consulta
                    FormHistoricos.Show()
                Case 115 'F4 - Incluir Histórico / Tramitar
                    If Me.DataGridRegistros.RowCount = 0 Then
                        Exit Sub
                    ElseIf Me.DataGridRegistros.CurrentCellAddress.Y < 0 Then
                        MessageBox.Show("Nenhum registro foi selecionado.", "Selecione um registro.", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Me.DataGridRegistros.Focus()
                        Exit Sub
                    End If
                    'If ObjEstrUsuario.PermissaoIncluir = False Then
                    '    ObjMensagens.UsuarioNaoHabilitado()
                    '    Exit Sub
                    'End If
                    Me.Hide()
                    FormHistoricos.ObjFormPaiHistoricos = ObjFormPai.CaixaEntrada
                    FormHistoricos.IdRegistroAtual = Me.DataGridRegistros.Rows(Me.DataGridRegistros.CurrentCellAddress.Y).Cells(0).Value
                    FormHistoricos.ObjTipoManutencao = FormHistoricos.TipoManutencao.NovoHistorico
                    FormHistoricos.Show()
                Case 116 'F5 
                    Me.CmdAtualizar_Click(Nothing, Nothing)
                Case 27 'ESC - SAIR
                    CmdSair_Click(Nothing, Nothing)
            End Select
        ElseIf e.Alt = True Then
            If e.KeyCode = Keys.F4 Then
                CmdSair_Click(Nothing, Nothing)
            End If
        End If

    End Sub

    ' *** SETA O FOCO PARA O GRID AO INICIAR O FORM ***
    Private Sub FormCaixaEntrada_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated

        If (DataGridRegistros.Enabled = True) Then
            DataGridRegistros.Focus()
        End If

    End Sub

    Function TextoConsultaSQLRegistros() As String

        Dim ComandoSQL As String = "SELECT R.ID_REGISTRO, DC.DESCRICAO AS " & """TIPO DE DOCUMENTO""" & ", " & _
                                    "R.NUM_DOC AS " & """Nº DOC """ & ", R.ANO_DOC AS " & """ANO DOC""" & ", I.descricao AS INTERESSADO, R.ASSUNTO, " & _
                                    "R.PROCEDENCIA, H.DATA_ENTRADA as ENTRADA, DT2.DESCRICAO AS REMETENTE, H.DATA_SAIDA AS SAIDA, " & _
                                    "DT.DESCRICAO AS DESTINO, (current_date - h.data_saida) AS " & """DIAS""" & _
                                    "FROM REGISTROS R, DOCUMENTOS DC, HISTORICO_REGISTROS H, DESTINATARIOS DT, INTERESSADOS I, DESTINATARIOS DT2 " & _
                                    "WHERE(DC.ID_DOCUMENTO = R.ID_TIPO_DOC) " & _
                                    "AND DT.ID_DESTINATARIO = H.ID_DESTINAT_DESTINO " & _
                                    "AND R.ID_INTERESSADO = I.ID_INTERESSADO " & _
                                    "AND DT2.id_destinatario = H.id_destinat_origem " & _
                                    "AND DT.ID_USUARIO = " & ObjEstrUsuario.IDUsuario & _
                                    "AND R.ID_REGISTRO = H.ID_REGISTRO " & _
                                    "AND H.ID_HISTORICO IN (SELECT MAX(H.ID_HISTORICO) " & _
                                                            "FROM REGISTROS R, HISTORICO_REGISTROS H " & _
                                                            "WHERE(R.ID_REGISTRO = H.ID_REGISTRO) " & _
                                                            "GROUP BY R.ID_REGISTRO) " & _
                                    "ORDER BY DIAS"

        Return ComandoSQL

    End Function

    Private Sub CmdSair_Click(sender As Object, e As EventArgs) Handles CmdSair.Click

        Me.Close()
        Me.Dispose()

    End Sub

    Private Sub CmdAtualizar_Click(sender As Object, e As EventArgs) Handles CmdAtualizar.Click

        With Me.DataGridRegistros
            .DataSource = Nothing
            Me.FormCaixaEntrada_Load(Nothing, Nothing)
            .Focus()
            If .RowCount > 0 Then
                .CurrentCell = .Rows(0).Cells(1)
            End If
        End With

    End Sub

End Class