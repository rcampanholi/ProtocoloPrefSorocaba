﻿Imports FirebirdSql.Data.FirebirdClient

Public Class ClassUsuarios

    Dim ObjMetodosGlobais As New ClassMetodosGlobais
    Dim ObjMensagens As New ClassMensagens

    Function LogInValido(ByVal NomeUsuario As String, ByVal Senha As String)

        Dim USUARIOS As FbDataReader
        Dim Comando As New FBCOMMAND(String.Empty, Conexao)
        Dim ObjMetodosGlobais As New ClassMetodosGlobais

        Conexao.Open()
        Comando.CommandText = "SELECT ID_USUARIO, NOME_FUNCIONARIO, SENHA, ADMINISTRADOR, INCLUIR, ALTERAR, EXCLUIR " & _
                              "FROM USUARIOS " & "WHERE NOME_USUARIO = '" & NomeUsuario & "'"
        USUARIOS = Comando.ExecuteReader

        If USUARIOS.Read Then
            If (USUARIOS!Senha <> Senha) Then
                MsgBox("Senha inválida", MsgBoxStyle.Exclamation, "Atenção!")
                With FormLogIn.TxtSenha
                    .Focus()
                    .SelectionStart = 0
                    .SelectionLength = Len(.Text)
                End With
                USUARIOS.Close()
                Conexao.Close()
                Return False
            Else
                ObjEstrUsuario.IDUsuario = USUARIOS!ID_USUARIO
                ObjEstrUsuario.PermissaoAlterar = USUARIOS!ALTERAR
                ObjEstrUsuario.PermissaoIncluir = USUARIOS!INCLUIR
                ObjEstrUsuario.PermissaoExcluir = USUARIOS!EXCLUIR
                If (USUARIOS!ADMINISTRADOR = "1") Then
                    UserAdm = True
                Else
                    UserAdm = False
                End If
                FormPrincipal.LblBoasVindas.Text = "Seja bem vindo(a), " & ObjMetodosGlobais.EncontraPrimeiroNomeFuncionario(USUARIOS!NOME_FUNCIONARIO) & "."
                USUARIOS.Close()
                Conexao.Close()
                Return True
            End If
        Else
            MsgBox("Nome de usuário não encontrado no banco de dados.", MsgBoxStyle.Exclamation, "Atenção!")
            With FormLogIn.TxtUser
                .Focus()
                .SelectionStart = 0
                .SelectionLength = Len(.Text)
            End With
            USUARIOS.Close()
            Conexao.Close()
            Return False
        End If

    End Function

    ' *** PROCURA INCONSISTENCIAS NO BANCO DE DADOS ***
    Function UsuarioExiste(ByVal NomeUsuario As String) As Boolean

        Dim USUARIOS As FbDataReader
        Dim Comando As New FBCOMMAND(String.Empty, Conexao)

        Conexao.Open()

        'VERIFICA SE JÁ EXISTE O NOME DE USUÁRIO NO BANCO DE DADOS:
        Comando.CommandText = "SELECT NOME_USUARIO FROM USUARIOS " & "WHERE NOME_USUARIO = '" & NomeUsuario & "'"
        USUARIOS = Comando.ExecuteReader

        If (USUARIOS.Read) Then
            MsgBox("Este nome de usuário já existe no banco de dados. Por favor, verifique.", MsgBoxStyle.Exclamation, "Atenção!")
            USUARIOS.Close()
            Conexao.Close()
            Return True
        End If
        USUARIOS.Close()
        Conexao.Close()
        Return False

    End Function

    ' *** INSERT ***
    Sub IncluiUsuario(ByVal ObjComando As FBCOMMAND)

        Conexao.Open()
        Try
            ObjComando.ExecuteNonQuery()
        Catch Ex As Exception
            MessageBox.Show(Ex.Message)
            Conexao.Close()
            ObjComando.Parameters.Clear()
        End Try
        Conexao.Close()
        ObjComando.Parameters.Clear()

    End Sub

    ' *** UPDATE ***
    Sub AtualizaUsuario(ByVal ObjComando As FBCOMMAND)

        Conexao.Open()
        Try
            ObjComando.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            Conexao.Close()
            ObjComando.Parameters.Clear()
        End Try
        Conexao.Close()
        ObjComando.Parameters.Clear()

    End Sub

    Sub ExcluiUsuario(ByVal ObjComando As FBCOMMAND)

        Conexao.Open()
        Try
            ObjComando.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            Conexao.Close()
            ObjComando.Parameters.Clear()
        End Try
        Conexao.Close()
        ObjComando.Parameters.Clear()

    End Sub

    Function ValidaAlterarSenha(ByVal NomeUsuario As String, ByVal SenhaAntiga As String, ByVal SenhaNova As String, ByVal ConfirmSenhaNova As String) As Boolean

        Dim USUARIOS As FbDataReader
        Dim Comando As New FBCOMMAND(String.Empty, Conexao)

        Conexao.ConnectionString = StringConexao
        Conexao.Open()

        Comando.CommandText = "SELECT SENHA " & _
                              "FROM USUARIOS " & _
                              "WHERE NOME_USUARIO = '" & NomeUsuario & "'"
        USUARIOS = Comando.ExecuteReader
        If (USUARIOS.Read) Then
            If (USUARIOS!Senha <> SenhaAntiga) Then
                MessageBox.Show("Senha Antiga inválida.", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Information)
                With FormAlterarSenha.TxtSenhaAntiga
                    .Focus()
                    .SelectionStart = 0
                    .SelectionLength = Len(.Text)
                    USUARIOS.Close()
                    Conexao.Close()
                    Return False
                End With
            End If
            If (SenhaNova <> ConfirmSenhaNova) Then
                MessageBox.Show("A Confirmação da Senha Nova deve ser igual a Senha Nova.", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Information)
                With FormAlterarSenha.TxtConfirmSenhaNova
                    .Focus()
                    .SelectionStart = 0
                    .SelectionLength = Len(.Text)
                    USUARIOS.Close()
                    Conexao.Close()
                    Return False
                End With
            End If
        Else 'SEM DADOS (USUARIOS.READ = FALSE)
            MessageBox.Show("Usuário não encontrado no banco de dados.", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Information)
            With FormAlterarSenha.TxtNomeUser
                .Focus()
                .SelectionStart = 0
                .SelectionLength = Len(.Text)
                USUARIOS.Close()
                Conexao.Close()
                Return False
            End With
        End If

        USUARIOS.Close()
        Conexao.Close()
        Return True

    End Function

    Sub AlteraSenha(ByVal NomeUsuario As String, ByVal SenhaNova As String)

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)
        Conexao.Open()

        Comando.CommandText = "UPDATE USUARIOS " & "SET SENHA = '" & SenhaNova & "'" & "WHERE NOME_USUARIO = '" & NomeUsuario & "'"
        Comando.ExecuteNonQuery()
        Conexao.Close()

    End Sub

    Function PermiteUsuario(ByVal ObjAcaoUsuario As AcaoUsuario) As Boolean

        Select Case ObjAcaoUsuario
            Case AcaoUsuario.Incluindo
                If ObjEstrUsuario.PermissaoIncluir = True Then
                    Return True
                Else
                    ObjMensagens.UsuarioNaoHabilitado()
                    Return False
                End If
            Case AcaoUsuario.Alterando
                If ObjEstrUsuario.PermissaoAlterar = True Then
                    Return True
                Else
                    ObjMensagens.UsuarioNaoHabilitado()
                    Return False
                End If
            Case AcaoUsuario.Excluindo
                If ObjEstrUsuario.PermissaoExcluir = True Then
                    Return True
                Else
                    ObjMensagens.UsuarioNaoHabilitado()
                    Return False
                End If
        End Select

        Return False

    End Function

    Sub RetornaArrayUsuarios(ByRef ArrayUsuarios() As String)

        Dim COMANDO As New FbCommand(String.Empty, Conexao)
        Dim Tabela As FbDataReader = Nothing
        Dim QtUser As Short = 1

        COMANDO.CommandText = "SELECT NOME_USUARIO FROM USUARIOS ORDER BY NOME_USUARIO"
        Conexao.Open()
        Tabela = COMANDO.ExecuteReader
        ReDim ArrayUsuarios(0)

        Do While Tabela.Read
            ReDim Preserve ArrayUsuarios(UBound(ArrayUsuarios) + 1)
            ArrayUsuarios(QtUser) = Tabela.GetString(0)
            QtUser += 1
        Loop

        Conexao.Close()

    End Sub

    Function RetornaIDUsuario(ByVal NomeUsuario As String) As Integer

        Dim COMANDO As New FbCommand(String.Empty, Conexao)
        Dim IDUsuarioAux As Integer = 0

        COMANDO.CommandText = "select id_usuario from usuarios where nome_usuario = '" & NomeUsuario & "'"
        Conexao.Open()
        IDUsuarioAux = COMANDO.ExecuteScalar
        Conexao.Close()

        Return IDUsuarioAux

    End Function

    Function RetornaNomeUsuario(ByVal IDUsuario As Integer) As String

        Dim COMANDO As New FbCommand(String.Empty, Conexao)
        Dim NomeUserAux As String = String.Empty

        COMANDO.CommandText = "select nome_usuario from usuarios where id_usuario = '" & IDUsuario & "'"
        Conexao.Open()
        NomeUserAux = COMANDO.ExecuteScalar
        Conexao.Close()

        Return NomeUserAux

    End Function

End Class
