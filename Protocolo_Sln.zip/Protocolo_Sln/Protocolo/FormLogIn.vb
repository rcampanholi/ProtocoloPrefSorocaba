﻿Public Class FormLogIn

    Dim ObjUsuario As New ClassUsuarios
    Dim ObjConexaoBanco As New ClassConexaoBanco
    Dim CaminhoDBInconsistente As Boolean

    Private Sub FormLogIn_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If e.Alt = False Then
            Select Case e.KeyCode
                Case 27 'ESC - SAIR
                    CmdSair_Click(Nothing, Nothing)
            End Select
        End If

    End Sub

    Private Sub FormLogIn_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

        'CARREGA STRING DE CONEXÃO:
        Try
            ObjConexaoBanco.CarregaStringConexao()
        Catch Ex As Exception
            If (Err.Number = 53) Then
                MessageBox.Show("Banco de dados não encontrado. Clique em 'OK' na tela de LogIn (não é necessário informar usuário e senha) e execute o menu de ajuda.", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.TxtUser.Enabled = False
                Me.TxtSenha.Enabled = False
                Me.CmdAlterarSenha.Enabled = False
                CaminhoDBInconsistente = True
                Exit Sub
            Else
                MessageBox.Show(Ex.Message)
                Exit Sub
            End If
        End Try

        'TESTA CONEXAO:
        Try
            Conexao.ConnectionString = StringConexao
            Conexao.Open()
            Conexao.Close()
        Catch Ex As Exception
            MessageBox.Show("Banco de dados não encontrado. Clique em 'OK' na tela de LogIn (não é necessário informar usuário e senha) e execute os procedimentos da tela seguinte.", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.TxtUser.Enabled = False
            Me.TxtSenha.Enabled = False
            Me.CmdAlterarSenha.Enabled = False
            CaminhoDBInconsistente = True
            Exit Sub
        End Try

    End Sub

    Private Sub CmdOK_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdOK.Click

        If (CaminhoDBInconsistente = True) Then
            FormCorrigirConDB.Show()
            Me.Hide()
        Else
            If ObjUsuario.LogInValido(TxtUser.Text, TxtSenha.Text) = False Then
                Exit Sub
            End If
            FormPrincipal.Show()
            Me.Hide()
        End If

    End Sub

    Private Sub CmdAlterSenha_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdAlterarSenha.Click

        Me.Hide()
        FormAlterarSenha.Show()

    End Sub

    Private Sub CmdSair_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdSair.Click

        End

    End Sub

    Private Sub TxtUser_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtUser.KeyDown

        If (e.KeyCode = 13) Then 'ENTER
            TxtSenha.Focus()
        End If

    End Sub

    Private Sub TxtSenha_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtSenha.KeyDown

        If (e.KeyCode = 13) Then
            CmdOK_Click(Nothing, Nothing)
        End If

    End Sub

End Class