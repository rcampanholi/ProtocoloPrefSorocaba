﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormRelatorioInclusoes
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormRelatorioInclusoes))
        Me.LblInformacao = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.MskDataSaida = New System.Windows.Forms.MaskedTextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.MskDataEntrada = New System.Windows.Forms.MaskedTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CmdSair = New System.Windows.Forms.Button()
        Me.CmdGerarEmails = New System.Windows.Forms.Button()
        Me.ChkSelecionarTodosInteressados = New System.Windows.Forms.CheckBox()
        Me.TxtEncontrarInteressado = New System.Windows.Forms.TextBox()
        Me.LstInteressados = New System.Windows.Forms.ListView()
        Me.ChkFiltrarInteressados = New System.Windows.Forms.CheckBox()
        Me.ChkSelecionarTodosDestinatarios = New System.Windows.Forms.CheckBox()
        Me.TxtEncontrarDestinatario = New System.Windows.Forms.TextBox()
        Me.LstDestinatarios = New System.Windows.Forms.ListView()
        Me.ChkFiltrarDestinatários = New System.Windows.Forms.CheckBox()
        Me.MskHoraEntrada = New System.Windows.Forms.MaskedTextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.MskHoraSaida = New System.Windows.Forms.MaskedTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.CmdImprimir = New System.Windows.Forms.Button()
        Me.GroupInteressados = New System.Windows.Forms.GroupBox()
        Me.GroupDestinatarios = New System.Windows.Forms.GroupBox()
        Me.GroupUsuarios = New System.Windows.Forms.GroupBox()
        Me.ChkFiltrarUsuarios = New System.Windows.Forms.CheckBox()
        Me.ChkSelecionarTodosUsuarios = New System.Windows.Forms.CheckBox()
        Me.LstUsuarios = New System.Windows.Forms.ListView()
        Me.TxtEncontrarUsuario = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupInteressados.SuspendLayout()
        Me.GroupDestinatarios.SuspendLayout()
        Me.GroupUsuarios.SuspendLayout()
        Me.SuspendLayout()
        '
        'LblInformacao
        '
        Me.LblInformacao.AutoSize = True
        Me.LblInformacao.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblInformacao.Location = New System.Drawing.Point(8, 531)
        Me.LblInformacao.Name = "LblInformacao"
        Me.LblInformacao.Size = New System.Drawing.Size(0, 13)
        Me.LblInformacao.TabIndex = 17
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.MskDataSaida)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.MskDataEntrada)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(158, 69)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Data de Inclusão"
        '
        'MskDataSaida
        '
        Me.MskDataSaida.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MskDataSaida.Location = New System.Drawing.Point(82, 36)
        Me.MskDataSaida.Mask = "00/00/0000"
        Me.MskDataSaida.Name = "MskDataSaida"
        Me.MskDataSaida.Size = New System.Drawing.Size(70, 20)
        Me.MskDataSaida.TabIndex = 2
        Me.MskDataSaida.TextMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals
        Me.MskDataSaida.ValidatingType = GetType(Date)
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(79, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(23, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Até"
        '
        'MskDataEntrada
        '
        Me.MskDataEntrada.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MskDataEntrada.Location = New System.Drawing.Point(6, 36)
        Me.MskDataEntrada.Mask = "00/00/0000"
        Me.MskDataEntrada.Name = "MskDataEntrada"
        Me.MskDataEntrada.Size = New System.Drawing.Size(70, 20)
        Me.MskDataEntrada.TabIndex = 1
        Me.MskDataEntrada.TextMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals
        Me.MskDataEntrada.ValidatingType = GetType(Date)
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(7, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(21, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "De"
        '
        'CmdSair
        '
        Me.CmdSair.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CmdSair.Location = New System.Drawing.Point(1164, 526)
        Me.CmdSair.Name = "CmdSair"
        Me.CmdSair.Size = New System.Drawing.Size(75, 23)
        Me.CmdSair.TabIndex = 23
        Me.CmdSair.Text = "Sair"
        Me.CmdSair.UseVisualStyleBackColor = True
        '
        'CmdGerarEmails
        '
        Me.CmdGerarEmails.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CmdGerarEmails.Location = New System.Drawing.Point(928, 527)
        Me.CmdGerarEmails.Name = "CmdGerarEmails"
        Me.CmdGerarEmails.Size = New System.Drawing.Size(129, 23)
        Me.CmdGerarEmails.TabIndex = 21
        Me.CmdGerarEmails.Text = "Gerar e Enviar E-Mails"
        Me.CmdGerarEmails.UseVisualStyleBackColor = True
        '
        'ChkSelecionarTodosInteressados
        '
        Me.ChkSelecionarTodosInteressados.AutoSize = True
        Me.ChkSelecionarTodosInteressados.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ChkSelecionarTodosInteressados.Enabled = False
        Me.ChkSelecionarTodosInteressados.Location = New System.Drawing.Point(13, 42)
        Me.ChkSelecionarTodosInteressados.Name = "ChkSelecionarTodosInteressados"
        Me.ChkSelecionarTodosInteressados.Size = New System.Drawing.Size(109, 17)
        Me.ChkSelecionarTodosInteressados.TabIndex = 8
        Me.ChkSelecionarTodosInteressados.Text = "Selecionar Todos"
        Me.ChkSelecionarTodosInteressados.UseVisualStyleBackColor = True
        '
        'TxtEncontrarInteressado
        '
        Me.TxtEncontrarInteressado.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TxtEncontrarInteressado.Enabled = False
        Me.TxtEncontrarInteressado.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.TxtEncontrarInteressado.Location = New System.Drawing.Point(6, 370)
        Me.TxtEncontrarInteressado.MaxLength = 80
        Me.TxtEncontrarInteressado.Name = "TxtEncontrarInteressado"
        Me.TxtEncontrarInteressado.Size = New System.Drawing.Size(393, 20)
        Me.TxtEncontrarInteressado.TabIndex = 10
        Me.TxtEncontrarInteressado.Text = "Encontrar Interessado"
        '
        'LstInteressados
        '
        Me.LstInteressados.AllowColumnReorder = True
        Me.LstInteressados.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LstInteressados.BackColor = System.Drawing.SystemColors.HighlightText
        Me.LstInteressados.CheckBoxes = True
        Me.LstInteressados.Enabled = False
        Me.LstInteressados.FullRowSelect = True
        Me.LstInteressados.HideSelection = False
        Me.LstInteressados.Location = New System.Drawing.Point(6, 65)
        Me.LstInteressados.MultiSelect = False
        Me.LstInteressados.Name = "LstInteressados"
        Me.LstInteressados.Size = New System.Drawing.Size(393, 299)
        Me.LstInteressados.TabIndex = 9
        Me.LstInteressados.UseCompatibleStateImageBehavior = False
        Me.LstInteressados.View = System.Windows.Forms.View.Details
        '
        'ChkFiltrarInteressados
        '
        Me.ChkFiltrarInteressados.AutoSize = True
        Me.ChkFiltrarInteressados.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ChkFiltrarInteressados.Location = New System.Drawing.Point(6, 19)
        Me.ChkFiltrarInteressados.Name = "ChkFiltrarInteressados"
        Me.ChkFiltrarInteressados.Size = New System.Drawing.Size(114, 17)
        Me.ChkFiltrarInteressados.TabIndex = 7
        Me.ChkFiltrarInteressados.Text = "Filtrar Interessados"
        Me.ChkFiltrarInteressados.UseVisualStyleBackColor = True
        '
        'ChkSelecionarTodosDestinatarios
        '
        Me.ChkSelecionarTodosDestinatarios.AutoSize = True
        Me.ChkSelecionarTodosDestinatarios.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ChkSelecionarTodosDestinatarios.Enabled = False
        Me.ChkSelecionarTodosDestinatarios.Location = New System.Drawing.Point(14, 42)
        Me.ChkSelecionarTodosDestinatarios.Name = "ChkSelecionarTodosDestinatarios"
        Me.ChkSelecionarTodosDestinatarios.Size = New System.Drawing.Size(109, 17)
        Me.ChkSelecionarTodosDestinatarios.TabIndex = 13
        Me.ChkSelecionarTodosDestinatarios.Text = "Selecionar Todos"
        Me.ChkSelecionarTodosDestinatarios.UseVisualStyleBackColor = True
        '
        'TxtEncontrarDestinatario
        '
        Me.TxtEncontrarDestinatario.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TxtEncontrarDestinatario.Enabled = False
        Me.TxtEncontrarDestinatario.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.TxtEncontrarDestinatario.Location = New System.Drawing.Point(6, 370)
        Me.TxtEncontrarDestinatario.MaxLength = 50
        Me.TxtEncontrarDestinatario.Name = "TxtEncontrarDestinatario"
        Me.TxtEncontrarDestinatario.Size = New System.Drawing.Size(393, 20)
        Me.TxtEncontrarDestinatario.TabIndex = 15
        Me.TxtEncontrarDestinatario.Text = "Encontrar Destinatário"
        '
        'LstDestinatarios
        '
        Me.LstDestinatarios.AllowColumnReorder = True
        Me.LstDestinatarios.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LstDestinatarios.BackColor = System.Drawing.SystemColors.HighlightText
        Me.LstDestinatarios.CheckBoxes = True
        Me.LstDestinatarios.Enabled = False
        Me.LstDestinatarios.FullRowSelect = True
        Me.LstDestinatarios.HideSelection = False
        Me.LstDestinatarios.Location = New System.Drawing.Point(6, 65)
        Me.LstDestinatarios.MultiSelect = False
        Me.LstDestinatarios.Name = "LstDestinatarios"
        Me.LstDestinatarios.Size = New System.Drawing.Size(393, 299)
        Me.LstDestinatarios.TabIndex = 14
        Me.LstDestinatarios.UseCompatibleStateImageBehavior = False
        Me.LstDestinatarios.View = System.Windows.Forms.View.Details
        '
        'ChkFiltrarDestinatários
        '
        Me.ChkFiltrarDestinatários.AutoSize = True
        Me.ChkFiltrarDestinatários.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ChkFiltrarDestinatários.Location = New System.Drawing.Point(6, 19)
        Me.ChkFiltrarDestinatários.Name = "ChkFiltrarDestinatários"
        Me.ChkFiltrarDestinatários.Size = New System.Drawing.Size(115, 17)
        Me.ChkFiltrarDestinatários.TabIndex = 12
        Me.ChkFiltrarDestinatários.Text = "Filtrar Destinatários"
        Me.ChkFiltrarDestinatários.UseVisualStyleBackColor = True
        '
        'MskHoraEntrada
        '
        Me.MskHoraEntrada.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MskHoraEntrada.Location = New System.Drawing.Point(6, 36)
        Me.MskHoraEntrada.Mask = "00:00"
        Me.MskHoraEntrada.Name = "MskHoraEntrada"
        Me.MskHoraEntrada.Size = New System.Drawing.Size(58, 20)
        Me.MskHoraEntrada.TabIndex = 4
        Me.MskHoraEntrada.TextMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals
        Me.MskHoraEntrada.ValidatingType = GetType(Date)
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.MskHoraSaida)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.MskHoraEntrada)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(176, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(134, 69)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Horário de Inclusão"
        '
        'MskHoraSaida
        '
        Me.MskHoraSaida.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MskHoraSaida.Location = New System.Drawing.Point(70, 36)
        Me.MskHoraSaida.Mask = "00:00"
        Me.MskHoraSaida.Name = "MskHoraSaida"
        Me.MskHoraSaida.Size = New System.Drawing.Size(58, 20)
        Me.MskHoraSaida.TabIndex = 5
        Me.MskHoraSaida.TextMaskFormat = System.Windows.Forms.MaskFormat.IncludePromptAndLiterals
        Me.MskHoraSaida.ValidatingType = GetType(Date)
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(67, 20)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(23, 13)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Até"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(7, 20)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(21, 13)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "De"
        '
        'CmdImprimir
        '
        Me.CmdImprimir.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CmdImprimir.Location = New System.Drawing.Point(1063, 527)
        Me.CmdImprimir.Name = "CmdImprimir"
        Me.CmdImprimir.Size = New System.Drawing.Size(95, 23)
        Me.CmdImprimir.TabIndex = 22
        Me.CmdImprimir.Text = "Gerar e Imprimir"
        Me.CmdImprimir.UseVisualStyleBackColor = True
        '
        'GroupInteressados
        '
        Me.GroupInteressados.Controls.Add(Me.ChkSelecionarTodosInteressados)
        Me.GroupInteressados.Controls.Add(Me.ChkFiltrarInteressados)
        Me.GroupInteressados.Controls.Add(Me.TxtEncontrarInteressado)
        Me.GroupInteressados.Controls.Add(Me.LstInteressados)
        Me.GroupInteressados.Location = New System.Drawing.Point(12, 87)
        Me.GroupInteressados.Name = "GroupInteressados"
        Me.GroupInteressados.Size = New System.Drawing.Size(405, 423)
        Me.GroupInteressados.TabIndex = 6
        Me.GroupInteressados.TabStop = False
        Me.GroupInteressados.Text = "Interessados"
        '
        'GroupDestinatarios
        '
        Me.GroupDestinatarios.Controls.Add(Me.ChkFiltrarDestinatários)
        Me.GroupDestinatarios.Controls.Add(Me.ChkSelecionarTodosDestinatarios)
        Me.GroupDestinatarios.Controls.Add(Me.LstDestinatarios)
        Me.GroupDestinatarios.Controls.Add(Me.TxtEncontrarDestinatario)
        Me.GroupDestinatarios.Location = New System.Drawing.Point(423, 87)
        Me.GroupDestinatarios.Name = "GroupDestinatarios"
        Me.GroupDestinatarios.Size = New System.Drawing.Size(405, 423)
        Me.GroupDestinatarios.TabIndex = 11
        Me.GroupDestinatarios.TabStop = False
        Me.GroupDestinatarios.Text = "Destinatários"
        '
        'GroupUsuarios
        '
        Me.GroupUsuarios.Controls.Add(Me.ChkFiltrarUsuarios)
        Me.GroupUsuarios.Controls.Add(Me.ChkSelecionarTodosUsuarios)
        Me.GroupUsuarios.Controls.Add(Me.LstUsuarios)
        Me.GroupUsuarios.Controls.Add(Me.TxtEncontrarUsuario)
        Me.GroupUsuarios.Location = New System.Drawing.Point(834, 87)
        Me.GroupUsuarios.Name = "GroupUsuarios"
        Me.GroupUsuarios.Size = New System.Drawing.Size(405, 423)
        Me.GroupUsuarios.TabIndex = 16
        Me.GroupUsuarios.TabStop = False
        Me.GroupUsuarios.Text = "Usuários"
        '
        'ChkFiltrarUsuarios
        '
        Me.ChkFiltrarUsuarios.AutoSize = True
        Me.ChkFiltrarUsuarios.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ChkFiltrarUsuarios.Location = New System.Drawing.Point(6, 19)
        Me.ChkFiltrarUsuarios.Name = "ChkFiltrarUsuarios"
        Me.ChkFiltrarUsuarios.Size = New System.Drawing.Size(95, 17)
        Me.ChkFiltrarUsuarios.TabIndex = 17
        Me.ChkFiltrarUsuarios.Text = "Filtrar Usuários"
        Me.ChkFiltrarUsuarios.UseVisualStyleBackColor = True
        '
        'ChkSelecionarTodosUsuarios
        '
        Me.ChkSelecionarTodosUsuarios.AutoSize = True
        Me.ChkSelecionarTodosUsuarios.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ChkSelecionarTodosUsuarios.Enabled = False
        Me.ChkSelecionarTodosUsuarios.Location = New System.Drawing.Point(14, 42)
        Me.ChkSelecionarTodosUsuarios.Name = "ChkSelecionarTodosUsuarios"
        Me.ChkSelecionarTodosUsuarios.Size = New System.Drawing.Size(109, 17)
        Me.ChkSelecionarTodosUsuarios.TabIndex = 18
        Me.ChkSelecionarTodosUsuarios.Text = "Selecionar Todos"
        Me.ChkSelecionarTodosUsuarios.UseVisualStyleBackColor = True
        '
        'LstUsuarios
        '
        Me.LstUsuarios.AllowColumnReorder = True
        Me.LstUsuarios.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LstUsuarios.BackColor = System.Drawing.SystemColors.HighlightText
        Me.LstUsuarios.CheckBoxes = True
        Me.LstUsuarios.Enabled = False
        Me.LstUsuarios.FullRowSelect = True
        Me.LstUsuarios.HideSelection = False
        Me.LstUsuarios.Location = New System.Drawing.Point(6, 65)
        Me.LstUsuarios.MultiSelect = False
        Me.LstUsuarios.Name = "LstUsuarios"
        Me.LstUsuarios.Size = New System.Drawing.Size(393, 299)
        Me.LstUsuarios.TabIndex = 19
        Me.LstUsuarios.UseCompatibleStateImageBehavior = False
        Me.LstUsuarios.View = System.Windows.Forms.View.Details
        '
        'TxtEncontrarUsuario
        '
        Me.TxtEncontrarUsuario.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TxtEncontrarUsuario.Enabled = False
        Me.TxtEncontrarUsuario.ForeColor = System.Drawing.SystemColors.WindowFrame
        Me.TxtEncontrarUsuario.Location = New System.Drawing.Point(6, 370)
        Me.TxtEncontrarUsuario.MaxLength = 50
        Me.TxtEncontrarUsuario.Name = "TxtEncontrarUsuario"
        Me.TxtEncontrarUsuario.Size = New System.Drawing.Size(393, 20)
        Me.TxtEncontrarUsuario.TabIndex = 20
        Me.TxtEncontrarUsuario.Text = "Encontrar Usuário"
        '
        'FormRelatorioInclusoes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1251, 561)
        Me.Controls.Add(Me.GroupUsuarios)
        Me.Controls.Add(Me.GroupDestinatarios)
        Me.Controls.Add(Me.GroupInteressados)
        Me.Controls.Add(Me.CmdImprimir)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.LblInformacao)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.CmdSair)
        Me.Controls.Add(Me.CmdGerarEmails)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Name = "FormRelatorioInclusoes"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Relatório de Inclusões"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupInteressados.ResumeLayout(False)
        Me.GroupInteressados.PerformLayout()
        Me.GroupDestinatarios.ResumeLayout(False)
        Me.GroupDestinatarios.PerformLayout()
        Me.GroupUsuarios.ResumeLayout(False)
        Me.GroupUsuarios.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LblInformacao As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CmdSair As System.Windows.Forms.Button
    Friend WithEvents CmdGerarEmails As System.Windows.Forms.Button
    Friend WithEvents TxtEncontrarInteressado As System.Windows.Forms.TextBox
    Friend WithEvents LstInteressados As System.Windows.Forms.ListView
    Friend WithEvents ChkFiltrarInteressados As System.Windows.Forms.CheckBox
    Friend WithEvents TxtEncontrarDestinatario As System.Windows.Forms.TextBox
    Friend WithEvents LstDestinatarios As System.Windows.Forms.ListView
    Friend WithEvents ChkFiltrarDestinatários As System.Windows.Forms.CheckBox
    Friend WithEvents MskDataSaida As System.Windows.Forms.MaskedTextBox
    Friend WithEvents MskDataEntrada As System.Windows.Forms.MaskedTextBox
    Friend WithEvents MskHoraEntrada As System.Windows.Forms.MaskedTextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents MskHoraSaida As System.Windows.Forms.MaskedTextBox
    Friend WithEvents CmdImprimir As System.Windows.Forms.Button
    Friend WithEvents ChkSelecionarTodosInteressados As System.Windows.Forms.CheckBox
    Friend WithEvents ChkSelecionarTodosDestinatarios As System.Windows.Forms.CheckBox
    Friend WithEvents GroupInteressados As System.Windows.Forms.GroupBox
    Friend WithEvents GroupDestinatarios As System.Windows.Forms.GroupBox
    Friend WithEvents GroupUsuarios As System.Windows.Forms.GroupBox
    Friend WithEvents ChkFiltrarUsuarios As System.Windows.Forms.CheckBox
    Friend WithEvents ChkSelecionarTodosUsuarios As System.Windows.Forms.CheckBox
    Friend WithEvents LstUsuarios As System.Windows.Forms.ListView
    Friend WithEvents TxtEncontrarUsuario As System.Windows.Forms.TextBox
End Class
