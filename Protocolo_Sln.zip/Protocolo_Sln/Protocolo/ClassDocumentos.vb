﻿Imports FirebirdSql.Data.FirebirdClient

Public Class ClassDocumentos

    Dim ObjMetodosGlobais As New ClassMetodosGlobais

    ' VERIFICA SE O CÓDIGO JÁ EXISTE PARA NOVA INCLUSÃO
    Function CodigoJaExiste(ByVal Codigo As Integer) As Boolean

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)

        Comando.CommandText = "SELECT CODIGO FROM DOCUMENTOS " & _
                                  "WHERE CODIGO = " & Codigo
        Conexao.Open()
        If ObjMetodosGlobais.ConverteValorNulo(Comando.ExecuteScalar) = 0 Then
            Conexao.Close()
            Return False
        Else
            MessageBox.Show("Este código já está cadastrado no banco de dados. Por favor, verifique.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Conexao.Close()
            Return True
        End If

    End Function

    ' VERIFICA SE O CÓDIGO JÁ EXISTE PARA ALTERAÇÃO (VERIFICA O ID E SE O CODIGO FOI ALTERADO)
    Function CodigoJaExiste(ByVal Codigo As Integer, ByVal IdDocumento As Integer) As Boolean

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)

        Comando.CommandText = "SELECT CODIGO " & _
                                  "FROM DOCUMENTOS " & _
                                  "WHERE ID_DOCUMENTO = " & IdDocumento & " " & _
                                  "AND CODIGO <> " & Codigo & " " & _
                                  "AND EXISTS (SELECT CODIGO FROM DOCUMENTOS " & _
                                                    "WHERE CODIGO = " & Codigo & ")"
        Conexao.Open()
        If ObjMetodosGlobais.ConverteValorNulo(Comando.ExecuteScalar) = 0 Then
            Conexao.Close()
            Return False
        Else
            MessageBox.Show("O código informado já está cadastrado no banco de dados para outro Documento. Por favor, verifique.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Conexao.Close()
            Return True
        End If

    End Function

    ' *** INSERT ***
    Sub IncluiDocumento(ByVal ObjComando As FBCOMMAND)

        Conexao.Open()
        Try
            ObjComando.ExecuteNonQuery()
        Catch Ex As Exception
            MessageBox.Show(Ex.Message)
            Conexao.Close()
            ObjComando.Parameters.Clear()
        End Try
        Conexao.Close()
        ObjComando.Parameters.Clear()

    End Sub

    ' *** UPDATE ***
    Sub AtualizaDocumento(ByVal ObjComando As FBCOMMAND)

        Conexao.Open()
        Try
            ObjComando.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            Conexao.Close()
            ObjComando.Parameters.Clear()
        End Try
        Conexao.Close()
        ObjComando.Parameters.Clear()

    End Sub

    Function ExtraiCodDeTextoDocumentos(ByVal ObjCodTextoDocumento As String) As Integer

        ObjCodTextoDocumento = Left(ObjCodTextoDocumento, 4)
        Do While ObjCodTextoDocumento.Contains("-") Or ObjCodTextoDocumento.Contains(" ")
            ObjCodTextoDocumento = Left(ObjCodTextoDocumento, Len(ObjCodTextoDocumento) - 1)
        Loop

        Return ObjCodTextoDocumento

    End Function

    Function NumEAnoObrigatorio(ByVal CodDocumento As Integer) As Boolean

        Dim Obrigatorio As Boolean

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)
        Comando.CommandText = "SELECT UTILIZA_NUM_ANO " & _
                              "FROM DOCUMENTOS " & _
                              "WHERE CODIGO = " & CodDocumento
        Conexao.Open()
        Obrigatorio = Comando.ExecuteScalar
        Conexao.Close()
        Comando.Dispose()
        Return Obrigatorio

    End Function

    Sub PovoaComboBoxDocumentos(ByRef ObjComboBox As Windows.Forms.ComboBox)

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)
        Dim Tabela As fbdatareader = Nothing
        Comando.CommandText = "SELECT CODIGO, DESCRICAO FROM DOCUMENTOS " & _
                                "ORDER BY DESCRICAO"
        Conexao.Open()
        Tabela = Comando.ExecuteReader
        While Tabela.Read
            ObjComboBox.Items.Add(Tabela.GetInt32(0) & " - " & Tabela.GetString(1))
        End While
        Conexao.Close()

    End Sub

    Function RetornaIDDocumento(ByVal CodDocumento As Integer) As Integer

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)
        Dim IDDocAux As Integer = 0

        Comando.CommandText = "SELECT ID_DOCUMENTO " & _
                              "FROM DOCUMENTOS " & _
                              "WHERE CODIGO = " & CodDocumento
        Conexao.Open()
        IDDocAux = Comando.ExecuteScalar
        Conexao.Close()
        Comando.Dispose()

        Return IDDocAux

    End Function

End Class
