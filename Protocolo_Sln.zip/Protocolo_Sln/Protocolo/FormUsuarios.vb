﻿Imports FirebirdSql.Data.FirebirdClient

Public Class FormUsuarios

    Dim ObjUsuarios As New ClassUsuarios
    Dim ObjControles As New ClassControles
    Dim ColunasOcultar() As Short = {0, 3, 4, 5, 6, 7}
    Dim LarguraColunas() As Short = {1, 400, 2, 200}
    Dim IdUsuario As Integer

    Private Sub FormUsuarios_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ObjControles.PreencheDataGridView(Me.TextoConsultaSQL, Me.DataGridView1, ClassControles.LinhaDataGridSelecionar.Primeira)
        ObjControles.FormataDataGridView(Me.DataGridView1, Me.ColunasOcultar, Me.LarguraColunas)

    End Sub

    Private Sub FormUsuarios_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If e.Alt = False Then
            Select Case e.KeyCode
                Case 27 'ESC - SAIR
                    If Me.CmdSair.Enabled = True Then
                        CmdSair_Click(Nothing, Nothing)
                    End If
            End Select
        End If

        If (e.Control = True) Then
            Dim ObjBotao As New Button
            Select Case e.KeyCode
                Case 65 'A
                    CmdAlterar_Click(Nothing, Nothing)
                Case 69 'E
                    CmdExcluir_Click(Nothing, Nothing)
                Case 78 'N
                    CmdNovo_Click(Nothing, Nothing)
                Case 83 'S
                    CmdSalvar_Click(Nothing, Nothing)
                Case 90 'Z
                    CmdCancel_Click(Nothing, Nothing)
            End Select
        End If

    End Sub

    ' *** SETA O FOCO PARA O GRID AO INICIAR O FORM ***
    Private Sub FormUsuarios_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated

        If (DataGridView1.Enabled = True) Then
            DataGridView1.Focus()
        End If

    End Sub

    'CARREGA CAMPOS, CONFORME USUÁRIO NAVEGAR PELO GRID:
    Private Sub DataGridView1_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGridView1.SelectionChanged

        If DataGridView1.CurrentCellAddress.Y >= 0 Then
            Me.CarregaCamposCadUsuarios(DataGridView1.CurrentCellAddress.Y)
        End If

    End Sub

    ' *** NOVO ***
    Public Sub CmdNovo_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdNovo.Click

        Me.DataGridView1.MultiSelect = False
        OptNao.Checked = True
        LimpaCampos()
        HabilDesabilFlexGrid(False)
        HabilDesabilCampos(True)
        HabilDesabilBotoesSuperiores(False)
        HabilDesabilBotoesInferiores(True)
        ObjTipoInstrucao = TipoInstrucao.INSERT
        TxtNomeFunc.Focus()
        Me.Controls.Owner.Refresh()

    End Sub

    ' *** ALTERAR ***
    Public Sub CmdAlterar_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdAlterar.Click

        If Me.DataGridView1.RowCount <= 0 Then
            MsgBox("Não há dados a serem alterados.", MsgBoxStyle.Exclamation, "Atenção!")
            Exit Sub
        End If

        IdUsuario = Me.DataGridView1.CurrentRow.Cells(0).Value
        Me.DataGridView1.MultiSelect = False
        HabilDesabilBotoesSuperiores(False)
        HabilDesabilBotoesInferiores(True)
        HabilDesabilCampos(True)
        HabilDesabilFlexGrid(False)
        ObjTipoInstrucao = TipoInstrucao.UPDATE
        If OptSim.Checked = True Then
            ChkAlterar.Enabled = False
            ChkIncluir.Enabled = False
            ChkExcluir.Enabled = False
        End If
        TxtNomeFunc.Focus()
        Me.Controls.Owner.Refresh()

    End Sub

    ' *** EXCLUIR ***
    Public Sub CmdExcluir_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdExcluir.Click

        If Me.DataGridView1.RowCount <= 0 Then
            MessageBox.Show("Não há dados a serem excluídos.", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If

        Dim Pergunta As Short
        Pergunta = MsgBox("Esta ação excluirá permanentemente o registro selecionado. Deseja continuar?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Atenção!")
        If (Pergunta = MsgBoxResult.Yes) Then
            IdUsuario = DataGridView1.CurrentRow.Cells(0).Value
            ObjUsuarios.ExcluiUsuario(Me.ComandoExclusao)
            ObjControles.PreencheDataGridView(Me.TextoConsultaSQL, Me.DataGridView1, ClassControles.LinhaDataGridSelecionar.Primeira)
            ObjControles.FormataDataGridView(Me.DataGridView1, Me.ColunasOcultar, Me.LarguraColunas)
            Me.CarregaCamposCadUsuarios(DataGridView1.CurrentCellAddress.Y)
        End If
        DataGridView1.Focus()
        Me.Controls.Owner.Refresh()

    End Sub

    ' *** SAIR ***
    Private Sub CmdSair_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdSair.Click

        LimpaCampos()
        Me.Close()
        Me.Dispose()

    End Sub

    Private Sub OptSim_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OptSim.CheckedChanged

        If OptSim.Checked = True Then
            ChkAlterar.Checked = True
            ChkIncluir.Checked = True
            ChkExcluir.Checked = True
            ChkAlterar.Enabled = False
            ChkIncluir.Enabled = False
            ChkExcluir.Enabled = False
        End If

    End Sub

    Private Sub OptNao_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OptNao.CheckedChanged

        If OptNao.Checked = True Then
            ChkAlterar.Checked = False
            ChkIncluir.Checked = False
            ChkExcluir.Checked = False
            If OptNao.Enabled = True Then
                ChkAlterar.Enabled = True
                ChkIncluir.Enabled = True
                ChkExcluir.Enabled = True
            End If
        End If

    End Sub

    ' *** SALVAR ***
    Private Sub CmdSalvar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdSalvar.Click

        If CamposInconsistentes() = True Then
            Exit Sub
        End If
        If ObjTipoInstrucao = TipoInstrucao.INSERT Then 'INSERT
            If ObjUsuarios.UsuarioExiste(Me.TxtNomeUser.Text) = True Then
                Me.TxtNomeUser.Focus()
                Exit Sub
            End If
            ObjUsuarios.IncluiUsuario(Me.ComandoInclusao)
            ObjControles.PreencheDataGridView(Me.TextoConsultaSQL, Me.DataGridView1, ClassControles.LinhaDataGridSelecionar.Primeira)
            ObjControles.FormataDataGridView(Me.DataGridView1, Me.ColunasOcultar, Me.LarguraColunas)
            'PROCURA ID INSERIDO PARA SETAR NO GRID:
            Dim ObjConexaoBanco As New ClassConexaoBanco
            Dim LinhaSelecionada As Integer = ObjControles.EncontraPosicaoRegistroDataGrid(Me.DataGridView1, ObjConexaoBanco.EncontraMaxID("USUARIOS", "ID_USUARIO"), 0)
            Me.DataGridView1.CurrentCell = Me.DataGridView1.Rows(LinhaSelecionada).Cells(1)
            Me.CarregaCamposCadUsuarios(LinhaSelecionada)
        ElseIf ObjTipoInstrucao = TipoInstrucao.UPDATE Then 'UPDATE
            ObjUsuarios.AtualizaUsuario(Me.ComandoAlteracao)
            ObjControles.PreencheDataGridView(Me.TextoConsultaSQL, Me.DataGridView1, ClassControles.LinhaDataGridSelecionar.Primeira)
            ObjControles.FormataDataGridView(Me.DataGridView1, Me.ColunasOcultar, Me.LarguraColunas)
            Dim LinhaSelecionada As Integer = ObjControles.EncontraPosicaoRegistroDataGrid(Me.DataGridView1, IdUsuario, 0)
            Me.DataGridView1.CurrentCell = Me.DataGridView1.Rows(LinhaSelecionada).Cells(1)
            Me.CarregaCamposCadUsuarios(LinhaSelecionada)
        End If
        HabilDesabilBotoesInferiores(False)
        HabilDesabilBotoesSuperiores(True)
        HabilDesabilFlexGrid(True)
        HabilDesabilCampos(False)
        Me.Controls.Owner.Refresh()
        Me.DataGridView1.Focus()

    End Sub

    ' *** CANCELAR ***
    Public Sub CmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdCancel.Click

        HabilDesabilCampos(False)
        HabilDesabilFlexGrid(True)
        HabilDesabilBotoesSuperiores(True)
        HabilDesabilBotoesInferiores(False)
        Me.CarregaCamposCadUsuarios(DataGridView1.CurrentCellAddress.Y)
        DataGridView1.Focus()
        Me.DataGridView1.MultiSelect = True
        Me.Controls.Owner.Refresh()

    End Sub

    Private Sub TxtSenha_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles TxtSenha.Enter

        With TxtSenha
            .SelectionStart = 0
            .SelectionLength = .TextLength
        End With

    End Sub

    Private Sub TxtConfirmSenha_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles TxtConfirmSenha.Enter

        With TxtConfirmSenha
            .SelectionStart = 0
            .SelectionLength = .TextLength
        End With
    End Sub

    Private Sub TxtEncontraNomeFunc_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtEncontraNomeFunc.KeyDown

        If e.KeyCode = 13 Then
            TxtEncontraNomeFunc.Text = String.Empty
            DataGridView1.Focus()
        End If

    End Sub

    Private Sub TxtEncontraNomeFunc_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtEncontraNomeFunc.LostFocus

        TxtEncontraNomeFunc.Text = String.Empty

    End Sub

    Private Sub TxtEncontraNomeFunc_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles TxtEncontraNomeFunc.TextChanged

        If TxtEncontraNomeFunc.Text <> String.Empty Then
            Dim Linha As Integer = ObjControles.EncontraRegistroDataGridView(Me.DataGridView1, 1, TxtEncontraNomeFunc.Text, Len(TxtEncontraNomeFunc.Text))
            If Linha > 0 Then
                Me.CarregaCamposCadUsuarios(Linha)
            End If
        End If

    End Sub

    Private Sub TxtEncontraNomeUser_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtEncontraNomeUser.KeyDown

        If e.KeyCode = 13 Then
            TxtEncontraNomeUser.Text = String.Empty
            DataGridView1.Focus()
        End If

    End Sub

    Private Sub TxtEncontraNomeUser_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles TxtEncontraNomeUser.TextChanged

        If TxtEncontraNomeUser.Text <> String.Empty Then
            Dim Linha As Integer = ObjControles.EncontraRegistroDataGridView(Me.DataGridView1, 2, TxtEncontraNomeUser.Text, Len(TxtEncontraNomeUser.Text))
            If Linha > 0 Then
                Me.CarregaCamposCadUsuarios(Linha)
            End If
        End If

    End Sub

    Private Sub TxtEncontraNomeUser_LostFocus(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles TxtEncontraNomeUser.LostFocus

        TxtEncontraNomeUser.Text = String.Empty

    End Sub

    ' *** PROCURA INCONSISTENCIAS NO FORM CADASTRO DE Usuarios ***
    Function CamposInconsistentes() As Boolean

        With Me
            'CAMPO NOME_FUNCIONARIO:
            If (.TxtNomeFunc.Text = String.Empty) Then
                MsgBox("Todos os campos devem ser preenchidos.", MsgBoxStyle.Exclamation, "Atenção!")
                .TxtNomeFunc.Focus()
                Return True
            End If

            'CAMPO NOME_USUARIO:
            If (.TxtNomeUser.Text = String.Empty) Then
                MsgBox("Todos os campos devem ser preenchidos.", MsgBoxStyle.Exclamation, "Atenção!")
                .TxtNomeUser.Focus()
                Return True
            End If

            'CAMPO ADMINISTRADOR:
            If (.OptSim.Checked = False And .OptNao.Checked = False) Then
                MsgBox("Todos os campos devem ser preenchidos.", MsgBoxStyle.Exclamation, "Atenção!")
                .OptNao.Focus()
                Return True
            End If

            'CAMPO SENHA:
            If (.TxtSenha.Text = String.Empty) Then
                MsgBox("Todos os campos devem ser preenchidos.", MsgBoxStyle.Exclamation, "Atenção!")
                .TxtSenha.Focus()
                Return True
            End If

            'CAMPO CONFIRMAÇÃO DE SENHA:
            If (.TxtConfirmSenha.Text = String.Empty) Then
                MsgBox("Todos os campos devem ser preenchidos.", MsgBoxStyle.Exclamation, "Atenção!")
                .TxtConfirmSenha.Focus()
                Return True
            End If

            'COMPARAÇÃO CAMPO SENHA E CONFIRMAÇÃO DE SENHA:
            If (.TxtSenha.Text <> .TxtConfirmSenha.Text) Then
                MsgBox("O campo 'Confirmar Senha' deve ser exatamente igual ao campo 'Senha'.", MsgBoxStyle.Exclamation, "Atenção!")
                .TxtConfirmSenha.Focus()
                Return True
            End If

        End With

    End Function

    Sub LimpaCampos()

        With Me
            .TxtNomeFunc.Text = String.Empty
            .TxtNomeUser.Text = String.Empty
            .TxtSenha.Text = String.Empty
            .TxtConfirmSenha.Text = String.Empty
            .OptSim.Checked = False
            .OptNao.Checked = False
            .ChkIncluir.Checked = False
            .ChkAlterar.Checked = False
            .ChkExcluir.Checked = False
        End With

    End Sub

    Sub HabilDesabilCampos(ByVal Acao As Boolean)

        With Me
            .TxtNomeFunc.Enabled = Acao
            .TxtNomeUser.Enabled = Acao
            .TxtSenha.Enabled = Acao
            .TxtConfirmSenha.Enabled = Acao
            .OptSim.Enabled = Acao
            .OptNao.Enabled = Acao
            .ChkAlterar.Enabled = Acao
            .ChkIncluir.Enabled = Acao
            .ChkExcluir.Enabled = Acao
        End With

    End Sub

    Sub HabilDesabilFlexGrid(ByVal Acao As Boolean)

        With Me
            .DataGridView1.Enabled = Acao
            .TxtEncontraNomeFunc.Enabled = Acao
            .TxtEncontraNomeUser.Enabled = Acao
        End With

    End Sub

    Sub HabilDesabilBotoesSuperiores(ByVal Acao)

        With Me
            .CmdNovo.Enabled = Acao
            .CmdAlterar.Enabled = Acao
            .CmdExcluir.Enabled = Acao
            .CmdSair.Enabled = Acao
        End With

    End Sub

    Sub HabilDesabilBotoesInferiores(ByVal Acao As Boolean)

        With Me
            .CmdSalvar.Enabled = Acao
            .CmdCancel.Enabled = Acao
        End With

    End Sub

    Function TextoConsultaSQL() As String

        Dim ComandoSQL As String = "SELECT ID_USUARIO, NOME_FUNCIONARIO AS NOME, NOME_USUARIO AS USUARIO, SENHA, " & _
                                   "ADMINISTRADOR, INCLUIR, ALTERAR, EXCLUIR " & _
                                   "FROM Usuarios " & _
                                   "ORDER BY NOME_FUNCIONARIO "
        Return ComandoSQL

    End Function

    Sub CarregaCamposCadUsuarios(ByRef linha As Integer)

        With Me
            If (.DataGridView1.RowCount > 0) Then
                .TxtNomeFunc.Text = .DataGridView1.Rows(linha).Cells(1).Value 'NOME_FUNCIONARIO
                .TxtNomeUser.Text = .DataGridView1.Rows(linha).Cells(2).Value 'NOME_USUARIO
                .TxtSenha.Text = .DataGridView1.Rows(linha).Cells(3).Value 'SENHA
                .TxtConfirmSenha.Text = .DataGridView1.Rows(linha).Cells(3).Value 'CONFIRMAÇÃO DA SENHA
                If (.DataGridView1.Rows(linha).Cells(4).Value = "1") Then 'ADMINISTRADOR
                    .OptSim.Checked = True
                Else
                    .OptNao.Checked = True
                End If
                If (.DataGridView1.Rows(linha).Cells(5).Value = 1) Then 'INCLUIR
                    .ChkIncluir.Checked = True
                Else
                    .ChkIncluir.Checked = False
                End If
                If (.DataGridView1.Rows(linha).Cells(6).Value = 1) Then 'ALTERAR
                    .ChkAlterar.Checked = True
                Else
                    .ChkAlterar.Checked = False
                End If
                If (.DataGridView1.Rows(linha).Cells(7).Value = 1) Then 'EXCLUIR
                    .ChkExcluir.Checked = True
                Else
                    .ChkExcluir.Checked = False
                End If
            End If
        End With

    End Sub

    Function ComandoInclusao() As FBCOMMAND

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)

        With Me
            Comando.CommandText = "INSERT INTO USUARIOS(NOME_FUNCIONARIO, NOME_USUARIO, SENHA, " & _
                "ADMINISTRADOR, ULTIMA_ALTERACAO, INCLUIR, ALTERAR, EXCLUIR) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar)
            Comando.Parameters(0).Value = .TxtNomeFunc.Text
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar)
            Comando.Parameters(1).Value = .TxtNomeUser.Text
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar)
            Comando.Parameters(2).Value = .TxtSenha.Text
            Comando.Parameters.Add(String.Empty, FbDbType.SmallInt)
            If (.OptSim.Checked = True) Then
                Comando.Parameters(3).Value = 1
            Else
                Comando.Parameters(3).Value = 0
            End If
            Comando.Parameters.Add(String.Empty, FbDbType.Date)
            Comando.Parameters(4).Value = Now
            Comando.Parameters.Add(String.Empty, FbDbType.SmallInt)
            If (.ChkIncluir.Checked = True) Then
                Comando.Parameters(5).Value = 1
            Else
                Comando.Parameters(5).Value = 0
            End If
            Comando.Parameters.Add(String.Empty, FbDbType.SmallInt)
            If (.ChkAlterar.Checked = True) Then
                Comando.Parameters(6).Value = 1
            Else
                Comando.Parameters(6).Value = 0
            End If
            Comando.Parameters.Add(String.Empty, FbDbType.SmallInt)
            If (.ChkExcluir.Checked = True) Then
                Comando.Parameters(7).Value = 1
            Else
                Comando.Parameters(7).Value = 0
            End If
        End With

        Return Comando

    End Function

    Function ComandoAlteracao() As FBCOMMAND

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)

        With Me
            Comando.CommandText = "UPDATE USUARIOS SET NOME_FUNCIONARIO = ?, NOME_USUARIO = ?, SENHA = ?, " & _
                "ADMINISTRADOR = ?, ULTIMA_ALTERACAO = ?, INCLUIR = ?, ALTERAR = ?, EXCLUIR = ? " & _
                "WHERE ID_USUARIO = " & IdUsuario & ""
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar)
            Comando.Parameters(0).Value = .TxtNomeFunc.Text
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar)
            Comando.Parameters(1).Value = .TxtNomeUser.Text
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar)
            Comando.Parameters(2).Value = .TxtSenha.Text
            Comando.Parameters.Add(String.Empty, FbDbType.SmallInt)
            If (.OptSim.Checked = True) Then
                Comando.Parameters(3).Value = 1
            Else
                Comando.Parameters(3).Value = 0
            End If
            Comando.Parameters.Add(String.Empty, FbDbType.Date)
            Comando.Parameters(4).Value = Now
            Comando.Parameters.Add(String.Empty, FbDbType.SmallInt)
            If (.ChkIncluir.Checked = True) Then
                Comando.Parameters(5).Value = 1
            Else
                Comando.Parameters(5).Value = 0
            End If
            Comando.Parameters.Add(String.Empty, FbDbType.SmallInt)
            If (.ChkAlterar.Checked = True) Then
                Comando.Parameters(6).Value = 1
            Else
                Comando.Parameters(6).Value = 0
            End If
            Comando.Parameters.Add(String.Empty, FbDbType.SmallInt)
            If (.ChkExcluir.Checked = True) Then
                Comando.Parameters(7).Value = 1
            Else
                Comando.Parameters(7).Value = 0
            End If
        End With

        Return Comando

    End Function

    Function ComandoExclusao() As FBCOMMAND

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)
        Comando.CommandText = "DELETE FROM USUARIOS " & "WHERE ID_USUARIO =  " & IDUsuario & ""

        Return Comando
    End Function

End Class