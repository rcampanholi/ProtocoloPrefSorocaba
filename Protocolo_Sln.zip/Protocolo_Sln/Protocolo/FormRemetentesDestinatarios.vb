﻿Imports FirebirdSql.Data.FirebirdClient

Public Class FormRemetentesDestinatarios

    Dim ObjUsuarios As New ClassUsuarios
    Dim ObjControles As New ClassControles
    Dim ObjDestinatarios As New ClassDestinatarios
    Dim ColunasOcultar() As Short = {0, 4}
    Dim LarguraColunas() As Short = {1, 60, 2, 240, 3, 220}
    Dim IdDestinatario As Integer
    Dim CodigoDestinatarioAux As Integer = 0

    Private Sub FormDestinatarios_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        ObjControles.PreencheDataGridView(Me.TextoConsultaSQL, Me.DataGridView1, ClassControles.LinhaDataGridSelecionar.Primeira)
        ObjControles.FormataDataGridView(Me.DataGridView1, Me.ColunasOcultar, Me.LarguraColunas)

    End Sub

    Private Sub FormDestinatarios_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If e.Alt = False Then
            Select Case e.KeyCode
                Case 27 'ESC - SAIR
                    If Me.CmdSair.Enabled = True Then
                        CmdSair_Click(Nothing, Nothing)
                    End If
            End Select
        End If

        If (e.Control = True) Then
            Dim ObjBotao As New Button
            Select Case e.KeyCode
                Case 65 'A
                    CmdAlterar_Click(Nothing, Nothing)
                Case 78 'N
                    CmdNovo_Click(Nothing, Nothing)
                Case 83 'S
                    CmdSalvar_Click(Nothing, Nothing)
                Case 90 'Z
                    CmdCancel_Click(Nothing, Nothing)
            End Select
        End If

    End Sub

    ' *** SETA O FOCO PARA O GRID AO INICIAR O FORM ***
    Private Sub FormDestinatarios_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated

        If (DataGridView1.Enabled = True) Then
            DataGridView1.Focus()
        End If

    End Sub

    'CARREGA CAMPOS, CONFORME USUÁRIO NAVEGAR PELO GRID:
    Private Sub DataGridView1_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGridView1.SelectionChanged

        If DataGridView1.CurrentCellAddress.Y >= 0 Then
            Me.CarregaCampos(Me.DataGridView1.CurrentCellAddress.Y)
        End If

    End Sub

    ' *** NOVO ***
    Public Sub CmdNovo_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdNovo.Click

        If ObjUsuarios.PermiteUsuario(AcaoUsuario.Incluindo) = False Then
            Exit Sub
        End If
        Me.LimpaCampos()
        Me.HabilDesabilGrid(False)
        Me.HabilDesabilCampos(True)
        Me.HabilDesabilBotoesSuperiores(False)
        Me.HabilDesabilBotoesInferiores(True)
        ObjTipoInstrucao = TipoInstrucao.INSERT
        Me.CarregaComboBoxUsuarios()
        TxtCodDestinatario.Focus()

    End Sub

    ' *** ALTERAR ***
    Public Sub CmdAlterar_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdAlterar.Click

        If ObjUsuarios.PermiteUsuario(AcaoUsuario.Alterando) = False Then
            Exit Sub
        End If

        If (Me.DataGridView1.RowCount = 0) Then
            MsgBox("Não há dados a serem alterados.", MsgBoxStyle.Exclamation, "Atenção!")
            Exit Sub
        End If
        IdDestinatario = Me.DataGridView1.CurrentRow.Cells(0).Value
        CodigoDestinatarioAux = Me.TxtCodDestinatario.Text
        Me.HabilDesabilBotoesSuperiores(False)
        Me.HabilDesabilBotoesInferiores(True)
        Me.HabilDesabilCampos(True)
        Me.HabilDesabilGrid(False)
        ObjTipoInstrucao = TipoInstrucao.UPDATE
        Me.CarregaComboBoxUsuarios()
        TxtCodDestinatario.Focus()

    End Sub

    ' *** SAIR ***
    Private Sub CmdSair_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdSair.Click

        Me.Close()
        Me.Dispose()

    End Sub

    Private Sub TxtEmail_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtEmail.KeyUp

        If e.KeyCode = 50 Then
            Me.TxtEmail.Text &= "sorocaba.sp.gov.br"
            Me.TxtEmail.SelectionStart = RetornaPosicaoCursorAposArroba(Me.TxtEmail.Text)
            Me.TxtEmail.SelectionLength = Len(Me.TxtEmail.Text) - RetornaPosicaoCursorAposArroba(Me.TxtEmail.Text)
        End If

    End Sub

    ' *** SALVAR ***
    Private Sub CmdSalvar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdSalvar.Click

        If Me.CamposInconsistentes = True Then
            Exit Sub
        End If
        If ObjTipoInstrucao = TipoInstrucao.INSERT Then
            If ObjDestinatarios.CodigoJaExiste(Me.TxtCodDestinatario.Text) = True Then
                Me.TxtCodDestinatario.Focus()
                Exit Sub
            End If
        ElseIf ObjTipoInstrucao = TipoInstrucao.UPDATE Then
            If CodigoDestinatarioAux <> Me.TxtCodDestinatario.Text Then 'HOUVE ALTERAÇÃO DO CÓDIGO
                If ObjDestinatarios.CodigoJaExiste(Me.TxtCodDestinatario.Text, IdDestinatario) = True Then
                    Me.TxtCodDestinatario.Focus()
                    Exit Sub
                End If
            End If
        End If

        If ObjTipoInstrucao = TipoInstrucao.INSERT Then 'INSERT
            ObjDestinatarios.IncluiDestinatario(Me.ComandoInclusao)
            ObjControles.PreencheDataGridView(Me.TextoConsultaSQL, Me.DataGridView1, ClassControles.LinhaDataGridSelecionar.Primeira)
            ObjControles.FormataDataGridView(Me.DataGridView1, Me.ColunasOcultar, Me.LarguraColunas)
            'PROCURA ID INSERIDO PARA SETAR NO GRID:
            Dim LinhaSelecionada As Integer = ObjControles.EncontraPosicaoRegistroDataGrid(Me.DataGridView1, Me.TxtCodDestinatario.Text, 1)
            Me.DataGridView1.CurrentCell = Me.DataGridView1.Rows(LinhaSelecionada).Cells(1)
            Me.CarregaCampos(LinhaSelecionada)
        ElseIf ObjTipoInstrucao = TipoInstrucao.UPDATE Then 'UPDATE
            ObjDestinatarios.AtualizaDestinatario(Me.ComandoAtualizacao)
            ObjControles.PreencheDataGridView(Me.TextoConsultaSQL, Me.DataGridView1, ClassControles.LinhaDataGridSelecionar.Primeira)
            ObjControles.FormataDataGridView(Me.DataGridView1, Me.ColunasOcultar, Me.LarguraColunas)
            Dim LinhaSelecionada As Integer = ObjControles.EncontraPosicaoRegistroDataGrid(Me.DataGridView1, IdDestinatario, 0)
            Me.DataGridView1.CurrentCell = Me.DataGridView1.Rows(LinhaSelecionada).Cells(1)
            Me.CarregaCampos(LinhaSelecionada)
        End If

        Me.HabilDesabilBotoesInferiores(False)
        Me.HabilDesabilBotoesSuperiores(True)
        Me.HabilDesabilGrid(True)
        Me.HabilDesabilCampos(False)
        Me.DataGridView1.Focus()

    End Sub

    ' *** CANCELAR ***
    Public Sub CmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdCancel.Click

        Me.HabilDesabilCampos(False)
        Me.HabilDesabilGrid(True)
        Me.HabilDesabilBotoesSuperiores(True)
        Me.HabilDesabilBotoesInferiores(False)
        Me.LimpaCampos()
        Me.CarregaCampos(Me.DataGridView1.CurrentCellAddress.Y)
        DataGridView1.Focus()

    End Sub

    Sub LimpaCampos()

        With Me
            .TxtCodDestinatario.Text = String.Empty
            .TxtDescrDestinatario.Text = String.Empty
            .TxtEmail.Text = String.Empty
            .CmbUsuario.Text = String.Empty
        End With

    End Sub

    Sub HabilDesabilCampos(ByVal Acao As Boolean)

        With Me
            .TxtCodDestinatario.Enabled = Acao
            .TxtDescrDestinatario.Enabled = Acao
            .TxtEmail.Enabled = Acao
            .CmbUsuario.Enabled = Acao
        End With

    End Sub

    Sub HabilDesabilGrid(ByVal Acao As Boolean)

        With Me
            .DataGridView1.Enabled = Acao
        End With

    End Sub

    Sub HabilDesabilBotoesSuperiores(ByVal Acao As Boolean)

        With Me
            .CmdNovo.Enabled = Acao
            .CmdAlterar.Enabled = Acao
            .CmdSair.Enabled = Acao
        End With

    End Sub

    Sub HabilDesabilBotoesInferiores(ByVal Acao As Boolean)

        With Me
            .CmdSalvar.Enabled = Acao
            .CmdCancel.Enabled = Acao
        End With

    End Sub

    Function CamposInconsistentes() As Boolean

        With Me
            'CAMPO CÓDIGO:
            If (.TxtCodDestinatario.Text = String.Empty) Then
                MessageBox.Show("Todos os campos devem ser preenchidos.", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                .TxtDescrDestinatario.Focus()
                Return True
            ElseIf Not IsNumeric(.TxtCodDestinatario.Text) = True Then
                MsgBox("O campo 'Código' aceita somente números.", MsgBoxStyle.Exclamation, "Atenção!")
                .TxtCodDestinatario.Focus()
                Return True
            End If

            'CAMPO DESCRIÇÃO:
            If (.TxtDescrDestinatario.Text = String.Empty) Then
                MsgBox("Todos os campos devem ser preenchidos.", MsgBoxStyle.Exclamation, "Atenção!")
                .TxtDescrDestinatario.Focus()
                Return True
            End If

            'CAMPO EMAIL:
            If .TxtEmail.Text <> String.Empty And Not .TxtEmail.Text.ToString.Contains("@") Then
                MessageBox.Show("E-Mail inválido.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                .TxtEmail.Focus()
                Return True
            End If

            'CAMPO USUARIO
            If Me.CmbUsuario.SelectedIndex < 0 Then
                MessageBox.Show("Usuário inválido.", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                .CmbUsuario.Focus()
                Return True
            End If

        End With

    End Function

    Function TextoConsultaSQL() As String

        Dim ComandoSQL As String = "SELECT ID_DESTINATARIO, CODIGO, DESCRICAO, EMAIL, ID_USUARIO " & _
                                   "FROM DESTINATARIOS " & _
                                   "ORDER BY DESCRICAO"
        Return ComandoSQL

    End Function

    Sub CarregaCampos(ByRef linha As Integer)

        With Me
            If (.DataGridView1.RowCount > 0) Then
                .TxtCodDestinatario.Text = Format(.DataGridView1.Rows(linha).Cells(1).Value, "000000") 'MATRÍCULA
                .TxtDescrDestinatario.Text = .DataGridView1.Rows(linha).Cells(2).Value 'NOME/DESCRIÇÃO
                If Not IsDBNull(.DataGridView1.Rows(linha).Cells(3).Value) Then
                    .TxtEmail.Text = .DataGridView1.Rows(linha).Cells(3).Value 'EMAIL
                Else
                    .TxtEmail.Text = String.Empty
                End If
                If Not IsDBNull(.DataGridView1.Rows(linha).Cells(4).Value) Then
                    Dim ObjUsuarios As New ClassUsuarios
                    .CmbUsuario.Text = ObjUsuarios.RetornaNomeUsuario(.DataGridView1.Rows(linha).Cells(4).Value) 'USUARIO
                Else
                    .CmbUsuario.Text = String.Empty
                End If
            End If
        End With

    End Sub

    Function ComandoInclusao() As FBCOMMAND

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)

        With Me
            Comando.CommandText = "INSERT INTO DESTINATARIOS(CODIGO, DESCRICAO, EMAIL, ID_USUARIO) VALUES (?, ?, ?, ?) "
            Comando.Parameters.Add(String.Empty, FbDbType.Integer)
            Comando.Parameters(0).Value = .TxtCodDestinatario.Text
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar)
            Comando.Parameters(1).Value = .TxtDescrDestinatario.Text
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar)
            If .TxtEmail.Text = String.Empty Then
                Comando.Parameters(2).Value = System.DBNull.Value
            Else
                Comando.Parameters(2).Value = .TxtEmail.Text
            End If
            Comando.Parameters.Add(String.Empty, FbDbType.Integer)
            Dim ObjUsuarios As New ClassUsuarios
            Comando.Parameters(3).Value = ObjUsuarios.RetornaIDUsuario(Me.CmbUsuario.Text)
            If Comando.Parameters(3).Value = 0 Then
                Comando.Parameters(3).Value = DBNull.Value
            End If

        End With

        Return Comando

    End Function

    Function ComandoAtualizacao() As FBCOMMAND

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)

        With Me
            Comando.CommandText = "UPDATE DESTINATARIOS SET CODIGO = ?, DESCRICAO = ?, EMAIL = ?, ID_USUARIO = ? " & _
                                  "WHERE ID_DESTINATARIO = " & IdDestinatario
            Comando.Parameters.Add(String.Empty, FbDbType.Integer)
            Comando.Parameters(0).Value = .TxtCodDestinatario.Text
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar)
            Comando.Parameters(1).Value = .TxtDescrDestinatario.Text
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar)
            If .TxtEmail.Text = String.Empty Then
                Comando.Parameters(2).Value = System.DBNull.Value
            Else
                Comando.Parameters(2).Value = .TxtEmail.Text
            End If
            Comando.Parameters.Add(String.Empty, FbDbType.Integer)
            Dim ObjUsuarios As New ClassUsuarios
            Comando.Parameters(3).Value = ObjUsuarios.RetornaIDUsuario(Me.CmbUsuario.Text)
            If Comando.Parameters(3).Value = 0 Then
                Comando.Parameters(3).Value = DBNull.Value
            End If
        End With

        Return Comando

    End Function

    Private Sub TxtEncontraCod_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtEncontraCod.KeyDown

        If e.KeyCode = 13 Then
            TxtEncontraCod.Text = String.Empty
            DataGridView1.Focus()
        End If

    End Sub

    Private Sub TxtEncontraCod_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtEncontraCod.LostFocus

        TxtEncontraCod.Text = String.Empty

    End Sub

    Private Sub TxtEncontraCod_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles TxtEncontraCod.TextChanged

        If TxtEncontraCod.Text <> String.Empty Then
            Dim Linha As Integer = ObjControles.EncontraRegistroDataGridView(Me.DataGridView1, 1, TxtEncontraCod.Text, Len(TxtEncontraCod.Text))
            If Linha > 0 Then
                Me.CarregaCampos(Linha)
            End If
        End If

    End Sub

    Private Sub TxtEncontraNome_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtEncontraNome.KeyDown

        If e.KeyCode = 13 Then
            TxtEncontraNome.Text = String.Empty
            DataGridView1.Focus()
        End If

    End Sub

    Private Sub TxtEncontraNome_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtEncontraNome.LostFocus

        TxtEncontraNome.Text = String.Empty

    End Sub

    Private Sub TxtEncontraNome_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles TxtEncontraNome.TextChanged

        If TxtEncontraNome.Text <> String.Empty Then
            Dim Linha As Integer = ObjControles.EncontraRegistroDataGridView(Me.DataGridView1, 2, TxtEncontraNome.Text, Len(TxtEncontraNome.Text))
            If Linha > 0 Then
                Me.CarregaCampos(Linha)
            End If
        End If

    End Sub

    Private Function RetornaPosicaoCursorAposArroba(ByVal StrEMail As String) As Short

        For i As Short = 1 To Len(StrEMail)
            If Mid(StrEMail, i, 1) = "@" Then
                Return i
            End If
        Next

    End Function

    Sub CarregaComboBoxUsuarios()

        Dim ObjUsuarios As New ClassUsuarios

        Me.CmbUsuario.Items.Clear()
        Me.CmbUsuario.Items.Add("** NENHUM **")
        Dim Usuarios() As String = Nothing
        ObjUsuarios.RetornaArrayUsuarios(Usuarios)

        For i As Short = 1 To Usuarios.Length - 1
            Me.CmbUsuario.Items.Add(Usuarios(i))
        Next

    End Sub

End Class