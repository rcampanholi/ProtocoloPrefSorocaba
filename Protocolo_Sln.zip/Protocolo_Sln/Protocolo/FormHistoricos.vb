﻿Imports FirebirdSql.Data.FirebirdClient

Public Class FormHistoricos

    Enum TipoManutencao
        NovoDocumento = 1
        NovoHistorico = 2
        Consulta = 3
        AlteracaoHistorico = 4
    End Enum

    Dim ObjControles As New ClassControles
    Dim ColunasOcultar() As Short = {0, 1, 2, 3, 4, 5, 6, 7, 9, 14, 15}
    Dim LarguraColunas() As Short = {8, 85, 10, 305, 11, 85, 12, 80, 13, 305}
    Public IdRegistroAtual As Integer
    Public ObjTipoManutencao As TipoManutencao
    Friend ObjFormPaiHistoricos As ObjFormPai = ObjFormPai.Registos

    Private Sub FormHistoricos_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If e.KeyCode = Keys.Enter Then '"TRANSFORMA" ENTER EM TAB
            SendKeys.Send("{TAB}")
        End If

        If e.Alt = False Then
            Select Case e.KeyCode
                Case 113 'F2 - Consultar Código
                    If Me.CmdPesquisa.Enabled = True Then
                        Me.Hide()
                        Me.CmdPesquisa_Click(Nothing, Nothing)
                    End If
                Case 114 'F3 - Cadastrar Interessado
                    If Me.TxtCodInteressado.Enabled = True Then
                        Me.Hide()
                        FormInteressados.ObjFormularioPaiInteressados = ObjFormPai.Historicos
                        FormInteressados.Show()
                    End If
                Case 115 'F4
                    If ObjEstrUsuario.PermissaoAlterar = False Then
                        Dim ObjMensagem As New ClassMensagens
                        ObjMensagem.UsuarioNaoHabilitado()
                        Exit Sub
                    End If
                    If Me.ObjTipoManutencao = TipoManutencao.Consulta Then
                        Dim ObjTipoDocumentos As New ClassDocumentos
                        ObjTipoDocumentos.PovoaComboBoxDocumentos(Me.CmbTipoDocumento)
                        Me.HabDesabCamposRegistroParaAlteracoes(True)
                        Me.HabDesabCamposInferiores(True)
                        Me.TxtCodInteressado.Focus()
                    Else 'se não for consulta impede que seja feita alteração
                        Exit Sub
                    End If
                Case 116 'F5
                    If Me.CmdAgregados.Enabled = True Then
                        CmdAgregados_Click(Nothing, Nothing)
                    End If
                Case 27 'ESC - SAIR
                    If CmdSair.Enabled = True Then
                        CmdSair_Click(Nothing, Nothing)
                    ElseIf CmdCancelar.Enabled = True Then
                        CmdCancelar_Click(Nothing, Nothing)
                    End If
            End Select
        End If

        If (e.Control = True) Then
            Dim ObjBotao As New Button
            Select Case e.KeyCode
                Case 83 'S
                    If Me.CmdSalvar.Enabled = True Then
                        CmdSalvar_Click(Nothing, Nothing)
                    End If
                Case 90 'Z
                    If Me.CmdCancelar.Enabled = True Then
                        CmdCancelar_Click(Nothing, Nothing)
                    End If
            End Select
        End If

    End Sub

    '*** LOAD ***
    Private Sub FormHistoricos_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Select Case ObjTipoManutencao
            Case TipoManutencao.NovoDocumento ' ** NOVO DOCUMENTO **
                HabDesabCamposSuperiores(True)
                HabDesabCamposInferiores(True)
                Dim ObjDestinatarios As New ClassDestinatarios
                Dim ObjTipoDocumentos As New ClassDocumentos
                ObjTipoDocumentos.PovoaComboBoxDocumentos(Me.CmbTipoDocumento)
                ObjDestinatarios.PovoaComboBoxCodigo(Me.CmbCodOrigem)
                ObjDestinatarios.PovoaComboBoxDescricao(Me.CmbOrigem)
                ObjDestinatarios.PovoaComboBoxCodigo(Me.CmbCodDestino)
                ObjDestinatarios.PovoaComboBoxDescricao(Me.CmbDestino)
                Me.MskDataEntrada.Text = Now
                Me.MskHoraEntrada.Text = Format(Now, "HH:mm")
                Me.TxtCodInteressado.Focus()
            Case TipoManutencao.NovoHistorico ' ** NOVO HISTÓRICO **
                ObjControles.PreencheDataGridView(Me.TextoConsultaSQL, Me.DataGridView1, ClassControles.LinhaDataGridSelecionar.Ultima)
                ObjControles.FormataDataGridView(Me.DataGridView1, Me.ColunasOcultar, Me.LarguraColunas)
                Me.DataGridView1.CurrentCell = Me.DataGridView1.Rows(Me.DataGridView1.RowCount - 1).Cells(8) 'SELECIONA ULTIMA LINHA DO GRID
                HabDesabCamposHistorico(True)
                HabDesabCamposInferiores(True)
                Dim ObjDestinatarios As New ClassDestinatarios
                ObjDestinatarios.PovoaComboBoxCodigo(Me.CmbCodDestino)
                ObjDestinatarios.PovoaComboBoxDescricao(Me.CmbDestino)
                Me.MskDataSaida.Focus()
                Me.CarregaCamposRegistros(Me.DataGridView1.RowCount - 1) 'CARREGA CAMPOS PASSANDO ULTIMA LINHA DO GRID
                LimpaCamposInclusaoHistorico()
            Case TipoManutencao.Consulta ' ** CONSULTA **
                ObjControles.PreencheDataGridView(Me.TextoConsultaSQL, Me.DataGridView1, ClassControles.LinhaDataGridSelecionar.Ultima)
                ObjControles.FormataDataGridView(Me.DataGridView1, Me.ColunasOcultar, Me.LarguraColunas)
                If ObjFormPaiHistoricos = ObjFormPai.Registos Then
                    Me.CmdAgregados.Enabled = True
                End If
                Me.DataGridView1.Enabled = True
                Me.CmdSair.Enabled = True
                Me.DataGridView1.Focus()
                Me.DataGridView1.CurrentCell = Me.DataGridView1.Rows(Me.DataGridView1.RowCount - 1).Cells(8) 'SELECIONA ULTIMA LINHA DO GRID
            Case TipoManutencao.AlteracaoHistorico
                ObjControles.PreencheDataGridView(Me.TextoConsultaSQL, Me.DataGridView1, ClassControles.LinhaDataGridSelecionar.Ultima)
                ObjControles.FormataDataGridView(Me.DataGridView1, Me.ColunasOcultar, Me.LarguraColunas)
                Me.DataGridView1.CurrentCell = Me.DataGridView1.Rows(Me.DataGridView1.RowCount - 1).Cells(8) 'SELECIONA ULTIMA LINHA DO GRID
                HabDesabCamposHistorico(True)
                HabDesabCamposInferiores(True)
                Dim ObjDestinatarios As New ClassDestinatarios
                ObjDestinatarios.PovoaComboBoxCodigo(Me.CmbCodDestino)
                ObjDestinatarios.PovoaComboBoxDescricao(Me.CmbDestino)
                Me.MskDataSaida.Focus()
                Me.CarregaCamposRegistros(Me.DataGridView1.RowCount - 1) 'CARREGA CAMPOS PASSANDO ULTIMA LINHA DO GRID
                LimpaCamposAlteracaoHistorico()
        End Select

    End Sub

    Private Sub DataGridView1_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGridView1.SelectionChanged

        If CancelaEventos = False Then
            If Me.DataGridView1.RowCount > 0 Then
                Me.CarregaCamposRegistros(Me.DataGridView1.CurrentCellAddress.Y)
            End If
        End If

    End Sub

    Private Sub TxtCodInteressado_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtCodInteressado.LostFocus

        Dim ObjInteressados As New ClassInteressado

        If Me.TxtCodInteressado.Text <> String.Empty And IsNumeric(Me.TxtCodInteressado.Text) Then
            If ObjInteressados.RetornaDescrInteressado(Me.TxtCodInteressado.Text) = String.Empty Then
                Me.TxtDescrInteressado.Text = String.Empty
                Exit Sub
            Else
                TxtDescrInteressado.Text = ObjInteressados.RetornaDescrInteressado(Me.TxtCodInteressado.Text)
            End If
        Else
            Me.TxtDescrInteressado.Text = String.Empty
        End If

    End Sub

    Private Sub CmdAgregados_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdAgregados.Click

        'Me.Hide()
        Dim ObjInteressados As New ClassInteressado
        With FormAgregados
            .IdInteressadoPrincipal = ObjInteressados.RetornaIDInteressado(Me.TxtCodInteressado.Text)
            .DescrInteressadoPrincipal = Me.TxtDescrInteressado.Text
            .IdRegistro = Me.IdRegistroAtual
            .Show()
        End With

    End Sub

    ' *** SALVAR ***
    Private Sub CmdSalvar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdSalvar.Click

        If CamposInconsistentes() = True Then
            Exit Sub
        End If

        If ObjTipoManutencao = TipoManutencao.NovoHistorico Then
            Dim ObjRegistros As New ClassRegistros
            ObjRegistros.IncluiRegistro(Me.ComandoInclusaoHistorico)
            If ObjFormPaiHistoricos = ObjFormPai.Registos Then
                With FormRegistros
                    ObjControles.PreencheDataGridView(.TextoConsultaSQLRegistros, .DataGridRegistros, ClassControles.LinhaDataGridSelecionar.Primeira)
                    ObjControles.FormataDataGridView(.DataGridRegistros, .ColunasOcultarRegistros, .LarguraColunasRegistros)
                    Dim LinhaSelecionada As Integer = ObjControles.EncontraPosicaoRegistroDataGrid(.DataGridRegistros, Me.DataGridView1.Rows(0).Cells(2).Value, 0)
                    .LinhaSelecionadaDataGridRegistros = LinhaSelecionada
                    .DataGridRegistros.CurrentCell = .DataGridRegistros.Rows(LinhaSelecionada).Cells(1)
                    .DataGridRegistros_SelectionChanged(Nothing, Nothing)
                    Me.Dispose()
                    .Show()
                End With
            ElseIf ObjFormPaiHistoricos = ObjFormPai.CaixaEntrada Then
                With FormCaixaEntrada
                    Me.Dispose()
                    .Show()
                    .CmdAtualizar.PerformClick()
                End With
            End If
        ElseIf ObjTipoManutencao = TipoManutencao.NovoDocumento Then
            Dim ObjRegistros As New ClassRegistros
            Dim ObjInteressados As New ClassInteressado
            ObjRegistros.IncluiRegistro(Me.ComandoInclusaoRegistro)
            ObjRegistros.IncluiRegistro(Me.ComandoInclusaoHistorico)
            With FormRegistros
                .TxtCodigo.Text = Me.TxtCodInteressado.Text
                .TxtCodigo_LostFocus(Nothing, Nothing)
                Me.Close()
                Me.Dispose()
                .Show()
            End With
        ElseIf ObjTipoManutencao = TipoManutencao.AlteracaoHistorico Then
            Dim ObjRegistros As New ClassRegistros
            ObjRegistros.AtualizaRegistro(Me.ComandoAlteracaoHistorico(Me.DataGridView1.Rows(Me.DataGridView1.CurrentCellAddress.Y).Cells(15).Value))
            With FormRegistros
                ObjControles.PreencheDataGridView(.TextoConsultaSQLRegistros, .DataGridRegistros, ClassControles.LinhaDataGridSelecionar.Primeira)
                ObjControles.FormataDataGridView(.DataGridRegistros, .ColunasOcultarRegistros, .LarguraColunasRegistros)
                Dim LinhaSelecionada As Integer = ObjControles.EncontraPosicaoRegistroDataGrid(.DataGridRegistros, Me.DataGridView1.Rows(0).Cells(2).Value, 0)
                .LinhaSelecionadaDataGridRegistros = LinhaSelecionada
                .DataGridRegistros.CurrentCell = .DataGridRegistros.Rows(LinhaSelecionada).Cells(1)
                .DataGridRegistros_SelectionChanged(Nothing, Nothing)
                Me.Dispose()
                .Show()
            End With
        ElseIf ObjTipoManutencao = TipoManutencao.Consulta Then 'alteração de dados do registro poderá ser feita somente em caso de consulta.

            Dim ObjRegistros As New ClassRegistros
            ObjRegistros.AtualizaRegistro(Me.ComandoAlteracaoRegistro)
            With FormRegistros
                FormRegistros.TxtCodigo.Text = Me.TxtCodInteressado.Text
                FormRegistros.TxtCodigo_LostFocus(Nothing, Nothing)
                ObjControles.PreencheDataGridView(.TextoConsultaSQLRegistros, .DataGridRegistros, ClassControles.LinhaDataGridSelecionar.Primeira)
                ObjControles.FormataDataGridView(.DataGridRegistros, .ColunasOcultarRegistros, .LarguraColunasRegistros)
                Me.Dispose()
                .Show()
            End With

        End If

    End Sub

    ' *** CANCELAR ***
    Private Sub CmdCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdCancelar.Click

        Me.Dispose()

        If Me.ObjFormPaiHistoricos = ObjFormPai.Registos Then
            FormRegistros.Show()
            FormRegistros.DataGridRegistros.Focus()
        ElseIf Me.ObjFormPaiHistoricos = ObjFormPai.ConsultaAvancada Then
            FormConsultaAvancada.Show()
            FormConsultaAvancada.DataGridView1.Focus()
        ElseIf Me.ObjFormPaiHistoricos = ObjFormPai.CaixaEntrada Then
            FormCaixaEntrada.Show()
            FormCaixaEntrada.CmdAtualizar.PerformClick()
            FormCaixaEntrada.DataGridRegistros.Focus()
        End If

    End Sub

    ' *** SAIR ***
    Private Sub CmdSair_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdSair.Click

        Me.Dispose()

        If Me.ObjFormPaiHistoricos = ObjFormPai.Registos Then
            FormRegistros.Show()
            FormRegistros.DataGridRegistros.Focus()
        ElseIf Me.ObjFormPaiHistoricos = ObjFormPai.ConsultaAvancada Then
            FormConsultaAvancada.Show()
            FormConsultaAvancada.DataGridView1.Focus()
        ElseIf Me.ObjFormPaiHistoricos = ObjFormPai.CaixaEntrada Then
            FormCaixaEntrada.Show()
            FormCaixaEntrada.CmdAtualizar.PerformClick()
            FormCaixaEntrada.DataGridRegistros.Focus()
        End If

    End Sub

    Private Sub HabDesabCamposSuperiores(ByVal Acao As Boolean)

        HabDesabCamposRegistro(Acao)
        HabDesabCamposHistorico(Acao)

    End Sub

    Private Sub HabDesabCamposRegistro(ByVal Acao As Boolean)

        Me.TxtCodInteressado.Enabled = Acao
        Me.CmdPesquisa.Enabled = Acao
        Me.TxtDescrInteressado.Enabled = Acao
        Me.TxtAssunto.Enabled = Acao
        Me.CmbTipoDocumento.Enabled = Acao
        Me.TxtNumDocumento.Enabled = Acao
        Me.TxtAnoDocumento.Enabled = Acao
        Me.TxtProcedencia.Enabled = Acao
        Me.MskDataEntrada.Enabled = Acao
        Me.MskHoraEntrada.Enabled = Acao
        Me.CmbCodOrigem.Enabled = Acao
        Me.CmbOrigem.Enabled = Acao

    End Sub

    Private Sub HabDesabCamposRegistroParaAlteracoes(ByVal Acao As Boolean)

        Me.TxtCodInteressado.Enabled = Acao
        Me.TxtDescrInteressado.Enabled = Acao
        Me.TxtAssunto.Enabled = Acao
        Me.CmbTipoDocumento.Enabled = Acao
        Me.TxtNumDocumento.Enabled = Acao
        Me.TxtAnoDocumento.Enabled = Acao
        Me.TxtProcedencia.Enabled = Acao

    End Sub

    Private Sub HabDesabCamposHistorico(ByVal Acao As Boolean)

        With Me
            .MskDataSaida.Enabled = Acao
            .MskHoraSaida.Enabled = Acao
            .CmbCodDestino.Enabled = Acao
            .CmbDestino.Enabled = Acao
            .TxtObservacao.Enabled = Acao
        End With

    End Sub

    Private Sub HabDesabCamposInferiores(ByVal Acao As Boolean)

        Me.CmdSalvar.Enabled = Acao
        Me.CmdCancelar.Enabled = Acao

    End Sub

    Private Sub FormHistoricos_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed

        If Me.ObjFormPaiHistoricos = ObjFormPai.Registos Then
            FormRegistros.Show()
            FormRegistros.DataGridRegistros.Focus()
        ElseIf Me.ObjFormPaiHistoricos = ObjFormPai.ConsultaAvancada Then
            FormConsultaAvancada.Show()
            FormConsultaAvancada.DataGridView1.Focus()
        ElseIf Me.ObjFormPaiHistoricos = ObjFormPai.CaixaEntrada Then
            FormCaixaEntrada.Show()
            FormCaixaEntrada.DataGridRegistros.Focus()
        End If

    End Sub

    Private Sub CarregaCamposRegistros(ByRef linha As Integer)

        If CancelaEventos = False Then
            Dim ObjDestinatarios As New ClassDestinatarios
            With Me
                If (.DataGridView1.RowCount > 0 And linha >= 0) Then
                    .TxtCodInteressado.Text = .DataGridView1.Rows(linha).Cells(0).Value 'CÓDIGO INTERESSADO
                    .TxtDescrInteressado.Text = .DataGridView1.Rows(linha).Cells(1).Value 'DESCRIÇÃO INTERESSADO
                    .TxtAssunto.Text = .DataGridView1.Rows(linha).Cells(3).Value 'ASSUNTO
                    .CmbTipoDocumento.Text = .DataGridView1.Rows(linha).Cells(4).Value 'TIPO DOCUMENTO
                    .TxtNumDocumento.Text = .DataGridView1.Rows(linha).Cells(5).Value 'Nº DOCUMENTO
                    If IsDBNull(.DataGridView1.Rows(linha).Cells(6).Value) Then 'ANO DOCUMENTO
                        .TxtAnoDocumento.Text = String.Empty
                    Else
                        .TxtAnoDocumento.Text = .DataGridView1.Rows(linha).Cells(6).Value
                    End If
                    .TxtProcedencia.Text = .DataGridView1.Rows(linha).Cells(7).Value 'PROCEDENCIA
                    If Not IsDBNull(DataGridView1.Rows(linha).Cells(8).Value) Then
                        .MskDataEntrada.Text = .DataGridView1.Rows(linha).Cells(8).Value 'DATA ENTRADA
                    End If
                    If Not IsDBNull(DataGridView1.Rows(linha).Cells(9).Value) Then
                        .MskHoraEntrada.Text = .DataGridView1.Rows(linha).Cells(9).Value 'HORA ENTRADA
                    End If
                    .CmbCodOrigem.Text = ObjDestinatarios.ExtraiCodDeTextoDestinatarios(.DataGridView1.Rows(linha).Cells(10).Value) 'CÓDIGO DE ORIGEM
                    .CmbOrigem.Text = ObjDestinatarios.ExtraiTextoDeCodDestinatarios(.DataGridView1.Rows(linha).Cells(10).Value) 'ORIGEM
                    If Not IsDBNull(DataGridView1.Rows(linha).Cells(11).Value) Then
                        .MskDataSaida.Text = .DataGridView1.Rows(linha).Cells(11).Value 'DATA SAÍDA
                    End If
                    If Not IsDBNull(DataGridView1.Rows(linha).Cells(12).Value) Then
                        .MskHoraSaida.Text = .DataGridView1.Rows(linha).Cells(12).Value 'HORA SAÍDA
                    End If
                    .CmbCodDestino.Text = ObjDestinatarios.ExtraiCodDeTextoDestinatarios(.DataGridView1.Rows(linha).Cells(13).Value) 'CÓDIGO DE DESTINO
                    .CmbDestino.Text = ObjDestinatarios.ExtraiTextoDeCodDestinatarios(.DataGridView1.Rows(linha).Cells(13).Value) 'DESTINO
                    .TxtObservacao.Text = .DataGridView1.Rows(linha).Cells(14).Value 'OBSERVACAO
                End If
            End With
        End If

    End Sub

    Private Sub LimpaCamposInclusaoHistorico()

        Me.MskDataEntrada.Text = Me.MskDataSaida.Text
        Me.MskHoraEntrada.Text = Me.MskHoraSaida.Text
        Me.CmbCodOrigem.Text = Me.CmbCodDestino.Text
        Me.CmbOrigem.Text = Me.CmbDestino.Text
        Me.CmbCodDestino.Text = String.Empty
        Me.CmbDestino.Text = String.Empty
        Me.MskDataSaida.Text = New Date(Now.Year, Now.Month, Now.Day)
        Me.MskHoraSaida.Text = Format(New Date(Now.Year, Now.Month, Now.Day, Now.Hour, Now.Minute, Now.Second), "HH:mm").ToString
        Me.TxtObservacao.Text = String.Empty

    End Sub

    Private Sub LimpaCamposAlteracaoHistorico()

        Me.MskDataSaida.Text = New Date(Now.Year, Now.Month, Now.Day)
        Me.MskHoraSaida.Text = Format(New Date(Now.Year, Now.Month, Now.Day, Now.Hour, Now.Minute, Now.Second), "HH:mm").ToString
        Me.TxtObservacao.Text = String.Empty
        Me.CmbCodDestino.Focus()

    End Sub

    Function TextoConsultaSQL() As String

        Dim ComandoSQL As String = "SELECT I.CODIGO, I.DESCRICAO, R.ID_REGISTRO, R.ASSUNTO, DC.DESCRICAO AS TIPO_DOC, " & _
                          "R.NUM_DOC, R.ANO_DOC, R.PROCEDENCIA, H.DATA_ENTRADA AS ENTRADA, H.HORA_ENTRADA, " & _
                               "(SELECT DT1.codigo ||' - '|| DT1.descricao AS ORIGEM " & _
                               "FROM destinatarios DT1 " & _
                               "WHERE H.id_destinat_origem = DT1.id_destinatario) AS ORIGEM, " & _
                               "H.DATA_SAIDA AS SAIDA, H.HORA_SAIDA as " & """ HR. SAIDA""" & ", DT.codigo  ||' - '|| DT.descricao AS DESTINO, " & _
                               "H.OBSERVACAO, H.ID_HISTORICO " & _
                          "FROM REGISTROS R, DOCUMENTOS DC, historico_registros H, DESTINATARIOS DT, INTERESSADOS I " & _
                          "WHERE DC.id_documento = R.id_tipo_doc " & _
                          "AND DT.id_destinatario = H.id_destinat_destino " & _
                          "AND R.ID_INTERESSADO = I.id_interessado " & _
                          "AND R.id_registro = H.ID_REGISTRO " & _
                          "AND R.ID_REGISTRO = " & IdRegistroAtual & " " & _
                          "ORDER BY H.ID_HISTORICO, H.DATA_SAIDA DESC, H.HORA_SAIDA"
        Return ComandoSQL

    End Function

    Function ComandoInclusaoRegistro() As FBCOMMAND

        Dim ObjDestinatarios As New ClassDestinatarios
        Dim ObjDocumentos As New ClassDocumentos
        Dim ObjInteressados As New ClassInteressado
        Dim Comando As New FbCommand(String.Empty, Conexao)

        With Me
            Comando.CommandText = "INSERT INTO REGISTROS (ID_INTERESSADO, PROCEDENCIA, ID_TIPO_DOC, NUM_DOC, " & _
                                  "ANO_DOC, ASSUNTO, DATA_INCLUSAO, ID_USUARIO) " & _
                                  "VALUES (?, ?, ?, ?, ?, ?, ?, ?) "
            Comando.Parameters.Add(String.Empty, FbDbType.Integer) 'ID_INTERESSADO
            Comando.Parameters(0).Value = ObjInteressados.RetornaIDInteressado(Me.TxtCodInteressado.Text)
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar) 'PROCEDENCIA
            Comando.Parameters(1).Value = .TxtProcedencia.Text
            Comando.Parameters.Add(String.Empty, FbDbType.Integer) 'ID_TIPO_DOC
            Comando.Parameters(2).Value = ObjDocumentos.RetornaIDDocumento(ObjDocumentos.ExtraiCodDeTextoDocumentos(Me.CmbTipoDocumento.Text))
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar) 'NUM_DOC
            Comando.Parameters(3).Value = .TxtNumDocumento.Text
            Comando.Parameters.Add(String.Empty, FbDbType.Integer) 'ANO_DOC
            If .TxtAnoDocumento.Text = String.Empty Then
                Comando.Parameters(4).Value = System.DBNull.Value
            Else
                Comando.Parameters(4).Value = .TxtAnoDocumento.Text
            End If
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar) 'ASSUNTO
            Comando.Parameters(5).Value = .TxtAssunto.Text
            Comando.Parameters.Add(String.Empty, FbDbType.Date) 'DATA_INCLUSAO
            Comando.Parameters(6).Value = Now
            Comando.Parameters.Add(String.Empty, FbDbType.Integer) 'ID_USUARIO
            Comando.Parameters(7).Value = ObjEstrUsuario.IDUsuario
        End With

        Return Comando

    End Function

    Function ComandoInclusaoHistorico() As FBCOMMAND

        Dim ObjDestinatarios As New ClassDestinatarios
        Dim Comando As New FBCOMMAND(String.Empty, Conexao)

        With Me
            Comando.CommandText = "INSERT INTO HISTORICO_REGISTROS (ID_REGISTRO, DATA_ENTRADA, HORA_ENTRADA, ID_DESTINAT_ORIGEM, " & _
                                  "DATA_SAIDA, HORA_SAIDA, ID_DESTINAT_DESTINO, OBSERVACAO, DATA_INCLUSAO, HORA_INCLUSAO, ID_USUARIO) " & _
                                  "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) "
            Comando.Parameters.Add(String.Empty, FbDbType.Integer) 'ID_REGISTRO
            If ObjTipoManutencao = TipoManutencao.NovoHistorico Then
                Comando.Parameters(0).Value = .DataGridView1.Rows(.DataGridView1.CurrentCellAddress.Y).Cells(2).Value
            ElseIf ObjTipoManutencao = TipoManutencao.NovoDocumento Then 'EM CASO DE NOVO DOCUMENTO, O ID_REGISTRO SERÁ NOVO.
                Dim ObjRegistros As New ClassRegistros
                Comando.Parameters(0).Value = ObjRegistros.RetornaMaxIDRegistro()
            End If
            Comando.Parameters.Add(String.Empty, FbDbType.Date) 'DATA_ENTRADA
            Comando.Parameters(1).Value = .MskDataEntrada.Text
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar) 'HORA_ENTRADA
            Comando.Parameters(2).Value = .MskHoraEntrada.Text
            Comando.Parameters.Add(String.Empty, FbDbType.Integer) 'ID_DESTINAT_ORIGEM
            Comando.Parameters(3).Value = ObjDestinatarios.RetornaIDDestinatario(.CmbCodOrigem.Text)
            Comando.Parameters.Add(String.Empty, FbDbType.Date) 'DATA_SAIDA
            Comando.Parameters(4).Value = .MskDataSaida.Text
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar) 'HORA_SAIDA
            Comando.Parameters(5).Value = .MskHoraSaida.Text
            Comando.Parameters.Add(String.Empty, FbDbType.Integer) 'ID_DESTINAT_DESTINO
            Comando.Parameters(6).Value = ObjDestinatarios.RetornaIDDestinatario(.CmbCodDestino.Text)
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar) 'OBSERVACAO
            Comando.Parameters(7).Value = .TxtObservacao.Text
            Comando.Parameters.Add(String.Empty, FbDbType.Date) 'DATA_INCLUSAO
            Comando.Parameters(8).Value = Now
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar) 'HORA_INCLUSAO
            Comando.Parameters(9).Value = Format(Now, "HH:mm:ss")
            Comando.Parameters.Add(String.Empty, FbDbType.Integer) 'ID_USUARIO
            Comando.Parameters(10).Value = ObjEstrUsuario.IDUsuario
        End With

        Return Comando

    End Function

    Function ComandoAlteracaoRegistro() As FbCommand

        Dim ObjDocumentos As New ClassDocumentos
        Dim ObjInteressados As New ClassInteressado
        Dim Comando As New FbCommand(String.Empty, Conexao)

        With Me
            Comando.CommandText = "UPDATE REGISTROS SET ID_INTERESSADO = ?, PROCEDENCIA = ?, ID_TIPO_DOC = ?, " & _
                                  "NUM_DOC = ?, ANO_DOC = ?, ASSUNTO = ?, ID_USUARIO = ? " & _
                                  "WHERE ID_REGISTRO = " & IdRegistroAtual
            Comando.Parameters.Add(String.Empty, FbDbType.Integer) 'ID_INTERESSADO
            Comando.Parameters(0).Value = ObjInteressados.RetornaIDInteressado(Me.TxtCodInteressado.Text)
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar) 'PROCEDENCIA
            Comando.Parameters(1).Value = .TxtProcedencia.Text
            Comando.Parameters.Add(String.Empty, FbDbType.Integer) 'ID_TIPO_DOC
            Comando.Parameters(2).Value = ObjDocumentos.RetornaIDDocumento(ObjDocumentos.ExtraiCodDeTextoDocumentos(Me.CmbTipoDocumento.Text))
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar) 'NUM_DOC
            Comando.Parameters(3).Value = .TxtNumDocumento.Text
            Comando.Parameters.Add(String.Empty, FbDbType.Integer) 'ANO_DOC
            If .TxtAnoDocumento.Text = String.Empty Then
                Comando.Parameters(4).Value = System.DBNull.Value
            Else
                Comando.Parameters(4).Value = .TxtAnoDocumento.Text
            End If
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar) 'ASSUNTO
            Comando.Parameters(5).Value = .TxtAssunto.Text
            Comando.Parameters.Add(String.Empty, FbDbType.Integer) 'ID_USUARIO
            Comando.Parameters(6).Value = ObjEstrUsuario.IDUsuario
        End With

        Return Comando

    End Function

    Function ComandoAlteracaoHistorico(ByVal IdHistorico As Integer) As FbCommand

        Dim ObjDestinatarios As New ClassDestinatarios
        Dim Comando As New FbCommand(String.Empty, Conexao)

        With Me
            Comando.CommandText = "UPDATE HISTORICO_REGISTROS SET ID_REGISTRO = ?, DATA_ENTRADA = ?, HORA_ENTRADA = ?, ID_DESTINAT_ORIGEM = ?, " & _
                                  "DATA_SAIDA = ?, HORA_SAIDA = ?, ID_DESTINAT_DESTINO = ?, OBSERVACAO = ?, DATA_INCLUSAO = ?, HORA_INCLUSAO = ?, ID_USUARIO = ? " & _
                                  "WHERE ID_HISTORICO = " & IdHistorico
            Comando.Parameters.Add(String.Empty, FbDbType.Integer) 'ID_REGISTRO
            If ObjTipoManutencao = TipoManutencao.NovoHistorico Then
                Comando.Parameters(0).Value = .DataGridView1.Rows(.DataGridView1.CurrentCellAddress.Y).Cells(2).Value
            ElseIf ObjTipoManutencao = TipoManutencao.NovoDocumento Then 'EM CASO DE NOVO DOCUMENTO, O ID_REGISTRO SERÁ NOVO.
                Dim ObjRegistros As New ClassRegistros
                Comando.Parameters(0).Value = ObjRegistros.RetornaMaxIDRegistro()
            ElseIf ObjTipoManutencao = TipoManutencao.AlteracaoHistorico Then
                Comando.Parameters(0).Value = .DataGridView1.Rows(.DataGridView1.CurrentCellAddress.Y).Cells(2).Value
            End If
            Comando.Parameters.Add(String.Empty, FbDbType.Date) 'DATA_ENTRADA
            Comando.Parameters(1).Value = .MskDataEntrada.Text
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar) 'HORA_ENTRADA
            Comando.Parameters(2).Value = .MskHoraEntrada.Text
            Comando.Parameters.Add(String.Empty, FbDbType.Integer) 'ID_DESTINAT_ORIGEM
            Comando.Parameters(3).Value = ObjDestinatarios.RetornaIDDestinatario(.CmbCodOrigem.Text)
            Comando.Parameters.Add(String.Empty, FbDbType.Date) 'DATA_SAIDA
            Comando.Parameters(4).Value = .MskDataSaida.Text
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar) 'HORA_SAIDA
            Comando.Parameters(5).Value = .MskHoraSaida.Text
            Comando.Parameters.Add(String.Empty, FbDbType.Integer) 'ID_DESTINAT_DESTINO
            Comando.Parameters(6).Value = ObjDestinatarios.RetornaIDDestinatario(.CmbCodDestino.Text)
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar) 'OBSERVACAO
            Comando.Parameters(7).Value = .TxtObservacao.Text
            Comando.Parameters.Add(String.Empty, FbDbType.Date) 'DATA_INCLUSAO
            Comando.Parameters(8).Value = Now
            Comando.Parameters.Add(String.Empty, FbDbType.VarChar) 'HORA_INCLUSAO
            Comando.Parameters(9).Value = Format(Now, "HH:mm:ss")
            Comando.Parameters.Add(String.Empty, FbDbType.Integer) 'ID_USUARIO
            Comando.Parameters(10).Value = ObjEstrUsuario.IDUsuario
        End With

        Return Comando

    End Function

    Private Function CamposInconsistentes() As Boolean

        Dim ObjMensagens As New ClassMensagens

        With Me
            If ObjTipoManutencao = TipoManutencao.NovoDocumento Or ObjTipoManutencao = TipoManutencao.Consulta Then 'FAZ CONSISTÊNCIAS EM TODOS OS CAMPOS

                Dim ObjInteressados As New ClassInteressado
                Dim ObjDocumentos As New ClassDocumentos

                'CODIGO INTERESSADO:
                If .TxtCodInteressado.Text = String.Empty Then
                    ObjMensagens.TodosCamposDevemSerPreenchidos()
                    .TxtCodInteressado.Focus()
                    Return True
                ElseIf Not IsNumeric(.TxtCodInteressado.Text) Then
                    ObjMensagens.CampoNumerico("Código")
                    .TxtCodInteressado.Focus()
                    ObjControles.SelecionaTodoTexto(.TxtCodInteressado)
                    Return True
                ElseIf ObjInteressados.CodigoExiste(Me.TxtCodInteressado.Text) = False Then
                    ObjMensagens.CodigoNaoExiste("Código")
                    Me.TxtCodInteressado.Focus()
                    ObjControles.SelecionaTodoTexto(.TxtCodInteressado)
                    Return True
                End If

                'DESCRIÇÃO INTERESSADO:
                If .TxtDescrInteressado.Text = String.Empty Then
                    ObjMensagens.TodosCamposDevemSerPreenchidos()
                    .TxtDescrInteressado.Focus()
                    Return True
                End If

                'ASSUNTO:
                If .TxtAssunto.Text = String.Empty Then
                    ObjMensagens.TodosCamposDevemSerPreenchidos()
                    .TxtAssunto.Focus()
                    Return True
                End If

                'TIPO DE DOCUMENTO:
                If .CmbTipoDocumento.Text = String.Empty Then
                    ObjMensagens.TodosCamposDevemSerPreenchidos()
                    .CmbTipoDocumento.Focus()
                    Return True
                ElseIf .CmbTipoDocumento.SelectedIndex < 0 Then
                    ObjMensagens.SelecaoInvalidaComboBox("Tipo de Documento")
                    .CmbTipoDocumento.Focus()
                    ObjControles.SelecionaTodoTexto(.CmbTipoDocumento)
                    Return True
                End If

                'Nº DOCUMENTO:
                If ObjDocumentos.NumEAnoObrigatorio(ObjDocumentos.ExtraiCodDeTextoDocumentos(.CmbTipoDocumento.Text)) = True Then
                    If .TxtNumDocumento.Text = String.Empty Then
                        ObjMensagens.PreenchimentoNumEAnoObrigatorio("Número Doc.")
                        .TxtNumDocumento.Focus()
                        Return True
                    End If
                End If
                If .TxtNumDocumento.Text <> String.Empty And Not IsNumeric(.TxtNumDocumento.Text) Then
                    ObjMensagens.CampoNumerico("Número Doc.")
                    .TxtNumDocumento.Focus()
                    ObjControles.SelecionaTodoTexto(.TxtNumDocumento)
                    Return True
                End If

                'ANO DOCUMENTO:
                If ObjDocumentos.NumEAnoObrigatorio(ObjDocumentos.ExtraiCodDeTextoDocumentos(.CmbTipoDocumento.Text)) = True Then
                    If .TxtAnoDocumento.Text = String.Empty Then
                        ObjMensagens.PreenchimentoNumEAnoObrigatorio("Ano Doc.")
                        .TxtAnoDocumento.Focus()
                        Return True
                    End If
                End If
                If .TxtAnoDocumento.Text <> String.Empty And Not IsNumeric(.TxtAnoDocumento.Text) Then
                    ObjMensagens.CampoNumerico("Ano Doc.")
                    .TxtAnoDocumento.Focus()
                    ObjControles.SelecionaTodoTexto(.TxtAnoDocumento)
                    Return True
                End If

                'PROCEDENCIA:
                If .TxtProcedencia.Text = String.Empty Then
                    ObjMensagens.TodosCamposDevemSerPreenchidos()
                    .TxtProcedencia.Focus()
                    Return True
                End If

                If ObjTipoManutencao = TipoManutencao.Consulta Then 'SE FOR TIPO CONSULTA SIGNIFICA QUE É ALTERAÇÃO DE DADOS DO REGISTRO. NÃO PRECISA VERIFICAR OS CAMPOS ABAIXO.
                    Return False
                End If

                'DATA ENTRADA:
                If .MskDataEntrada.Text = DataNula Then
                    ObjMensagens.TodosCamposDevemSerPreenchidos()
                    .MskDataEntrada.Focus()
                    Return True
                ElseIf Not IsDate(.MskDataEntrada.Text) Then
                    ObjMensagens.DataInvalida()
                    .MskDataEntrada.Focus()
                    Return True
                End If

                'HORA ENTRADA:
                If .MskHoraEntrada.Text = HoraNula Then
                    ObjMensagens.TodosCamposDevemSerPreenchidos()
                    .MskHoraEntrada.Focus()
                    Return True
                ElseIf Not IsDate(.MskHoraEntrada.Text) Then
                    ObjMensagens.HoraInvalida()
                    .MskHoraEntrada.Focus()
                    Return True
                End If

                'COD ORIGEM:
                If .CmbCodOrigem.Text = String.Empty Then
                    ObjMensagens.TodosCamposDevemSerPreenchidos()
                    .CmbCodOrigem.Focus()
                    Return True
                ElseIf Not IsNumeric(.CmbCodOrigem.Text) Then
                    ObjMensagens.CampoNumerico("Origem (Código)")
                    .CmbCodOrigem.Focus()
                    Return True
                ElseIf .CmbCodOrigem.SelectedIndex < 0 Then
                    ObjMensagens.SelecaoInvalidaComboBox("Origem (Código)")
                    .CmbCodOrigem.Focus()
                    Return True
                End If

                'DESCR ORIGEM:
                If .CmbOrigem.Text = String.Empty Then
                    ObjMensagens.TodosCamposDevemSerPreenchidos()
                    .CmbOrigem.Focus()
                    Return True
                ElseIf .CmbOrigem.SelectedIndex < 0 Then
                    ObjMensagens.SelecaoInvalidaComboBox("Origem")
                    .CmbOrigem.Focus()
                    Return True
                End If
            End If

            'CONSISTENCIAS DOS CAMPOS COMUNS PARA INCLUSÃO DE NOVO REGISTRO E INCLUSÃO DE NOVO HISTÓRICO:
            'DATA SAIDA:
            If .MskDataSaida.Text = DataNula Then
                ObjMensagens.TodosCamposDevemSerPreenchidos()
                .MskDataSaida.Focus()
                Return True
            ElseIf Not IsDate(.MskDataSaida.Text) Then
                ObjMensagens.DataInvalida()
                .MskDataSaida.Focus()
                Return True
            End If

            'HORA SAIDA:
            If .MskHoraSaida.Text = HoraNula Then
                ObjMensagens.TodosCamposDevemSerPreenchidos()
                .MskHoraSaida.Focus()
                Return True
            ElseIf Not IsDate(.MskHoraSaida.Text) Then
                ObjMensagens.HoraInvalida()
                .MskHoraSaida.Focus()
                Return True
            End If

            'COD DESTINO:
            If .CmbCodDestino.Text = String.Empty Then
                ObjMensagens.TodosCamposDevemSerPreenchidos()
                .CmbCodDestino.Focus()
                Return True
            ElseIf Not IsNumeric(.CmbCodDestino.Text) Then
                ObjMensagens.CampoNumerico("Destino (Código)")
                .CmbCodDestino.Focus()
                Return True
            ElseIf .CmbCodDestino.SelectedIndex < 0 Then
                ObjMensagens.SelecaoInvalidaComboBox("Destino (Código)")
                .CmbCodDestino.Focus()
                Return True
            End If

            'DESCR DESTINO:
            If .CmbDestino.Text = String.Empty Then
                ObjMensagens.TodosCamposDevemSerPreenchidos()
                .CmbDestino.Focus()
                Return True
            ElseIf .CmbDestino.SelectedIndex < 0 Then
                ObjMensagens.SelecaoInvalidaComboBox("Destino")
                .CmbDestino.Focus()
                Return True
            End If

        End With

        Return False

    End Function

    Private Sub MskDataEntrada_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles MskDataEntrada.GotFocus

        If Me.MskDataEntrada.Text <> DataNula Then
            ObjControles.SelecionaTodoTexto(Me.MskDataEntrada)
        End If

    End Sub

    Private Sub MskDataSaida_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles MskDataSaida.GotFocus

        If Me.MskDataSaida.Text <> DataNula Then
            ObjControles.SelecionaTodoTexto(Me.MskDataSaida)
        ElseIf Me.MskDataSaida.Text = DataNula Then
            Me.MskDataSaida.Text = Now
            ObjControles.SelecionaTodoTexto(Me.MskDataSaida)
        End If

    End Sub

    Private Sub MskHoraEntrada_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles MskHoraEntrada.GotFocus

        If Me.MskHoraEntrada.Text <> HoraNula Then
            ObjControles.SelecionaTodoTexto(Me.MskHoraEntrada)
        End If

    End Sub

    Private Sub MskHoraSaida_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles MskHoraSaida.GotFocus

        If Me.MskHoraSaida.Text <> HoraNula Then
            ObjControles.SelecionaTodoTexto(Me.MskHoraSaida)
        ElseIf Me.MskHoraSaida.Text = HoraNula Then
            Me.MskHoraSaida.Text = Format(Now, "HH:mm")
            ObjControles.SelecionaTodoTexto(Me.MskHoraSaida)
        End If

    End Sub

    Private Sub CmbCodOrigem_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmbCodOrigem.SelectedIndexChanged

        Me.CmbOrigem.SelectedIndex = Me.CmbCodOrigem.SelectedIndex

    End Sub

    Private Sub CmbOrigem_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmbOrigem.SelectedIndexChanged

        Me.CmbCodOrigem.SelectedIndex = Me.CmbOrigem.SelectedIndex

    End Sub

    Private Sub CmbCodDestino_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmbCodDestino.SelectedIndexChanged

        Me.CmbDestino.SelectedIndex = Me.CmbCodDestino.SelectedIndex

    End Sub

    Private Sub CmbDestino_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmbDestino.SelectedIndexChanged

        Me.CmbCodDestino.SelectedIndex = Me.CmbDestino.SelectedIndex

    End Sub

    Private Sub CmdPesquisa_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdPesquisa.Click

        FormPesquisaNome.ObjFormularioPaiPesquisa = ObjFormPai.Historicos
        FormPesquisaNome.Show(Me)

    End Sub

End Class