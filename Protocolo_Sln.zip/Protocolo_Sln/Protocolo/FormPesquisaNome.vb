﻿Public Class FormPesquisaNome

    Dim ObjControles As New ClassControles
    Friend ObjFormularioPaiPesquisa As ObjFormPai

    Private Sub FormPesquisaNome_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If e.Alt = False Then
            Select Case e.KeyCode
                Case 27 'ESC - SAIR
                    If Me.CmdSair.Enabled = True Then
                        CmdSair_Click(Nothing, Nothing)
                    End If
            End Select
        End If

    End Sub

    Private Sub TxtNome_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtNome.KeyDown

        If e.KeyCode = Keys.Enter Then
            CmdPesquisar_Click(Nothing, Nothing)
        End If

    End Sub

    Private Sub TxtNome_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtNome.TextChanged

        If Me.TxtNome.Text <> String.Empty Then
            CmdPesquisar.Enabled = True
        Else
            CmdPesquisar.Enabled = False
        End If

    End Sub

    Private Sub DataGridView1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles DataGridView1.KeyDown

        If e.KeyCode = Keys.Enter Then
            CmdSelecionar_Click(Nothing, Nothing)
        End If

    End Sub

    Private Sub DataGridView1_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGridView1.SelectionChanged

        If Me.DataGridView1.RowCount > 0 Then
            CmdSelecionar.Enabled = True
            CmdLimpar.Enabled = True
        Else
            CmdSelecionar.Enabled = False
            CmdLimpar.Enabled = False
        End If

    End Sub

    Private Sub CmdPesquisar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdPesquisar.Click

        PreencherFlexGridPesquisaInteressados(Me.TxtNome.Text)
        If Me.DataGridView1.RowCount = 0 Then
            Me.TxtNome.Focus()
            Me.TxtNome.Text = String.Empty
            Exit Sub
        End If
        Me.DataGridView1.Focus()

    End Sub

    Private Sub PreencherFlexGridPesquisaInteressados(ByVal StrNome As String)

        Dim ConsultaSQL As String = String.Empty
        ConsultaSQL = "SELECT CODIGO, DESCRICAO " & _
                              "FROM INTERESSADOS " & _
                              "WHERE DESCRICAO LIKE '%" & StrNome & "%' " & _
                              "ORDER BY DESCRICAO"

        'CHAMA FUNÇÃO PARA PREENCHER O DATA_GRID_VIEW:
        ObjControles.PreencheDataGridView(ConsultaSQL, Me.DataGridView1, ClassControles.LinhaDataGridSelecionar.Primeira)
        If Me.DataGridView1.RowCount > 0 Then
            Dim ColunasOcultar() As Short = {}
            Dim LarguraColunas() As Short = {0, 100, 1, 450}
            ObjControles.FormataDataGridView(Me.DataGridView1, ColunasOcultar, LarguraColunas)
        End If

    End Sub

    Private Sub CmdSelecionar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdSelecionar.Click

        If Me.DataGridView1.RowCount = 0 Then
            MessageBox.Show("Não há registros a serem selecionados.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If

        If ObjFormularioPaiPesquisa = ObjFormPai.Historicos Then
            FormHistoricos.TxtCodInteressado.Text = Me.DataGridView1.Rows(Me.DataGridView1.CurrentCellAddress.Y).Cells(0).Value.ToString
            FormHistoricos.TxtDescrInteressado.Text = Me.DataGridView1.Rows(Me.DataGridView1.CurrentCellAddress.Y).Cells(1).Value.ToString
            Me.Close()
            FormHistoricos.Show()
            Me.Dispose()
        ElseIf ObjFormularioPaiPesquisa = ObjFormPai.Registos Then
            FormRegistros.TxtCodigo.Text = Me.DataGridView1.Rows(Me.DataGridView1.CurrentCellAddress.Y).Cells(0).Value.ToString
            Me.Close()
            FormRegistros.Show()
            FormRegistros.TxtCodigo_LostFocus(Nothing, Nothing)
            Me.Dispose()
        End If

    End Sub

    Private Sub CmdLimpar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdLimpar.Click

        Me.DataGridView1.DataSource = Nothing
        Me.TxtNome.Text = String.Empty
        Me.CmdSelecionar.Enabled = False
        Me.CmdLimpar.Enabled = False
        Me.TxtNome.Focus()

    End Sub

    Private Sub CmdSair_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdSair.Click

        Me.Close()
        Select Case ObjFormularioPaiPesquisa
            Case ObjFormPai.Historicos
                FormHistoricos.Show()
            Case ObjFormPai.Registos
                FormRegistros.Show()
        End Select
        Me.Dispose()

    End Sub

End Class