﻿Imports System.IO
Imports FirebirdSql.Data.FirebirdClient

Public Class ClassImportacoes

    Private ObjMetodosGlobais As New ClassMetodosGlobais

    Structure Interessado
        Dim Codigo As Integer
        Dim Descricao As String
    End Structure

    Sub ImportarInteressado(ByRef Diretorio As String, ByRef DescricaoArquivo As String)

        Dim ObjInteressado() As Interessado = Nothing
        Dim NumInteressados As Integer = 0
        Dim LogErros(0) As Short
        Dim PrimLinha As Boolean = True
        Dim Registro As String = String.Empty
        Dim CodigoAux As String = String.Empty
        Dim DescrAux As String = String.Empty
        Dim Inconsistencia As Boolean = False

        On Error GoTo TrataErro

        Dim Leitor As StreamReader = File.OpenText(Diretorio & "\" & DescricaoArquivo)
        Do While Not Leitor.EndOfStream
            NumInteressados += 1
            If PrimLinha = True Then
                ReDim ObjInteressado(1)
                PrimLinha = False
            Else
                If Inconsistencia = True Then
                    Inconsistencia = False
                Else
                    ReDim Preserve ObjInteressado(UBound(ObjInteressado) + 1)
                End If
            End If
            Registro = Leitor.ReadLine
            For col As Short = 1 To Registro.Length - 1
                If Mid(Registro, col, 1) = "," Then
                    CodigoAux = Left(Registro, col - 1)
                    DescrAux = Mid(Registro, col + 1, Registro.Length - col)
                    Exit For
                End If
            Next

            'FAZ CONSISTENCIA NO CAMPO CODIGO:
            If Not IsNumeric(CodigoAux) Then 'CODIGO
                ReDim Preserve LogErros(UBound(LogErros) + 1)
                LogErros(LogErros.Length - 1) = NumInteressados
                NumInteressados -= 1
                Inconsistencia = True
            Else 'SE NÃO HOUVER INCONSISTENCIA, GRAVA VALORES NA ESTRUTURA:
                ObjInteressado(NumInteressados).Codigo = CodigoAux
                ObjInteressado(NumInteressados).Descricao = DescrAux
            End If
        Loop
        Leitor.Close()

        'IMPORTA DADOS SEM ERROS PARA O BANCO DE DADOS:
        Dim COMANDO As New FbCommand(String.Empty, Conexao)
        Conexao.Open()

        Dim i As Integer

        For i = 1 To ObjInteressado.Length - 1
            COMANDO.CommandText = "INSERT INTO INTERESSADOS(CODIGO, DESCRICAO) " & " VALUES(?, ?)"
            COMANDO.Parameters.Add(String.Empty, FbDbType.Integer)
            COMANDO.Parameters(0).Value = ObjInteressado(i).Codigo
            COMANDO.Parameters.Add(String.Empty, FbDbType.VarChar)
            COMANDO.Parameters(1).Value = ObjInteressado(i).Descricao
            COMANDO.ExecuteNonQuery()
            COMANDO.Parameters.Clear()
            'PROGRESS BAR:
            With FormImportacoes.ProgressBar1
                If CShort(i / ((ObjInteressado.Length - 1) / 100)) > 100 Then
                    .Value = 100
                Else
                    .Value = (CShort(i / ((ObjInteressado.Length - 1) / 100)))
                End If
            End With
        Next i
        Conexao.Close()

        'CASO HAJA ERROS NO ARQUIVO, INFORMA AO USUÁRIO AS LINHAS CORROMPIDAS:
        If LogErros.Length > 1 Then
            Dim StrLinhasErro As String = String.Empty
            For j As Integer = 1 To LogErros.Length - 1
                StrLinhasErro &= "Linha " & LogErros(j) & vbNewLine
            Next j
            MessageBox.Show("O arquivo foi importado. No entanto, as seguintes linhas continham dados corrompidos/codigos não numéricos e foram ignoradas: " & vbNewLine & StrLinhasErro, "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Exit Sub
        End If

        MessageBox.Show("Arquivo importado com sucesso.", "Processo finalizado.", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Exit Sub

TrataErro:
        If COMANDO.Parameters.Count > 0 Then
            COMANDO.Parameters.Clear()
        End If
        If (Err.Number = 13) Then 'Time Mismatch
            MsgBox("Há dados corrompidos no arquivo." & vbNewLine & "Linha: " & i & _
                   ". O arquivo foi importado até a linha anterior. Verifique, por favor.", MsgBoxStyle.Exclamation, "Atenção!")
        ElseIf (Err.Number <> 0) Then
            If i < 0 Then
                i = 0
            Else
                i -= 1
            End If
            MsgBox("Ocorreu um erro inesperado. O arquivo não foi importado por completo." & vbNewLine & _
                   "Descrição do Erro: " & Err.Description & vbNewLine & _
                   "Contexto do Erro: " & Err.HelpContext & vbNewLine & _
                   "Linhas importadas: " & i, MsgBoxStyle.Exclamation, "Atenção!")
        End If
        Conexao.Close()

    End Sub

    Function VerificaArquivoExiste(ByVal CaminhoArquivo As String) As Boolean

        Dim Arquivo As New FileInfo(CaminhoArquivo)

        If Arquivo.Exists Then
            Return True
        Else
            Return False
        End If

    End Function

End Class