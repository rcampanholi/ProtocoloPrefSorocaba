﻿Public Class ClassMensagens

    Sub UsuarioNaoHabilitado()

        MessageBox.Show("Desculpe, você não tem permissões para executar esta ação.", "Acesso negado.", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

    End Sub

    Sub TodosCamposDevemSerPreenchidos()

        MessageBox.Show("Todos os campos devem ser preenchidos.", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

    End Sub

    Sub CampoNumerico(ByVal NomeCampo As String)

        MessageBox.Show("O campo '" & NomeCampo & "' aceita somente números.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

    End Sub

    Sub DataInvalida()

        MessageBox.Show("Data inválida.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

    End Sub

    Sub DataInicioMaiorQueFim()

        MessageBox.Show("A data de início não pode ser maior que a data de término.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

    End Sub

    Sub HoraInvalida()

        MessageBox.Show("Horário inválido.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

    End Sub

    Sub SelecaoInvalidaComboBox(ByVal NomeDoCampo As String)

        MessageBox.Show("O item selecionado em '" & NomeDoCampo & "' é inválido. Selecione um item da lista.", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

    End Sub

    Sub CodigoNaoExiste(ByVal NomeDoCampo As String)

        MessageBox.Show("O código informado no campo '" & NomeDoCampo & "' não existe no banco de dados. Por favor, verifique.", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

    End Sub

    Sub PreenchimentoNumEAnoObrigatorio(ByVal NomeDoCampo As String)

        MessageBox.Show("O preenchimento do campo '" & NomeDoCampo & "' é obrigatório para o tipo de documento informado.", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

    End Sub

    Sub EmailsInvalidos(ByVal StrEmailsInvalidos As String)

        If StrEmailsInvalidos <> String.Empty Then
            MessageBox.Show("Os seguintes e-mails não foram encontrados ou são inválidos: " & vbNewLine & StrEmailsInvalidos, "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If

    End Sub

    Sub DestinatSemEmail(ByVal StrDestinatSemEmail As String)

        If StrDestinatSemEmail <> String.Empty Then
            MessageBox.Show("Os seguintes destinatários não receberão mensagens, pois não possuem e-mail cadastrado: " & vbNewLine & StrDestinatSemEmail, "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If

    End Sub

    Sub EmailsNaoCadastrados(DestinatSemEmailCadastrado As String)
        Throw New NotImplementedException
    End Sub

End Class
