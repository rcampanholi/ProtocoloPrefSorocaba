﻿Public Class ClassMetodosGlobais

    Function ConverteDataFormatoAmericano(ByVal DataConverter As Date) As String

        Dim DataConvertida As String = DataConverter.Month & "/" & DataConverter.Day & "/" & DataConverter.Year

        Return DataConvertida

    End Function

    Function ConverteVirgulaEmPonto(ByVal NumConverter As Decimal) As String

        Dim StrNumConverter As String = NumConverter.ToString
        Dim StrNumConvertido As String = String.Empty
        Dim CharAux As Char

        For i As Integer = 1 To Len(StrNumConverter)
            CharAux = Mid(StrNumConverter, i, 1)
            If CharAux = "," Then
                StrNumConvertido &= "."
            Else
                StrNumConvertido &= CharAux
            End If
        Next

        Return StrNumConvertido

    End Function

    Function ConverteVirgulaEmPontoStr(ByVal NumConverter As String) As String

        Dim StrNumConvertido As String = String.Empty
        Dim CharAux As Char

        For i As Integer = 1 To Len(NumConverter)
            CharAux = Mid(NumConverter, i, 1)
            If CharAux = "," Then
                StrNumConvertido &= "."
            Else
                StrNumConvertido &= CharAux
            End If
        Next

        Return StrNumConvertido

    End Function

    Function EncontraPrimeiroNomeFuncionario(ByVal NomeCompleto As String) As String

        Dim NomeAux As String = String.Empty

        For i As Short = 1 To Len(NomeCompleto)
            If Mid(NomeCompleto, i, 1) <> " " Then
                NomeAux &= Mid(NomeCompleto, i, 1)
            Else
                Return NomeAux
            End If
        Next

        Return NomeAux

    End Function

    Function DataInicioMenorQueFim(ByVal DataIni As Date, ByVal DataFim As Date) As Boolean

        If DataFim <= DataIni Then
            Return False
        Else
            Return True
        End If

    End Function

    Function ConverteValorNulo(ByVal Valor As Object) As Decimal

        If IsDBNull(Valor) Then
            Return 0
        Else
            Return Valor
        End If

    End Function

    Function ConverteValorNuloStr(ByVal Valor As Object) As String

        If IsDBNull(Valor) Then
            Return String.Empty
        Else
            Return Valor
        End If

    End Function


End Class
