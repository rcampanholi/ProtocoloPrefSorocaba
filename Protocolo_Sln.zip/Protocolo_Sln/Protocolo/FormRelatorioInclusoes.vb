﻿
Public Class FormRelatorioInclusoes

    Private Enum TipoRelatorio
        EMail = 1
        Impressao = 2
    End Enum

    Dim ObjControles As New ClassControles
    Private ObjTipoRelatorio As TipoRelatorio
    Dim ListItensAutoCheckCancel As Boolean = False 'VARIAVEL USADA PARA CANCELAR ROTINA DE MUDANÇA DO ESTADO DE CHECK BOX, DEVIDO À ENTRADA AUTOMATICA NA ROTINA, QUANDO ACIONADOS OS ITENS

    Private Sub FormRelatorioInclusoes_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If e.Alt = False Then
            Select Case e.KeyCode
                Case 27 'ESC - SAIR
                    If Me.CmdSair.Enabled = True Then
                        CmdSair_Click(Nothing, Nothing)
                    End If
            End Select
        End If

    End Sub

    Private Sub FormRelatorioInclusoes_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Me.MskDataEntrada.Focus()
        ObjControles.SelecionaTodoTexto(Me.MskDataEntrada)

    End Sub

    Private Sub FormRelatorioInclusoes_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed

        FormPrincipal.Show()

    End Sub

    Private Sub CmdGerarEmails_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdGerarEmails.Click

        If CamposInconsistentes() = True Then
            Exit Sub
        End If

        ObjTipoRelatorio = TipoRelatorio.EMail
        EnviarRelatorioParaSaida()
        MessageBox.Show("E-mails enviados", "Relatório", MessageBoxButtons.OK, MessageBoxIcon.Information)

    End Sub

    Private Sub CmdImprimir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdImprimir.Click

        If CamposInconsistentes() = True Then
            Exit Sub
        End If

        ObjTipoRelatorio = TipoRelatorio.Impressao
        EnviarRelatorioParaSaida()

    End Sub

    Private Sub EnviarRelatorioParaSaida()

        Dim FiltrosInteressados As String = String.Empty
        Dim FiltrosDestinatarios As String = String.Empty
        Dim FiltrosUsuarios As String = String.Empty
        Dim StrFiltros As String = String.Empty
        Dim DiaAux As Short = 30

        'VERIFICA SE O USUÁRIO USOU FILTROS E CARREGA AS VARIÁVEIS REFERENTES:
        If ChkFiltrarInteressados.Checked = True Then
            FiltrosInteressados = ObjControles.RetornaStrFiltrosListView(Me.LstInteressados, "AND I.CODIGO IN")
        End If
        If ChkFiltrarDestinatários.Checked = True Then
            FiltrosDestinatarios = ObjControles.RetornaStrFiltrosListView(Me.LstDestinatarios, "AND DT.CODIGO IN")
        End If
        If ChkFiltrarUsuarios.Checked = True Then
            FiltrosUsuarios = ObjControles.RetornaStrFiltrosListView(Me.LstUsuarios, "AND U.NOME_USUARIO IN")
        End If

        Dim ObjRelatorios As New ClassRelatorios
        Dim ComandoSQL As String = Me.RetornaComandoSQLEnviarEmails(Me.MskDataEntrada.Text, Me.MskDataSaida.Text, Me.MskHoraEntrada.Text, Me.MskHoraSaida.Text, FiltrosInteressados, FiltrosDestinatarios, FiltrosUsuarios)

        Dim UsuariosSelecionados As Boolean = False
        If FiltrosUsuarios <> String.Empty Then
            UsuariosSelecionados = True
        End If

        If ObjTipoRelatorio = TipoRelatorio.EMail Then
            ObjRelatorios.CriarRelatorio(ComandoSQL, ClassRelatorios.TipoRelatorio.EMail, UsuariosSelecionados)
        ElseIf ObjTipoRelatorio = TipoRelatorio.Impressao Then
            ObjRelatorios.CriarRelatorio(ComandoSQL, ClassRelatorios.TipoRelatorio.Impressao, UsuariosSelecionados)
        End If

        Me.MskDataEntrada.Focus()

    End Sub

    Private Sub CmdSair_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdSair.Click

        Me.Close()
        Me.Dispose()
        FormPrincipal.Show()

    End Sub

    Private Sub ChkFiltrarInteressados_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkFiltrarInteressados.CheckedChanged

        If ChkFiltrarInteressados.Checked = True Then

            If Me.MskDataEntrada.Text = DataNula Or Me.MskDataSaida.Text = DataNula Or Me.MskHoraEntrada.Text = HoraNula Or Me.MskHoraSaida.Text = HoraNula Then
                MessageBox.Show("Informe as datas e horários acima.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Me.ChkFiltrarInteressados.Checked = False
                Me.MskDataEntrada.Focus()
                Exit Sub
            End If

            Dim ObjMetodosGlobais As New ClassMetodosGlobais

            Dim DataIniAux As String = ObjMetodosGlobais.ConverteDataFormatoAmericano(Me.MskDataEntrada.Text)
            Dim DataFimAux As String = ObjMetodosGlobais.ConverteDataFormatoAmericano(Me.MskDataSaida.Text)
            Dim HoraEntradaAux As String = Me.MskHoraEntrada.Text
            Dim HoraSaidaAux As String = Me.MskHoraSaida.Text

            Me.ChkSelecionarTodosInteressados.Enabled = True
            ObjControles.HabilitaDesabilitaControlesGroupBox(Me.GroupInteressados, True)



            Dim ComandoSQL As String = "SELECT I.CODIGO, I.DESCRICAO " & _
                                       "FROM INTERESSADOS I, REGISTROS R, HISTORICO_REGISTROS H " & _
                                       "WHERE I.id_interessado = R.id_interessado " & _
                                       "AND R.id_registro = H.id_registro " & _
                                       "AND (H.data_entrada >= '" & DataIniAux & "' " & _
                                       "or H.DATA_SAIDA <= '" & DataFimAux & "') " & _
                                       "AND (H.hora_entrada >= '" & HoraEntradaAux & "' " & _
                                       "or H.hora_saida <= '" & HoraSaidaAux & "') " & _
                                       "ORDER BY DESCRICAO"
            ObjControles.PreencheListView(Me.LstInteressados, ComandoSQL, 70, 310)
            Me.LstInteressados.GridLines = True
        Else
            Me.ChkSelecionarTodosInteressados.Checked = False
            Me.ChkSelecionarTodosInteressados.Enabled = False
            Me.LstInteressados.Clear()
            Me.LstInteressados.GridLines = False
            ObjControles.HabilitaDesabilitaControlesGroupBox(Me.GroupInteressados, False)
        End If

    End Sub

    Private Sub ChkFiltrarDestinatarios_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkFiltrarDestinatários.CheckedChanged

        If ChkFiltrarDestinatários.Checked = True Then
            Me.ChkSelecionarTodosDestinatarios.Enabled = True
            ObjControles.HabilitaDesabilitaControlesGroupBox(Me.GroupDestinatarios, True)
            Dim ComandoSQL As String = "SELECT CODIGO, DESCRICAO FROM DESTINATARIOS " & _
                                       "ORDER BY DESCRICAO"
            ObjControles.PreencheListView(Me.LstDestinatarios, ComandoSQL, 70, 310)
            Me.LstDestinatarios.GridLines = True
        Else
            Me.ChkSelecionarTodosDestinatarios.Checked = False
            Me.ChkSelecionarTodosDestinatarios.Enabled = False
            Me.LstDestinatarios.Clear()
            Me.LstDestinatarios.GridLines = False
            ObjControles.HabilitaDesabilitaControlesGroupBox(Me.GroupDestinatarios, False)
        End If

    End Sub

    Private Sub ChkFiltrarUsuarios_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkFiltrarUsuarios.CheckedChanged

        If Me.ChkFiltrarUsuarios.Checked = True Then
            If ObjEstrUsuario.PermissaoIncluir = False Or ObjEstrUsuario.PermissaoAlterar = False Then
                Dim ObjMensagens As New ClassMensagens
                ObjMensagens.UsuarioNaoHabilitado()
                Me.ChkFiltrarUsuarios.Checked = False
                Exit Sub
            End If
        End If

        If ChkFiltrarUsuarios.Checked = True Then

            Me.ChkSelecionarTodosUsuarios.Enabled = True
            ObjControles.HabilitaDesabilitaControlesGroupBox(Me.GroupUsuarios, True)



            Dim ComandoSQL As String = "SELECT U.NOME_USUARIO, U.NOME_FUNCIONARIO " & _
                                       "FROM USUARIOS U " & _
                                       "ORDER BY NOME_USUARIO"
            ObjControles.PreencheListView(Me.LstUsuarios, ComandoSQL, 110, 300)
            Me.LstUsuarios.GridLines = True
        Else
            Me.ChkSelecionarTodosUsuarios.Checked = False
            Me.ChkSelecionarTodosUsuarios.Enabled = False
            Me.LstUsuarios.Clear()
            Me.LstUsuarios.GridLines = False
            ObjControles.HabilitaDesabilitaControlesGroupBox(Me.GroupUsuarios, False)
        End If

    End Sub

    Private Sub TxtEncontrarInteressado_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtEncontrarInteressado.GotFocus

        ObjControles.FormataTextBox(Me.TxtEncontrarInteressado, True, String.Empty)

    End Sub

    Private Sub TxtEncontrarInteressado_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtEncontrarInteressado.KeyDown

        If e.KeyCode = Keys.Return Then
            LstInteressados.Focus()
        End If

    End Sub

    Private Sub TxtEncontrarInteressado_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtEncontrarInteressado.LostFocus

        ObjControles.FormataTextBox(Me.TxtEncontrarInteressado, False, "Encontrar Interessado")

    End Sub

    Private Sub TxtEncontrarInteressado_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtEncontrarInteressado.TextChanged

        If Me.TxtEncontrarInteressado.Enabled = True And Me.TxtEncontrarInteressado.Text <> String.Empty And TxtEncontrarInteressado.Text <> "Encontrar Interessado" Then
            ObjControles.EncontraRegistroListView(TxtEncontrarInteressado.Text, Me.LstInteressados, 1)
        End If

    End Sub

    Private Sub TxtEncontrarDestinatario_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtEncontrarDestinatario.GotFocus

        ObjControles.FormataTextBox(Me.TxtEncontrarDestinatario, True, String.Empty)

    End Sub

    Private Sub TxtEncontrarDestinatario_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtEncontrarDestinatario.KeyDown

        If e.KeyCode = Keys.Return Then
            LstDestinatarios.Focus()
        End If

    End Sub

    Private Sub TxtEncontrarDestinatario_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtEncontrarDestinatario.LostFocus

        ObjControles.FormataTextBox(Me.TxtEncontrarDestinatario, False, "Encontrar Destinatário")

    End Sub

    Private Sub TxtEncontrarDestinatario_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtEncontrarDestinatario.TextChanged

        If Me.TxtEncontrarDestinatario.Enabled = True And Me.TxtEncontrarDestinatario.Text <> String.Empty And TxtEncontrarDestinatario.Text <> "Encontrar Destinatário" Then
            ObjControles.EncontraRegistroListView(TxtEncontrarDestinatario.Text, Me.LstDestinatarios, 1)
        End If

    End Sub

    Private Sub TxtEncontrarUsuario_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtEncontrarUsuario.GotFocus

        ObjControles.FormataTextBox(Me.TxtEncontrarUsuario, True, String.Empty)

    End Sub

    Private Sub TxtEncontrarUsuario_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtEncontrarUsuario.KeyDown

        If e.KeyCode = Keys.Return Then
            LstUsuarios.Focus()
        End If

    End Sub

    Private Sub TxtEncontrarUsuario_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtEncontrarUsuario.LostFocus

        ObjControles.FormataTextBox(Me.TxtEncontrarUsuario, False, "Encontrar Usuário")

    End Sub

    Private Sub TxtEncontrarUsuario_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtEncontrarUsuario.TextChanged

        If Me.TxtEncontrarUsuario.Enabled = True And Me.TxtEncontrarUsuario.Text <> String.Empty And TxtEncontrarUsuario.Text <> "Encontrar Usuário" Then
            ObjControles.EncontraRegistroListView(TxtEncontrarUsuario.Text, Me.LstUsuarios, 1)
        End If

    End Sub

    Private Function CamposInconsistentes() As Boolean

        Dim ObjMensagens As New ClassMensagens

        With Me
            'CAMPO DATA INICIAL
            If .MskDataEntrada.Text = DataNula Then
                ObjMensagens.TodosCamposDevemSerPreenchidos()
                .MskDataEntrada.Focus()
                Return True
            ElseIf Not IsDate(.MskDataEntrada.Text) Then
                ObjMensagens.DataInvalida()
                .MskDataEntrada.Focus()
                Return True
            End If

            'CAMPO DATA FINAL
            If .MskDataSaida.Text = DataNula Then
                ObjMensagens.TodosCamposDevemSerPreenchidos()
                .MskDataSaida.Focus()
                Return True
            ElseIf Not IsDate(.MskDataSaida.Text) Then
                ObjMensagens.DataInvalida()
                .MskDataSaida.Focus()
                Return True
            End If

            'CAMPO HORA INICIAL
            If .MskHoraEntrada.Text = HoraNula Then
                ObjMensagens.TodosCamposDevemSerPreenchidos()
                .MskHoraEntrada.Focus()
                Return True
            ElseIf Not IsDate(.MskHoraEntrada.Text) Then
                ObjMensagens.HoraInvalida()
                .MskHoraEntrada.Focus()
                Return True
            End If

            'CAMPO HORA FINAL
            If .MskHoraSaida.Text = HoraNula Then
                ObjMensagens.TodosCamposDevemSerPreenchidos()
                .MskHoraSaida.Focus()
                Return True
            ElseIf Not IsDate(.MskHoraSaida.Text) Then
                ObjMensagens.HoraInvalida()
                .MskHoraSaida.Focus()
                Return True
            End If

        End With

        Return False

    End Function

    Private Function RetornaComandoSQLEnviarEmails(ByVal DataEntrada As Date, ByVal DataSaida As Date, ByVal HoraEntrada As String, ByVal HoraSaida As String, ByVal StrFiltroInteressados As String, ByVal StrFiltroDestinatarios As String, ByVal StrFiltroUsuarios As String) As String

        Dim ObjMetodosGlobais As New ClassMetodosGlobais

        Dim DataIni As String = ObjMetodosGlobais.ConverteDataFormatoAmericano(DataEntrada)
        Dim DataFim As String = ObjMetodosGlobais.ConverteDataFormatoAmericano(DataSaida)
        Dim StrIntervaloHorario As String = String.Empty
        If HoraEntrada <> String.Empty Then
            HoraEntrada &= ":00"
            HoraSaida &= ":59"
            StrIntervaloHorario = "and H.hora_inclusao between '" & HoraEntrada & "' and '" & HoraSaida & "' " & vbNewLine
        End If
        Dim StrUsuarios As String = String.Empty
        If StrFiltroUsuarios = String.Empty Then
            StrUsuarios = "AND U.ID_USUARIO = " & ObjEstrUsuario.IDUsuario
        Else
            StrUsuarios = StrFiltroUsuarios
        End If


        Dim ComandoSQL As String = "select I.codigo as COD_INTERESSADO, I.descricao as INTERESSADO, R.procedencia, " & _
                                   "R.assunto, DC.descricao as TIPO_DOC, R.num_doc, R.ano_doc, " & _
                                        "(select DT1.descricao AS ORIGEM " & _
                                            "from DESTINATARIOS DT1 " & _
                                            "where H.id_destinat_origem = DT1.id_destinatario) AS ORIGEM, " & _
                                        "DT.codigo as COD_DESTINAT, DT.descricao AS DESTINATARIO, DT.email, " & _
                                        "H.data_entrada, H.data_saida, H.observacao, H.data_inclusao, H.hora_inclusao " & _
                                        "from DESTINATARIOS DT, HISTORICO_REGISTROS H, INTERESSADOS I, REGISTROS R, DOCUMENTOS DC, USUARIOS U " & _
                                   "where DC.id_documento = R.id_tipo_doc " & _
                                   "and DT.id_destinatario = H.id_destinat_destino " & _
                                   "and R.id_interessado = I.id_interessado " & _
                                   "and H.id_registro = R.id_registro " & _
                                   "and H.data_inclusao between '" & DataIni & "' and '" & DataFim & "' " & _
                                   StrIntervaloHorario & StrFiltroInteressados & StrFiltroDestinatarios & " " & _
                                   "and H.id_usuario = U.ID_USUARIO " & StrUsuarios & " " & _
                                   "order by DT.descricao, I.descricao, R.assunto "
        Return ComandoSQL

    End Function

    Private Sub MskDataEntrada_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles MskDataEntrada.GotFocus

        If Me.MskDataEntrada.Text = DataNula Then
            Me.MskDataEntrada.Text = Now
            ObjControles.SelecionaTodoTexto(Me.MskDataEntrada)
        Else
            ObjControles.SelecionaTodoTexto(Me.MskDataEntrada)
        End If

    End Sub

    Private Sub MskDataSaida_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles MskDataSaida.GotFocus

        If Me.MskDataSaida.Text = DataNula Then
            Me.MskDataSaida.Text = Now
            ObjControles.SelecionaTodoTexto(Me.MskDataSaida)
        Else
            ObjControles.SelecionaTodoTexto(Me.MskDataSaida)
        End If

    End Sub

    Private Sub MskHoraEntrada_GotFocus(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MskHoraEntrada.GotFocus

        If Me.MskHoraEntrada.Text = HoraNula Then
            Me.MskHoraEntrada.Text = "08:00"
            ObjControles.SelecionaTodoTexto(Me.MskHoraEntrada)
        Else
            ObjControles.SelecionaTodoTexto(Me.MskHoraEntrada)
        End If

    End Sub

    Private Sub MskHoraSaida_GotFocus(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MskHoraSaida.GotFocus

        If Me.MskHoraSaida.Text = HoraNula Then
            Me.MskHoraSaida.Text = "17:00"
            ObjControles.SelecionaTodoTexto(Me.MskHoraSaida)
        Else
            ObjControles.SelecionaTodoTexto(Me.MskHoraSaida)
        End If

    End Sub

    Private Sub ChkSelecionarTodosInteressados_CheckedChanged(sender As Object, e As EventArgs) Handles ChkSelecionarTodosInteressados.CheckedChanged

        If Me.ChkSelecionarTodosInteressados.CheckState = CheckState.Indeterminate Then
            Exit Sub
        End If

        Dim Acao As Boolean = False
        ListItensAutoCheckCancel = True

        If Me.ChkSelecionarTodosInteressados.Checked = True Then
            Acao = True
        End If

        For i As Short = 0 To Me.LstInteressados.Items.Count - 1
            Me.LstInteressados.Items(i).Checked = Acao
        Next

    End Sub

    Private Sub ChkSelecionarTodosDestinatarios_CheckedChanged(sender As Object, e As EventArgs) Handles ChkSelecionarTodosDestinatarios.CheckedChanged

        If Me.ChkSelecionarTodosDestinatarios.CheckState = CheckState.Indeterminate Then
            Exit Sub
        End If

        Dim Acao As Boolean = False
        ListItensAutoCheckCancel = True

        If Me.ChkSelecionarTodosDestinatarios.Checked = True Then
            Acao = True
        End If

        For i As Short = 0 To Me.LstDestinatarios.Items.Count - 1
            Me.LstDestinatarios.Items(i).Checked = Acao
        Next

    End Sub

    Private Sub MudaStatusCheckBox(ByRef ObjListView As ListView, ObjCheckBox As CheckBox)

        Dim NumItensMarcados As Short = 0

        For i As Short = 0 To ObjListView.Items.Count - 1
            If ObjListView.Items(i).Checked = True Then
                NumItensMarcados += 1
            End If
        Next

        If NumItensMarcados = 0 Then
            ObjCheckBox.CheckState = CheckState.Unchecked
        ElseIf NumItensMarcados = ObjListView.Items.Count Then
            ObjCheckBox.CheckState = CheckState.Checked
        Else
            ObjCheckBox.CheckState = CheckState.Indeterminate
        End If

    End Sub

    Private Sub LstInteressados_Click(sender As Object, e As EventArgs) Handles LstInteressados.Click

        ListItensAutoCheckCancel = False

    End Sub

    Private Sub LstInteressados_ItemChecked(sender As Object, e As ItemCheckedEventArgs) Handles LstInteressados.ItemChecked

        If ListItensAutoCheckCancel = True Then
            Exit Sub
        End If

        MudaStatusCheckBox(Me.LstInteressados, Me.ChkSelecionarTodosInteressados)

    End Sub

    Private Sub LstDestinatarios_Click(sender As Object, e As EventArgs) Handles LstDestinatarios.Click

        ListItensAutoCheckCancel = False

    End Sub

    Private Sub LstDestinatarios_ItemChecked(sender As Object, e As ItemCheckedEventArgs) Handles LstDestinatarios.ItemChecked

        If ListItensAutoCheckCancel = True Then
            Exit Sub
        End If

        MudaStatusCheckBox(Me.LstDestinatarios, Me.ChkSelecionarTodosDestinatarios)

    End Sub

    Private Sub ChkSelecionarTodosUsuarios_CheckedChanged(sender As Object, e As EventArgs) Handles ChkSelecionarTodosUsuarios.CheckedChanged


        If Me.ChkSelecionarTodosUsuarios.CheckState = CheckState.Indeterminate Then
            Exit Sub
        End If

        Dim Acao As Boolean = False
        ListItensAutoCheckCancel = True

        If Me.ChkSelecionarTodosUsuarios.Checked = True Then
            Acao = True
        End If

        For i As Short = 0 To Me.LstUsuarios.Items.Count - 1
            Me.LstUsuarios.Items(i).Checked = Acao
        Next

    End Sub

    Private Sub LstUsuarios_Click(sender As Object, e As EventArgs) Handles LstUsuarios.Click

        ListItensAutoCheckCancel = False

    End Sub

    Private Sub LstUsuarios_ItemChecked(sender As Object, e As ItemCheckedEventArgs) Handles LstUsuarios.ItemChecked

        If ListItensAutoCheckCancel = True Then
            Exit Sub
        End If

        MudaStatusCheckBox(Me.LstUsuarios, Me.ChkSelecionarTodosUsuarios)

    End Sub

End Class