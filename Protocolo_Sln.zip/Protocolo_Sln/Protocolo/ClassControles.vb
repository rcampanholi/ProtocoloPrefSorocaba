﻿Imports FirebirdSql.Data.FirebirdClient

Public Class ClassControles

    Dim ObjMetodosGlobais As New ClassMetodosGlobais

    Enum LinhaDataGridSelecionar
        Primeira = 1
        Ultima = 2
    End Enum

    Sub PreencheDataGridView(ByVal TextoConsultaSQL As String, ByRef ObjDataGridView As DataGridView, ByVal ObjLinhaSelecionar As LinhaDataGridSelecionar)

        Dim COMANDO As New FbCommand(String.Empty, Conexao)

        COMANDO.CommandText = TextoConsultaSQL

        Dim TABELA As New DataTable
        Dim DataAdapter As New FbDataAdapter(COMANDO)

        DataAdapter.Fill(TABELA)
        ObjDataGridView.DataSource = TABELA
        ObjDataGridView.Refresh()

        If ObjDataGridView.RowCount >= 1 Then
            If ObjLinhaSelecionar = LinhaDataGridSelecionar.Primeira Then
                ObjDataGridView.Rows.GetFirstRow(DataGridViewElementStates.Displayed)
            ElseIf ObjLinhaSelecionar = LinhaDataGridSelecionar.Ultima Then
                ObjDataGridView.Rows.GetLastRow(DataGridViewElementStates.Displayed)
            End If
        End If
        TABELA.Dispose()

    End Sub

    Sub FormataDataGridView(ByRef ObjDataGridView As DataGridView, ByRef ColunasOcultar() As Short, ByRef LarguraColunas() As Short)

        With ObjDataGridView
            'OCULTA COLUNAS PASSADAS NO PARÂMETRO:
            For i As Short = 0 To (ColunasOcultar.GetLength(0) - 1)
                .Columns(ColunasOcultar(i)).Visible = False
            Next i
            'FORMATA LARGURA DAS COLUNAS PASSADAS COMO PARÂMETRO:
            For i As Short = 0 To (LarguraColunas.GetLength(0) - 1) Step 2
                .Columns(LarguraColunas(i)).Width = LarguraColunas(i + 1)
            Next i

            'FORMATA CABEÇALHO
            Dim DataGridViewCellStyleAux As New DataGridViewCellStyle
            DataGridViewCellStyleAux.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
            DataGridViewCellStyleAux.BackColor = System.Drawing.SystemColors.Control
            DataGridViewCellStyleAux.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            DataGridViewCellStyleAux.ForeColor = System.Drawing.SystemColors.WindowText
            DataGridViewCellStyleAux.SelectionBackColor = System.Drawing.SystemColors.Highlight
            DataGridViewCellStyleAux.SelectionForeColor = System.Drawing.SystemColors.HighlightText
            DataGridViewCellStyleAux.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
            ObjDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyleAux
        End With

    End Sub

    Sub ColoreCelulasGridView(ByRef ObjDataGrid As DataGridView, ByVal ColunaChave As Short, ByVal ParamMaxNormal As Short, ByVal ParamMaxAmarelo As Short)

        With ObjDataGrid
            For i As Short = 0 To ObjDataGrid.RowCount - 1
                Select .Rows(i).Cells(ColunaChave).Value
                    Case Is <= ParamMaxNormal
                        Exit Select
                    Case Is <= ParamMaxAmarelo
                        .Rows(i).DefaultCellStyle.BackColor = Color.Yellow
                        .Rows(i).DefaultCellStyle.SelectionBackColor = Color.YellowGreen
                    Case Else
                        .Rows(i).DefaultCellStyle.BackColor = Color.Red
                        .Rows(i).DefaultCellStyle.SelectionBackColor = Color.Orange
                End Select
            Next
        End With

    End Sub

    Function EncontraRegistroDataGridView(ByRef FormDataGridView As DataGridView, ByVal ColunaProcurar As Short, ByVal RegistroProcurar As String, ByVal LenRegistro As Short) As Integer

        Dim i As Short
        Dim Linha As Integer = 0

        For i = 0 To (FormDataGridView.Rows.Count - 1)
            If RegistroProcurar = Left(FormDataGridView.Rows(i).Cells(ColunaProcurar).Value, LenRegistro) Then
                FormDataGridView.CurrentCell = FormDataGridView.Rows(i).Cells(1)
                Linha = i
                Return Linha
            End If
        Next i

        Return Linha

    End Function

    Sub SelecionaTodoTexto(ByRef ObjTextBox As System.Windows.Forms.TextBox)

        ObjTextBox.SelectionStart = 0
        ObjTextBox.SelectionLength = ObjTextBox.TextLength

    End Sub

    Sub SelecionaTodoTexto(ByRef ObjMskBox As System.Windows.Forms.MaskedTextBox)

        ObjMskBox.SelectionStart = 0
        ObjMskBox.SelectionLength = ObjMskBox.TextLength

    End Sub

    Sub SelecionaTodoTexto(ByRef ObjComboBox As System.Windows.Forms.ComboBox)

        ObjComboBox.SelectionStart = 0
        ObjComboBox.SelectionLength = Len(ObjComboBox.Text)

    End Sub

    Function EncontraPosicaoRegistroDataGrid(ByRef ObjDataGridView As DataGridView, ByVal ValorBuscado As Integer, ByVal ColunaProcurar As Short) As Integer

        Dim PosicaoRegistro As Integer = 0

        For Linha As Short = 0 To ObjDataGridView.Rows.Count - 1
            If ObjDataGridView.Rows(Linha).Cells(ColunaProcurar).Value = ValorBuscado Then
                PosicaoRegistro = Linha
                Return PosicaoRegistro
            End If
        Next

        Return PosicaoRegistro

    End Function

    Function RetornaStrFiltrosListView(ByRef ObjListView As ListView, ByVal StrLinhaConsultaSQL As String) As String

        Dim StrFiltro As String = String.Empty
        Dim ObjItem As ListViewItem

        For Each ObjItem In ObjListView.Items
            If ObjItem.Checked = True Then
                If StrFiltro = String.Empty Then
                    StrFiltro = "'" & ObjItem.Text & "'"
                Else
                    StrFiltro &= ", " & "'" & ObjItem.Text & "'"
                End If
            End If
        Next
        If StrFiltro <> String.Empty Then
            StrFiltro = " " & StrLinhaConsultaSQL & " (" & StrFiltro & ") " & vbNewLine
        End If

        Return StrFiltro

    End Function

    Sub HabilitaDesabilitaControlesContainer(ByRef ObjPainel As Panel, ByVal Habilitar As Boolean)

        Dim Controle As Control

        For Each Controle In ObjPainel.Controls
            If Not TypeOf Controle Is CheckBox Then
                If Habilitar = True Then
                    Controle.Enabled = True
                Else
                    Controle.Enabled = False
                End If
            End If
        Next

    End Sub

    Sub HabilitaDesabilitaControlesGroupBox(ByRef ObjGroupBox As GroupBox, ByVal Habilitar As Boolean)

        Dim Controle As Control

        For Each Controle In ObjGroupBox.Controls
            If Not TypeOf Controle Is CheckBox Then
                If Habilitar = True Then
                    Controle.Enabled = True
                Else
                    Controle.Enabled = False
                End If
            End If
        Next

    End Sub

    Sub PreencheListView(ByRef ObjListView As ListView, ByVal ComandoSQL As String, ByVal LarguraCol1 As Short, ByVal LarguraCol2 As Short)

        Dim TABELA As FbDataReader
        Dim COMANDO As New FbCommand(String.Empty, Conexao)

        COMANDO.CommandText = ComandoSQL
        Conexao.Open()
        TABELA = COMANDO.ExecuteReader

        With ObjListView
            .Clear()
            .Columns.Add(TABELA.GetName(0), LarguraCol1, HorizontalAlignment.Center)
            .Columns.Add(TABELA.GetName(1), LarguraCol2, HorizontalAlignment.Center)
        End With

        While TABELA.Read
            Dim Codigo As String = TABELA.Item(0)
            Dim Lista As New ListViewItem(Codigo)
            Lista.SubItems.Add(TABELA(1))
            ObjListView.Items.Add(Lista)
        End While

        TABELA.Close()
        Conexao.Close()
        COMANDO.Dispose()

    End Sub

    Sub FormataTextBox(ByRef ObjTextBox As TextBox, ByVal FocoSetado As Boolean, ByVal StrTexto As String)

        With ObjTextBox
            If FocoSetado = True Then
                .ForeColor = Color.Black
                .Text = StrTexto
            Else
                .ForeColor = Color.DarkGray
                .Text = StrTexto
            End If
        End With

    End Sub

    Sub EncontraRegistroListView(ByVal Texto As String, ByRef ObjListView As ListView, ByVal ColSubItem As Byte)

        For i As Short = 0 To ObjListView.Items.Count - 1
            If Left(ObjListView.Items(i).SubItems(ColSubItem).Text, Texto.Length).ToUpper = Texto.ToUpper Then
                ObjListView.Items(i).Selected = True
                ObjListView.Items(i).EnsureVisible()
                ObjListView.Items(i).Focused = True
                Exit Sub
            End If
        Next i

    End Sub

End Class
