﻿Imports FirebirdSql.Data.FirebirdClient

Public Class ClassDestinatarios

    Dim ObjMetodosGlobais As New ClassMetodosGlobais

    ' VERIFICA SE O CÓDIGO JÁ EXISTE PARA NOVA INCLUSÃO
    Function CodigoJaExiste(ByVal Codigo As Integer) As Boolean

        Dim Comando As New FbCommand(String.Empty, Conexao)

        Comando.CommandText = "SELECT CODIGO " & _
                                  "FROM DESTINATARIOS " & _
                                  "WHERE CODIGO = " & Codigo
        Conexao.Open()
        If ObjMetodosGlobais.ConverteValorNulo(Comando.ExecuteScalar) = 0 Then
            Conexao.Close()
            Return False
        Else
            MessageBox.Show("Este Código já está cadastrado no banco de dados. Por favor, verifique.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Conexao.Close()
            Return True
        End If

    End Function

    ' VERIFICA SE O CÓDIGO JÁ EXISTE PARA ALTERAÇÃO (VERIFICA O ID E SE O CODIGO FOI ALTERADO)
    Function CodigoJaExiste(ByVal Codigo As Integer, ByVal IdDestinatario As Integer) As Boolean

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)

        Comando.CommandText = "SELECT CODIGO " & _
                                  "FROM DESTINATARIOS " & _
                                  "WHERE ID_DESTINATARIO = " & IdDestinatario & " " & _
                                  "AND CODIGO <> " & Codigo & " " & _
                                  "AND EXISTS (SELECT CODIGO FROM DESTINATARIOS " & _
                                                    "WHERE CODIGO = " & Codigo & ")"
        Conexao.Open()
        If ObjMetodosGlobais.ConverteValorNulo(Comando.ExecuteScalar) = 0 Then
            Conexao.Close()
            Return False
        Else
            MessageBox.Show("O código informado já está cadastrado no banco de dados para outro Remetente/Destinatário. Por favor, verifique.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Conexao.Close()
            Return True
        End If

    End Function

    ' *** INSERT ***
    Sub IncluiDestinatario(ByVal ObjComando As FbCommand)

        Conexao.Open()
        Try
            ObjComando.ExecuteNonQuery()
        Catch Ex As Exception
            MessageBox.Show(Ex.Message)
            Conexao.Close()
            ObjComando.Parameters.Clear()
        End Try
        Conexao.Close()
        ObjComando.Parameters.Clear()

    End Sub

    ' *** UPDATE ***
    Sub AtualizaDestinatario(ByVal ObjComando As FbCommand)

        Conexao.Open()
        Try
            ObjComando.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            Conexao.Close()
            ObjComando.Parameters.Clear()
        End Try
        Conexao.Close()
        ObjComando.Parameters.Clear()

    End Sub

    Sub PovoaComboBoxCodigo(ByRef ObjComboBox As Windows.Forms.ComboBox)

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)
        Dim Tabela As FbDataReader = Nothing
        Comando.CommandText = "SELECT CODIGO FROM DESTINATARIOS " & _
                                "ORDER BY DESCRICAO"
        Conexao.Open()
        Tabela = Comando.ExecuteReader
        While Tabela.Read
            ObjComboBox.Items.Add(Tabela.GetInt32(0))
        End While
        Conexao.Close()

    End Sub

    Sub PovoaComboBoxDescricao(ByRef ObjComboBox As Windows.Forms.ComboBox)

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)
        Dim Tabela As FbDataReader = Nothing
        Comando.CommandText = "SELECT DESCRICAO FROM DESTINATARIOS " & _
                                "ORDER BY DESCRICAO"
        Conexao.Open()
        Tabela = Comando.ExecuteReader
        While Tabela.Read
            ObjComboBox.Items.Add(Tabela.GetString(0))
        End While
        Conexao.Close()

    End Sub


    Function RetornaIDDestinatario(ByVal CodDestinat As Integer) As Integer

        Dim ObjComando As New FBCOMMAND(String.Empty, Conexao)

        ObjComando.CommandText = "SELECT ID_DESTINATARIO " & _
                              "FROM DESTINATARIOS " & _
                              "WHERE CODIGO = " & CodDestinat
        Conexao.Open()
        Dim IDDestinatario As Integer = ObjComando.ExecuteScalar()
        ObjComando.Dispose()
        Conexao.Close()
        Return IDDestinatario

    End Function

    Function ExtraiCodDeTextoDestinatarios(ByVal ObjCodTextoDestinatario As String) As Integer

        ObjCodTextoDestinatario = Left(ObjCodTextoDestinatario, 6)
        Do While ObjCodTextoDestinatario.Contains("-") Or ObjCodTextoDestinatario.Contains(" ")
            ObjCodTextoDestinatario = Left(ObjCodTextoDestinatario, Len(ObjCodTextoDestinatario) - 1)
        Loop

        Return ObjCodTextoDestinatario

    End Function

    Function ExtraiTextoDeCodDestinatarios(ByVal ObjCodTextoDestinatario As String) As String

        Dim Contador As Short = 1
        ObjCodTextoDestinatario = Mid(ObjCodTextoDestinatario, 1, Len(ObjCodTextoDestinatario))
        Do While ObjCodTextoDestinatario.Contains("-")
            ObjCodTextoDestinatario = Mid(ObjCodTextoDestinatario, Contador + 1, Len(ObjCodTextoDestinatario))
        Loop

        If Mid(ObjCodTextoDestinatario, 1, 1) = " " Then
            ObjCodTextoDestinatario = Mid(ObjCodTextoDestinatario, 2, Len(ObjCodTextoDestinatario) - 1)
        End If

        Return ObjCodTextoDestinatario

    End Function

End Class
