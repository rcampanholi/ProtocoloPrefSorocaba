﻿Public Class FormPrincipal

    Private Sub FormPrincipal_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If e.Alt = False Then
            Select Case e.KeyCode
                Case 27 'ESC - SAIR
                    SairToolStripMenuItem_Click(Nothing, Nothing)
            End Select
        End If

    End Sub

    Private Sub SairToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SairToolStripMenuItem.Click

        End

    End Sub

    Private Sub FuncionáriosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FuncionáriosToolStripMenuItem.Click

        FormInteressados.Show()

    End Sub

    Private Sub RemetentesDestinatáriosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemetentesDestinatáriosToolStripMenuItem.Click

        FormRemetentesDestinatarios.Show()

    End Sub

    Private Sub TiposDeDocumentosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TiposDeDocumentosToolStripMenuItem.Click

        FormDocumentos.Show()

    End Sub

    Private Sub CadastroDeUsuáriosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CadastroDeUsuáriosToolStripMenuItem.Click

        If UserAdm = True Then
            FormUsuarios.Show()
        Else
            Dim ObjMensagens As New ClassMensagens
            ObjMensagens.UsuarioNaoHabilitado()
            Exit Sub
        End If

    End Sub

    Private Sub RegistrosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RegistrosToolStripMenuItem.Click

        FormRegistros.Show()

    End Sub

    Private Sub ConsultaAvançadaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConsultaAvançadaToolStripMenuItem.Click

        FormConsultaAvancada.Show()

    End Sub

    Private Sub FormPrincipal_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed

        End

    End Sub

    Private Sub RelatórioDeInclusõesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RelatórioDeInclusõesToolStripMenuItem.Click

        FormRelatorioInclusoes.Show()

    End Sub

    Private Sub ConsultaSQLToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConsultaSQLToolStripMenuItem.Click

        If UserAdm = True Then
            FormConsultaSQL.Show()
        Else
            Dim ObjMensagens As New ClassMensagens
            ObjMensagens.UsuarioNaoHabilitado()
            Exit Sub
        End If

    End Sub

    Private Sub CaixaDeEntradaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CaixaDeEntradaToolStripMenuItem.Click

        FormCaixaEntrada.Show()

    End Sub

    Private Sub ImportarInteressadosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ImportarInteressadosToolStripMenuItem.Click

        If UserAdm = True Then
            FormImportacoes.Show()
        Else
            Dim ObjMensagens As New ClassMensagens
            ObjMensagens.UsuarioNaoHabilitado()
            Exit Sub
        End If

    End Sub

End Class