﻿Public Class FormAlterarSenha

    Private Sub FormAlterarSenha_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If e.Alt = False Then
            Select Case e.KeyCode
                Case 27 'ESC - SAIR
                    CmdSair_Click(Nothing, Nothing)
            End Select
        End If

    End Sub

    Private Sub TxtNomeUser_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles TxtNomeUser.KeyPress

        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)

        If (KeyAscii = 13) Then 'ENTER
            KeyAscii = 0 'PARA IMPEDIR AVISO SONORO
            TxtSenhaAntiga.Focus()
            GoTo EventExitSub
        End If
        KeyAscii = Asc(UCase(Chr(KeyAscii)))

EventExitSub:
        eventArgs.KeyChar = Chr(KeyAscii)
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If

    End Sub

    Private Sub TxtSenhaAntiga_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles TxtSenhaAntiga.KeyPress

        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)

        If (KeyAscii = 13) Then 'ENTER
            KeyAscii = 0 'PARA IMPEDIR AVISO SONORO
            TxtSenhaNova.Focus()
            GoTo EventExitSub
        End If
        KeyAscii = Asc(UCase(Chr(KeyAscii)))

EventExitSub:
        eventArgs.KeyChar = Chr(KeyAscii)
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If

    End Sub

    Private Sub TxtSenhaNova_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles TxtSenhaNova.KeyPress
        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)

        If (KeyAscii = 13) Then 'ENTER
            KeyAscii = 0 'PARA IMPEDIR AVISO SONORO
            TxtConfirmSenhaNova.Focus()
            GoTo EventExitSub
        End If
        KeyAscii = Asc(UCase(Chr(KeyAscii)))

EventExitSub:
        eventArgs.KeyChar = Chr(KeyAscii)
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub TxtConfirmSenhaNova_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles TxtConfirmSenhaNova.KeyPress

        Dim KeyAscii As Short = Asc(eventArgs.KeyChar)

        If (KeyAscii = 13) Then 'ENTER
            KeyAscii = 0 'PARA IMPEDIR AVISO SONORO
            CmdSalvar_Click(CmdSalvar, Nothing)
            GoTo EventExitSub
        End If
        KeyAscii = Asc(UCase(Chr(KeyAscii)))

EventExitSub:
        eventArgs.KeyChar = Chr(KeyAscii)
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub CmdSalvar_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdSalvar.Click

        If ((TxtSenhaNova.Text = String.Empty) Or (TxtConfirmSenhaNova.Text = String.Empty)) Then
            MsgBox("Todos os campos devem ser preenchidos.", MsgBoxStyle.Exclamation, "Atenção!")
            With TxtSenhaNova
                .Focus()
                .SelectionStart = 0
                .SelectionLength = Len(.Text)
                Exit Sub
            End With
        End If

        Dim ObjAlterarSenha As New ClassUsuarios

        If ObjAlterarSenha.ValidaAlterarSenha(TxtNomeUser.Text, TxtSenhaAntiga.Text, TxtSenhaNova.Text, TxtConfirmSenhaNova.Text) = False Then
            Exit Sub
        End If

        ObjAlterarSenha.AlteraSenha(TxtNomeUser.Text, TxtSenhaNova.Text)

        MessageBox.Show("Senha alterada com sucesso.", "Protocolo SEGEP", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Me.LimpaCampos()
        Me.Dispose()
        FormLogIn.Show()
        FormLogIn.TxtUser.Focus()

    End Sub

    Private Sub CmdSair_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdSair.Click

        Me.LimpaCampos()
        Me.Close()
        Me.Dispose()
        FormLogIn.Show()
        FormLogIn.TxtUser.Focus()

    End Sub

    Private Sub LimpaCampos()

        Me.TxtNomeUser.Text = String.Empty
        Me.TxtSenhaAntiga.Text = String.Empty
        Me.TxtSenhaNova.Text = String.Empty
        Me.TxtConfirmSenhaNova.Text = String.Empty

    End Sub

End Class