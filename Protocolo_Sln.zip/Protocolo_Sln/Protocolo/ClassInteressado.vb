﻿Imports FirebirdSql.Data.FirebirdClient

Public Class ClassInteressado

    Dim ObjMetodosGlobais As New ClassMetodosGlobais

    ' VERIFICA SE O CÓDIGO JÁ EXISTE PARA NOVA INCLUSÃO
    Function CodigoJaExiste(ByVal Codigo As Integer) As Boolean

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)

        Comando.CommandText = "SELECT CODIGO " & _
                                  "FROM INTERESSADOS " & _
                                  "WHERE CODIGO = " & Codigo
        Conexao.Open()
        If ObjMetodosGlobais.ConverteValorNulo(Comando.ExecuteScalar) = 0 Then
            Conexao.Close()
            Return False
        Else
            MessageBox.Show("Este Código já está cadastrado no banco de dados. Por favor, verifique.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Conexao.Close()
            Return True
        End If

    End Function

    ' VERIFICA SE O CÓDIGO JÁ EXISTE PARA ALTERAÇÃO (VERIFICA O ID E SE O CODIGO FOI ALTERADO)
    Function CodigoJaExiste(ByVal Codigo As Integer, ByVal IdInteressado As Integer) As Boolean

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)

        Comando.CommandText = "SELECT CODIGO " & _
                                  "FROM INTERESSADOS " & _
                                  "WHERE ID_INTERESSADO = " & IdInteressado & " " & _
                                  "AND CODIGO <> " & Codigo & " " & _
                                  "AND EXISTS (SELECT CODIGO FROM INTERESSADOS " & _
                                                    "WHERE CODIGO = " & Codigo & ")"
        Conexao.Open()
        If ObjMetodosGlobais.ConverteValorNulo(Comando.ExecuteScalar) = 0 Then
            Conexao.Close()
            Return False
        Else
            MessageBox.Show("O código informado já está cadastrado no banco de dados para outro Interessado. Por favor, verifique.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Conexao.Close()
            Return True
        End If

    End Function

    'VERIFICA SE CODIGO EXISTE E NÃO EXIBE MENSAGEM (USADA PARA VERIFICAR SE UM CODIGO INFORMADO É VÁLIDO)
    Function CodigoExiste(ByVal Codigo As Integer) As Boolean

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)

        Comando.CommandText = "SELECT CODIGO " & _
                                  "FROM INTERESSADOS " & _
                                  "WHERE CODIGO = " & Codigo
        Conexao.Open()
        If ObjMetodosGlobais.ConverteValorNulo(Comando.ExecuteScalar) = 0 Then
            Conexao.Close()
            Return False
        Else
            Conexao.Close()
            Return True
        End If

    End Function

    Function RetornaDescrInteressado(ByVal Codigo As Integer) As String

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)
        Dim DescrInteressado As String = String.Empty

        Conexao.Open()
        Comando.CommandText = "SELECT DESCRICAO FROM INTERESSADOS " & _
                                 "WHERE CODIGO = " & Codigo
        DescrInteressado = Comando.ExecuteScalar

        Conexao.Close()

        Return DescrInteressado

    End Function

    ' *** INSERT ***
    Sub IncluiFuncionario(ByVal ObjComando As FBCOMMAND)

        Conexao.Open()
        Try
            ObjComando.ExecuteNonQuery()
        Catch Ex As Exception
            MessageBox.Show(Ex.Message)
            Conexao.Close()
            ObjComando.Parameters.Clear()
        End Try
        Conexao.Close()
        ObjComando.Parameters.Clear()

    End Sub

    ' *** UPDATE ***
    Sub AtualizaFuncionario(ByVal ObjComando As FBCOMMAND)

        Conexao.Open()
        Try
            ObjComando.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            Conexao.Close()
            ObjComando.Parameters.Clear()
        End Try
        Conexao.Close()
        ObjComando.Parameters.Clear()

    End Sub

    Function RetornaIDInteressado(ByVal CodInteressado As Integer) As Integer

        Dim Comando As New FBCOMMAND(String.Empty, Conexao)
        Dim IDInteressadoAux As Integer = 0

        Comando.CommandText = "SELECT ID_INTERESSADO " & _
                              "FROM INTERESSADOS " & _
                              "WHERE CODIGO = " & CodInteressado
        Conexao.Open()
        IDInteressadoAux = Comando.ExecuteScalar
        Conexao.Close()
        Comando.Dispose()

        Return IDInteressadoAux

    End Function

End Class
