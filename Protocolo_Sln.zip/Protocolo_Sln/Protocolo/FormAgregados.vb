﻿Imports FirebirdSql.Data.FirebirdClient

Public Class FormAgregados

    Dim ObjControles As New ClassControles
    Public IdInteressadoPrincipal As Integer
    Public IdRegistro As Integer
    Public DescrInteressadoPrincipal As String

    Private Sub FormAgregados_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If e.Alt = False Then
            Select Case e.KeyCode
                Case 27 'ESC - SAIR
                    If Me.CmdSair.Enabled = True Then
                        CmdSair_Click(Nothing, Nothing)
                    End If
            End Select
        End If

    End Sub

    Private Sub FormAgregados_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Me.LblInteressadoPrincipal.Text = DescrInteressadoPrincipal
        Me.CarregarListAgregados()
        Me.CmdCarregarLisInteressadosGeral.Focus()

    End Sub

    Private Sub FormAgregados_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed

        FormHistoricos.Show()

    End Sub

    Private Sub CmdSair_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CmdSair.Click

        Me.Close()
        Me.Dispose()
        FormHistoricos.Show()

    End Sub

    Private Sub TxtEncontrarInteressado_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtEncontrarInteressado.GotFocus

        ObjControles.FormataTextBox(Me.TxtEncontrarInteressado, True, String.Empty)

    End Sub

    Private Sub TxtEncontrarInteressado_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtEncontrarInteressado.KeyDown

        If e.KeyCode = Keys.Return Then
            LstInteressadosGeral.Focus()
        End If

    End Sub

    Private Sub TxtEncontrarInteressado_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtEncontrarInteressado.LostFocus

        ObjControles.FormataTextBox(Me.TxtEncontrarInteressado, False, "Encontrar Interessado")

    End Sub

    Private Sub TxtEncontrarInteressado_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtEncontrarInteressado.TextChanged

        If Me.TxtEncontrarInteressado.Enabled = True And Me.TxtEncontrarInteressado.Text <> String.Empty And TxtEncontrarInteressado.Text <> "Encontrar Interessado" Then
            ObjControles.EncontraRegistroListView(TxtEncontrarInteressado.Text, Me.LstInteressadosGeral, 1)
        End If

    End Sub

    Private Sub TxtEncontrarAgregado_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtEncontrarAgregado.GotFocus

        ObjControles.FormataTextBox(Me.TxtEncontrarAgregado, True, String.Empty)

    End Sub

    Private Sub TxtEncontrarAgregado_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TxtEncontrarAgregado.KeyDown

        If e.KeyCode = Keys.Return Then
            LstAgregados.Focus()
        End If

    End Sub

    Private Sub TxtEncontrarAgregado_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TxtEncontrarAgregado.LostFocus

        ObjControles.FormataTextBox(Me.TxtEncontrarAgregado, False, "Encontrar Agregado")

    End Sub

    Private Sub TxtEncontrarAgregado_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtEncontrarAgregado.TextChanged

        If Me.TxtEncontrarAgregado.Enabled = True And Me.TxtEncontrarAgregado.Text <> String.Empty And TxtEncontrarAgregado.Text <> "Encontrar Agregado" Then
            ObjControles.EncontraRegistroListView(TxtEncontrarAgregado.Text, Me.LstAgregados, 1)
        End If

    End Sub

    Private Sub ChkSelecionarTodosInteressadosGeral_CheckedChanged(sender As Object, e As EventArgs) Handles ChkSelecionarTodosInteressadosGeral.CheckedChanged

        Dim Acao As Boolean = False

        If Me.ChkSelecionarTodosInteressadosGeral.Checked = True Then
            Acao = True
        End If

        For i As Short = 0 To Me.LstInteressadosGeral.Items.Count - 1
            Me.LstInteressadosGeral.Items(i).Checked = Acao
        Next

    End Sub

    Private Sub ChkSelecionarTodosAgregados_CheckedChanged(sender As Object, e As EventArgs) Handles ChkSelecionarTodosAgregados.CheckedChanged

        Dim Acao As Boolean = False

        If Me.ChkSelecionarTodosAgregados.Checked = True Then
            Acao = True
        End If

        For i As Short = 0 To Me.LstAgregados.Items.Count - 1
            Me.LstAgregados.Items(i).Checked = Acao
        Next

    End Sub

    Sub CarregarListInteressadosGeral()

        Dim ComandoSQL As String = "SELECT CODIGO, DESCRICAO " & _
                                   "FROM INTERESSADOS " & _
                                   "ORDER BY DESCRICAO"

        ObjControles.PreencheListView(Me.LstInteressadosGeral, ComandoSQL, 70, 310)
        Me.LstInteressadosGeral.GridLines = True

        If Me.LstInteressadosGeral.Items.Count > 0 Then
            Me.ChkSelecionarTodosInteressadosGeral.Enabled = True
            Me.TxtEncontrarInteressado.Enabled = True
            Me.CmdIncluir.Enabled = True
        Else
            Me.ChkSelecionarTodosInteressadosGeral.Enabled = False
            Me.TxtEncontrarInteressado.Enabled = False
            Me.CmdIncluir.Enabled = False
        End If

    End Sub

    Sub CarregarListAgregados()

        Dim ObjMetodosGlobais As New ClassMetodosGlobais

        Dim ComandoSQL As String = "SELECT CODIGO, DESCRICAO " & _
                                   "FROM AGREGADOS A " & _
                                   "WHERE A.ID_INTERESSADO_PRINCIPAL = " & IdInteressadoPrincipal & " " & _
                                   "AND A.ID_REGISTRO = " & Me.IdRegistro & " " & _
                                   "ORDER BY A.DESCRICAO"
        ObjControles.PreencheListView(Me.LstAgregados, ComandoSQL, 70, 310)
        Me.LstAgregados.GridLines = True

        If Me.LstAgregados.Items.Count > 0 Then
            Me.ChkSelecionarTodosAgregados.Enabled = True
            Me.TxtEncontrarAgregado.Enabled = True
            Me.CmdExcluir.Enabled = True
        Else
            Me.ChkSelecionarTodosAgregados.Enabled = False
            Me.TxtEncontrarAgregado.Enabled = False
            Me.CmdExcluir.Enabled = False
        End If

    End Sub

    Private Sub CmdCarregarLisInteressadosGeral_Click(sender As Object, e As EventArgs) Handles CmdCarregarLisInteressadosGeral.Click

        Me.CarregarListInteressadosGeral()

    End Sub

    Private Sub CmdIncluir_Click(sender As Object, e As EventArgs) Handles CmdIncluir.Click

        If ObjEstrUsuario.PermissaoIncluir = False Then
            Dim ObjMensagens As New ClassMensagens
            ObjMensagens.UsuarioNaoHabilitado()
            Exit Sub
        End If

        Dim RegistroSelecionado As Boolean = False

        For i As Integer = 0 To Me.LstInteressadosGeral.Items.Count - 1
            If Me.LstInteressadosGeral.Items(i).Checked = True Then
                Me.IncluirAgregado(Me.LstInteressadosGeral.Items(i).Text)
                RegistroSelecionado = True
            End If
        Next

        If RegistroSelecionado = False Then
            MessageBox.Show("Nenhum registro foi selecionado. Verifique por favor.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            CarregarListAgregados()
        End If

    End Sub

    Private Sub CmdExcluir_Click(sender As Object, e As EventArgs) Handles CmdExcluir.Click

        If ObjEstrUsuario.PermissaoExcluir = False Then
            Dim ObjMensagens As New ClassMensagens
            ObjMensagens.UsuarioNaoHabilitado()
            Exit Sub
        End If

        Dim ObjRegistros As New ClassRegistros
        Dim RegistroSelecionado As Boolean = False

        For i As Integer = 0 To Me.LstAgregados.Items.Count - 1
            If Me.LstAgregados.Items(i).Checked = True Then
                ExcluirAgregado(Me.LstAgregados.Items(i).Text)
                RegistroSelecionado = True
            End If
        Next

        If RegistroSelecionado = False Then
            MessageBox.Show("Nenhum registro foi selecionado. Verifique por favor.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            CarregarListAgregados()
        End If

    End Sub

    Private Sub IncluirAgregado(ByVal Codigo As Integer)

        Dim ObjInteressados As New ClassInteressado

        Dim Comando As New FbCommand(String.Empty, Conexao)
        Comando.CommandText = "INSERT INTO AGREGADOS (ID_INTERESSADO_PRINCIPAL, CODIGO, DESCRICAO, ID_REGISTRO) VALUES (?, ?, ?, ?)"
        Comando.Parameters.Add(String.Empty, FbDbType.Integer)
        Comando.Parameters(0).Value = IdInteressadoPrincipal
        Comando.Parameters.Add(String.Empty, FbDbType.Integer)
        Comando.Parameters(1).Value = Codigo
        Comando.Parameters.Add(String.Empty, FbDbType.VarChar)
        Comando.Parameters(2).Value = ObjInteressados.RetornaDescrInteressado(Codigo)
        Comando.Parameters.Add(String.Empty, FbDbType.Integer)
        Comando.Parameters(3).Value = Me.IdRegistro

        Conexao.Open()

        Try
            Comando.ExecuteNonQuery()
        Catch Ex As Exception
            MessageBox.Show(Ex.Message)
        End Try

        Conexao.Close()
        Comando.Parameters.Clear()

    End Sub

    Private Sub ExcluirAgregado(ByVal Codigo As Integer)

        Dim Comando As New FbCommand(String.Empty, Conexao)
        Comando.CommandText = "DELETE FROM AGREGADOS " & _
                              "WHERE CODIGO = " & Codigo & " " & _
                              "AND ID_INTERESSADO_PRINCIPAL = " & IdInteressadoPrincipal & " " & _
                              "AND ID_REGISTRO = " & Me.IdRegistro

        Conexao.Open()

        Try
            Comando.ExecuteNonQuery()
        Catch Ex As Exception
            MessageBox.Show(Ex.Message)
        End Try

        Conexao.Close()
        Comando.Parameters.Clear()

    End Sub

End Class